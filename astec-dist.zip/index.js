var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  ACTIVITY_CATEGORIZATIONS: () => ACTIVITY_CATEGORIZATIONS,
  ACTIVITY_LOCATIONS: () => ACTIVITY_LOCATIONS,
  activities: () => activities,
  activitiesRelations: () => activitiesRelations,
  activityAttachments: () => activityAttachments,
  activityAttachmentsRelations: () => activityAttachmentsRelations,
  activityCategorizationEnum: () => activityCategorizationEnum,
  activityCategoryEnum: () => activityCategoryEnum,
  activityDayStatus: () => activityDayStatus,
  activityReschedules: () => activityReschedules2,
  activityReschedulesRelations: () => activityReschedulesRelations,
  activityStatusEnum: () => activityStatusEnum,
  activityTimeRecords: () => activityTimeRecords,
  activityTimeRecordsRelations: () => activityTimeRecordsRelations,
  activityTravelTimes: () => activityTravelTimes,
  activityTypes: () => activityTypes,
  activityTypesRelations: () => activityTypesRelations,
  agendaBlockTypeEnum: () => agendaBlockTypeEnum,
  agendaBlocks: () => agendaBlocks,
  approvalStatusEnum: () => approvalStatusEnum,
  approvals: () => approvals,
  approvalsRelations: () => approvalsRelations,
  auditLogs: () => auditLogs,
  auditLogsRelations: () => auditLogsRelations,
  clientSites: () => clientSites,
  clientSitesRelations: () => clientSitesRelations,
  clients: () => clients,
  clientsRelations: () => clientsRelations,
  componentCategoryEnum: () => componentCategoryEnum,
  connectionStatusEnum: () => connectionStatusEnum,
  createRatSchema: () => createRatSchema,
  createUserAndTechnicianSchema: () => createUserAndTechnicianSchema,
  dayMarkerEnum: () => dayMarkerEnum,
  dayMarkers: () => dayMarkers,
  dayMarkersRelations: () => dayMarkersRelations,
  gpsStatusEnum: () => gpsStatusEnum,
  insertActivityAttachmentSchema: () => insertActivityAttachmentSchema,
  insertActivityDayStatusSchema: () => insertActivityDayStatusSchema,
  insertActivityRescheduleSchema: () => insertActivityRescheduleSchema,
  insertActivitySchema: () => insertActivitySchema,
  insertActivityTimeRecordSchema: () => insertActivityTimeRecordSchema,
  insertActivityTravelTimeSchema: () => insertActivityTravelTimeSchema,
  insertActivityTypeSchema: () => insertActivityTypeSchema,
  insertAgendaBlockSchema: () => insertAgendaBlockSchema,
  insertApprovalSchema: () => insertApprovalSchema,
  insertAuditLogSchema: () => insertAuditLogSchema,
  insertClientSchema: () => insertClientSchema,
  insertClientSiteSchema: () => insertClientSiteSchema,
  insertDayMarkerSchema: () => insertDayMarkerSchema,
  insertNotificationSchema: () => insertNotificationSchema,
  insertRatSchema: () => insertRatSchema,
  insertRegionSchema: () => insertRegionSchema,
  insertSegmentSchema: () => insertSegmentSchema,
  insertSentReminderSchema: () => insertSentReminderSchema,
  insertTechnicianLocationSchema: () => insertTechnicianLocationSchema,
  insertTechnicianSchema: () => insertTechnicianSchema,
  insertTimeEntrySchema: () => insertTimeEntrySchema,
  insertTravelSegmentSchema: () => insertTravelSegmentSchema,
  insertUserPushSubscriptionSchema: () => insertUserPushSubscriptionSchema,
  insertUserSchema: () => insertUserSchema,
  loginSchema: () => loginSchema,
  migrationLog: () => migrationLog,
  notificationTypeEnum: () => notificationTypeEnum,
  notifications: () => notifications,
  projectTypeEnum: () => projectTypeEnum,
  ratSendChannelEnum: () => ratSendChannelEnum,
  ratStatusEnum: () => ratStatusEnum,
  rats: () => rats,
  ratsRelations: () => ratsRelations,
  regions: () => regions,
  segments: () => segments,
  sentReminders: () => sentReminders,
  technicianLocations: () => technicianLocations,
  technicianLocationsRelations: () => technicianLocationsRelations,
  technicians: () => technicians,
  techniciansRelations: () => techniciansRelations,
  timeEntries: () => timeEntries2,
  timeEntriesRelations: () => timeEntriesRelations,
  timeRecordTypeEnum: () => timeRecordTypeEnum,
  timeSourceEnum: () => timeSourceEnum,
  transportTypeEnum: () => transportTypeEnum,
  travelSegmentTypeEnum: () => travelSegmentTypeEnum,
  travelSegments: () => travelSegments,
  travelSegmentsRelations: () => travelSegmentsRelations,
  travelStatusEnum: () => travelStatusEnum,
  updateActivitySchema: () => updateActivitySchema,
  updateActivityTypeSchema: () => updateActivityTypeSchema,
  updateApprovalSchema: () => updateApprovalSchema,
  updateClientSchema: () => updateClientSchema,
  updateClientSiteSchema: () => updateClientSiteSchema,
  updateRatSchema: () => updateRatSchema,
  updateRegionSchema: () => updateRegionSchema,
  updateSegmentSchema: () => updateSegmentSchema,
  updateTechnicianSchema: () => updateTechnicianSchema,
  updateTimeEntrySchema: () => updateTimeEntrySchema,
  updateTravelSegmentSchema: () => updateTravelSegmentSchema,
  updateUserAndTechnicianSchema: () => updateUserAndTechnicianSchema,
  updateUserSchema: () => updateUserSchema,
  userPushSubscriptions: () => userPushSubscriptions,
  userRoleEnum: () => userRoleEnum,
  users: () => users,
  usersRelations: () => usersRelations
});
import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, pgEnum, decimal, boolean, unique, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var userRoleEnum, activityStatusEnum, activityCategoryEnum, activityCategorizationEnum, ACTIVITY_CATEGORIZATIONS, ACTIVITY_LOCATIONS, dayMarkerEnum, agendaBlockTypeEnum, approvalStatusEnum, gpsStatusEnum, connectionStatusEnum, timeSourceEnum, travelStatusEnum, travelSegmentTypeEnum, notificationTypeEnum, ratStatusEnum, ratSendChannelEnum, projectTypeEnum, componentCategoryEnum, transportTypeEnum, timeRecordTypeEnum, users, technicians, clients, clientSites, activityTypes, migrationLog, segments, regions, activities, activityTravelTimes, activityTimeRecords, activityReschedules2, activityDayStatus, dayMarkers, agendaBlocks, approvals, activityAttachments, auditLogs, technicianLocations, timeEntries2, travelSegments, notifications, userPushSubscriptions, sentReminders, rats, usersRelations, techniciansRelations, clientsRelations, clientSitesRelations, activityTypesRelations, activitiesRelations, activityTimeRecordsRelations, activityReschedulesRelations, approvalsRelations, activityAttachmentsRelations, dayMarkersRelations, auditLogsRelations, technicianLocationsRelations, timeEntriesRelations, travelSegmentsRelations, ratsRelations, insertUserSchema, insertTechnicianSchema, insertClientSchema, insertClientSiteSchema, insertActivityTypeSchema, insertSegmentSchema, insertRegionSchema, insertActivitySchema, insertDayMarkerSchema, insertAgendaBlockSchema, insertActivityTravelTimeSchema, insertActivityTimeRecordSchema, insertActivityRescheduleSchema, insertActivityDayStatusSchema, insertApprovalSchema, insertActivityAttachmentSchema, insertAuditLogSchema, insertTechnicianLocationSchema, insertTimeEntrySchema, insertTravelSegmentSchema, insertNotificationSchema, insertUserPushSubscriptionSchema, insertSentReminderSchema, insertRatSchema, createRatSchema, createUserAndTechnicianSchema, updateUserSchema, updateTechnicianSchema, updateClientSchema, updateClientSiteSchema, updateActivityTypeSchema, updateSegmentSchema, updateRegionSchema, updateActivitySchema, updateApprovalSchema, updateTimeEntrySchema, updateTravelSegmentSchema, updateRatSchema, updateUserAndTechnicianSchema, loginSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    userRoleEnum = pgEnum("user_role", ["admin", "assistente"]);
    activityStatusEnum = pgEnum("activity_status", ["planejado", "aCaminho", "emExecucao", "concluido", "reprovado", "cancelado"]);
    activityCategoryEnum = pgEnum("activity_category", ["efetivo", "adicional", "perda"]);
    activityCategorizationEnum = pgEnum("activity_categorization", ["administrativo", "visita_tecnica", "deslocamento", "qualificacao", "ociosidade"]);
    ACTIVITY_CATEGORIZATIONS = [
      { value: "administrativo", label: "Administrativo" },
      { value: "visita_tecnica", label: "Visita T\xE9cnica" },
      { value: "deslocamento", label: "Deslocamento" },
      { value: "qualificacao", label: "Qualifica\xE7\xE3o" },
      { value: "ociosidade", label: "Ociosidade" }
    ];
    ACTIVITY_LOCATIONS = [
      { value: "cliente", label: "Cliente" },
      { value: "renner", label: "Renner" },
      { value: "home_office", label: "Home Office" },
      { value: "outro", label: "Outro" },
      { value: "trajeto", label: "Trajeto" }
    ];
    dayMarkerEnum = pgEnum("day_marker", ["F", "FE", "S", "D", "P", "H"]);
    agendaBlockTypeEnum = pgEnum("agenda_block_type", ["ferias", "compromisso"]);
    approvalStatusEnum = pgEnum("approval_status", ["pendente", "aprovado", "rejeitado"]);
    gpsStatusEnum = pgEnum("gps_status", ["ativo", "inativo"]);
    connectionStatusEnum = pgEnum("connection_status", ["online", "offline"]);
    timeSourceEnum = pgEnum("time_source", ["manual", "timer", "import", "gps", "route_estimate", "ida_travel", "volta_travel"]);
    travelStatusEnum = pgEnum("travel_status", ["planned", "enroute", "arrived", "reconciled"]);
    travelSegmentTypeEnum = pgEnum("travel_segment_type", ["ida", "execucao", "volta"]);
    notificationTypeEnum = pgEnum("notification_type", ["nova_atividade", "atividade_modificada", "lembrete_atividade", "aprovacao_pendente", "aprovacao_respondida", "mensagem_admin", "alerta_sistema"]);
    ratStatusEnum = pgEnum("rat_status", ["pendente", "rascunho", "completa"]);
    ratSendChannelEnum = pgEnum("rat_send_channel", ["whatsapp", "email", "ambos", "nenhum"]);
    projectTypeEnum = pgEnum("project_type", ["manutencao", "nova"]);
    componentCategoryEnum = pgEnum("component_category", ["componente_a", "componente_b", "componente_c", "diluente", "powder"]);
    transportTypeEnum = pgEnum("transport_type", ["carro", "moto", "a_pe", "transporte_publico", "aviao"]);
    timeRecordTypeEnum = pgEnum("time_record_type", ["ida", "execucao", "retorno_base"]);
    users = pgTable("users", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      username: text("username"),
      // Optional - legacy field, use email for login
      email: text("email").notNull().unique(),
      password: text("password").notNull(),
      role: userRoleEnum("role").notNull().default("assistente"),
      name: text("name").notNull(),
      datasulUsername: text("datasul_username"),
      // login do Datasul associado (perfil Datasul)
      avatarUrl: text("avatar_url"),
      isActive: boolean("is_active").default(true).notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    technicians = pgTable("technicians", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).unique().notNull(),
      name: text("name").notNull(),
      email: text("email").notNull(),
      phone: text("phone").notNull(),
      team: text("team").notNull(),
      baseCity: text("base_city").notNull(),
      color: text("color").notNull(),
      avatarUrl: text("avatar_url"),
      vehicleInfo: text("vehicle_info"),
      licenseNumber: text("license_number"),
      workHoursPerDay: integer("work_hours_per_day").default(8),
      baseAddress: text("base_address"),
      baseNumero: text("base_numero"),
      baseBairro: text("base_bairro"),
      baseState: text("base_state"),
      baseLatitude: decimal("base_latitude", { precision: 10, scale: 7 }),
      baseLongitude: decimal("base_longitude", { precision: 10, scale: 7 }),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    clients = pgTable("clients", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      companyName: text("company_name").notNull(),
      cnpj: text("cnpj"),
      contactName: text("contact_name"),
      contactEmail: text("contact_email"),
      contactPhone: text("contact_phone"),
      internalCode: text("internal_code"),
      taxId: text("tax_id"),
      segment: text("segment"),
      region: text("region"),
      address: text("address"),
      numero: text("numero"),
      bairro: text("bairro"),
      city: text("city"),
      state: text("state"),
      country: text("country").default("Brasil"),
      latitude: decimal("latitude", { precision: 10, scale: 7 }),
      longitude: decimal("longitude", { precision: 10, scale: 7 }),
      responsibleUserId: varchar("responsible_user_id").references(() => users.id),
      teamId: text("team_id"),
      notes: text("notes"),
      active: boolean("active").default(true).notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    clientSites = pgTable("client_sites", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      clientId: varchar("client_id").references(() => clients.id).notNull(),
      siteName: text("site_name").notNull(),
      address: text("address").notNull(),
      city: text("city").notNull(),
      state: text("state").notNull(),
      zipCode: text("zip_code"),
      latitude: decimal("latitude", { precision: 10, scale: 7 }),
      longitude: decimal("longitude", { precision: 10, scale: 7 }),
      accessRequirements: text("access_requirements"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    activityTypes = pgTable("activity_types", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      category: activityCategoryEnum("category").notNull(),
      color: text("color").notNull(),
      icon: text("icon"),
      description: text("description"),
      displayOrder: integer("display_order").default(0),
      isAutomatic: boolean("is_automatic").default(false).notNull(),
      isActive: boolean("is_active").default(true).notNull(),
      parentId: varchar("parent_id"),
      // null = categoria principal, preenchido = subcategoria
      requiresRat: boolean("requires_rat").default(false).notNull(),
      requiresTravel: boolean("requires_travel").default(true).notNull(),
      // se false, fluxo do técnico pula IDA/VOLTA (só inicia e conclui execução)
      categorization: activityCategorizationEnum("categorization"),
      // Categorização manual do tipo (independente da categoria pai)
      locations: text("locations").array(),
      // Locais de realização permitidos para este tipo (cliente, renner, home_office, outro, trajeto)
      isHomeOffice: boolean("is_home_office")
      // Coluna legada (não usada pelo código atual; mantida no schema para preservar dados em bancos antigos)
    });
    migrationLog = pgTable("_migration_log", {
      id: serial("id").primaryKey(),
      version: varchar("version", { length: 50 }).notNull(),
      appliedAt: timestamp("applied_at").defaultNow(),
      description: text("description"),
      success: boolean("success").default(true)
    });
    segments = pgTable("segments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull().unique(),
      description: text("description"),
      active: boolean("active").default(true).notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    regions = pgTable("regions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull().unique(),
      description: text("description"),
      active: boolean("active").default(true).notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    activities = pgTable("activities", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id).notNull(),
      clientId: varchar("client_id").references(() => clients.id),
      clientName: text("client_name"),
      siteId: varchar("site_id").references(() => clientSites.id),
      activityTypeId: varchar("activity_type_id").references(() => activityTypes.id).notNull(),
      location: text("location"),
      // Local de realização escolhido (dentre os locais definidos no tipo de atividade)
      title: text("title"),
      // Título da atividade
      description: text("description"),
      address: text("address"),
      numero: text("numero"),
      bairro: text("bairro"),
      city: text("city"),
      state: text("state"),
      country: text("country").default("Brasil"),
      latitude: decimal("latitude", { precision: 10, scale: 7 }),
      longitude: decimal("longitude", { precision: 10, scale: 7 }),
      scheduledDate: timestamp("scheduled_date").notNull(),
      endDate: timestamp("end_date"),
      // Para atividades multi-dia
      startTime: text("start_time").notNull(),
      endTime: text("end_time").notNull(),
      status: activityStatusEnum("status").notNull().default("planejado"),
      navigationStartTime: timestamp("navigation_start_time"),
      checkInTime: timestamp("check_in_time"),
      checkOutTime: timestamp("check_out_time"),
      checkInLatitude: decimal("check_in_latitude", { precision: 10, scale: 7 }),
      checkInLongitude: decimal("check_in_longitude", { precision: 10, scale: 7 }),
      checkOutLatitude: decimal("check_out_latitude", { precision: 10, scale: 7 }),
      checkOutLongitude: decimal("check_out_longitude", { precision: 10, scale: 7 }),
      actualDurationMinutes: integer("actual_duration_minutes"),
      estimatedTravelMinutes: integer("estimated_travel_minutes"),
      actualTravelMinutes: integer("actual_travel_minutes"),
      travelClassification: activityCategoryEnum("travel_classification"),
      travelJustification: text("travel_justification"),
      transportMode: text("transport_mode"),
      // carro, aviao, onibus, outro, nenhum
      workCompleted: boolean("work_completed"),
      notes: text("notes"),
      // V3: Navigation and time tracking
      navigationEtaMinutes: integer("navigation_eta_minutes"),
      // ETA from GPS when navigation started
      suggestedExecMinutes: integer("suggested_exec_minutes"),
      // Suggested execution time (now - checkInTime)
      idaRecordedAt: timestamp("ida_recorded_at"),
      // When travel time was recorded
      returnBaseRecordedAt: timestamp("return_base_recorded_at"),
      // When return to base was recorded
      actualReturnMinutes: integer("actual_return_minutes"),
      // Actual return travel time reported by technician
      rescheduleCount: integer("reschedule_count").default(0).notNull(),
      // Number of times activity was rescheduled
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    activityTravelTimes = pgTable("activity_travel_times", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      transportType: transportTypeEnum("transport_type").notNull(),
      minutes: integer("minutes").notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    activityTimeRecords = pgTable("activity_time_records", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      recordType: timeRecordTypeEnum("record_type").notNull(),
      // 'ida', 'execucao', 'retorno_base'
      minutesReported: integer("minutes_reported").notNull(),
      // Actual time reported by technician
      gpsEtaMinutes: integer("gps_eta_minutes"),
      // GPS estimated time (nullable)
      transportType: transportTypeEnum("transport_type"),
      // For ida and retorno_base
      baseId: varchar("base_id"),
      // For retorno_base only (technician's base ID)
      startedAt: timestamp("started_at"),
      finishedAt: timestamp("finished_at"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    activityReschedules2 = pgTable("activity_reschedules", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      previousDate: timestamp("previous_date").notNull(),
      previousStartTime: text("previous_start_time").notNull(),
      previousEndTime: text("previous_end_time").notNull(),
      newDate: timestamp("new_date").notNull(),
      newStartTime: text("new_start_time").notNull(),
      newEndTime: text("new_end_time").notNull(),
      reason: text("reason").notNull(),
      rescheduledBy: varchar("rescheduled_by").references(() => users.id).notNull(),
      rescheduleNumber: integer("reschedule_number").notNull(),
      // 1, 2, 3...
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    activityDayStatus = pgTable("activity_day_status", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      date: timestamp("date").notNull(),
      // The specific day
      status: activityStatusEnum("status").notNull().default("planejado"),
      // Status for this day
      startTime: text("start_time"),
      // Per-day start time override (HH:MM)
      endTime: text("end_time"),
      // Per-day end time override (HH:MM)
      checkInTime: timestamp("check_in_time"),
      checkOutTime: timestamp("check_out_time"),
      checkInLatitude: decimal("check_in_latitude", { precision: 10, scale: 7 }),
      checkInLongitude: decimal("check_in_longitude", { precision: 10, scale: 7 }),
      checkOutLatitude: decimal("check_out_latitude", { precision: 10, scale: 7 }),
      checkOutLongitude: decimal("check_out_longitude", { precision: 10, scale: 7 }),
      actualDurationMinutes: integer("actual_duration_minutes"),
      workCompleted: boolean("work_completed").default(false),
      notes: text("notes"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    }, (table) => ({
      // Garante um único registro de status por dia para cada atividade (evita duplicatas em corrida de check-in)
      uniqActivityDate: unique("activity_day_status_activity_date_unique").on(table.activityId, table.date)
    }));
    dayMarkers = pgTable("day_markers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id),
      date: timestamp("date").notNull(),
      markerType: dayMarkerEnum("marker_type").notNull(),
      description: text("description"),
      isGlobal: boolean("is_global").default(false)
    });
    agendaBlocks = pgTable("agenda_blocks", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id, { onDelete: "cascade" }).notNull(),
      blockType: agendaBlockTypeEnum("block_type").notNull(),
      startDate: timestamp("start_date").notNull(),
      // dia inicial (00:00)
      endDate: timestamp("end_date").notNull(),
      // dia final (00:00) — igual a startDate p/ compromisso de 1 dia
      startTime: text("start_time"),
      // "HH:MM" — só p/ compromisso (parcial)
      endTime: text("end_time"),
      // "HH:MM" — só p/ compromisso (parcial)
      description: text("description"),
      createdBy: varchar("created_by").references(() => users.id),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    approvals = pgTable("approvals", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id).notNull(),
      submittedBy: varchar("submitted_by").references(() => users.id).notNull(),
      reviewedBy: varchar("reviewed_by").references(() => users.id),
      status: approvalStatusEnum("status").notNull().default("pendente"),
      submittedAt: timestamp("submitted_at").defaultNow().notNull(),
      reviewedAt: timestamp("reviewed_at"),
      comments: text("comments"),
      rejectionReason: text("rejection_reason")
    });
    activityAttachments = pgTable("activity_attachments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id).notNull(),
      fileName: text("file_name").notNull(),
      fileUrl: text("file_url").notNull(),
      fileType: text("file_type").notNull(),
      fileSize: integer("file_size"),
      uploadedAt: timestamp("uploaded_at").defaultNow().notNull()
    });
    auditLogs = pgTable("audit_logs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id).notNull(),
      action: text("action").notNull(),
      entityType: text("entity_type").notNull(),
      entityId: varchar("entity_id").notNull(),
      changes: text("changes"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    technicianLocations = pgTable("technician_locations", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id, { onDelete: "cascade" }).notNull(),
      latitude: decimal("latitude", { precision: 9, scale: 6 }).notNull(),
      longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
      accuracy: integer("accuracy"),
      battery: integer("battery"),
      gpsStatus: gpsStatusEnum("gps_status").notNull().default("inativo"),
      connectionStatus: connectionStatusEnum("connection_status").notNull().default("offline"),
      deviceModel: text("device_model"),
      androidVersion: text("android_version"),
      appVersion: text("app_version"),
      address: text("address"),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    timeEntries2 = pgTable("time_entries", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id, { onDelete: "cascade" }).notNull(),
      activityTypeId: varchar("activity_type_id").references(() => activityTypes.id).notNull(),
      workDate: timestamp("work_date").notNull(),
      minutes: integer("minutes").notNull(),
      category: activityCategoryEnum("category").notNull(),
      source: timeSourceEnum("source").notNull().default("manual"),
      location: text("location"),
      // Local de realização ("Executado em") associado a estas horas; "Trajeto" para deslocamentos
      notes: text("notes"),
      createdBy: varchar("created_by").references(() => users.id).notNull(),
      agendaActivityId: varchar("agenda_activity_id").references(() => activities.id).unique(),
      travelSegmentId: varchar("travel_segment_id").references(() => travelSegments.id),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    travelSegments = pgTable("travel_segments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      technicianId: varchar("technician_id").references(() => technicians.id, { onDelete: "cascade" }).notNull(),
      agendaActivityId: varchar("agenda_activity_id").references(() => activities.id),
      originLat: decimal("origin_lat", { precision: 10, scale: 7 }).notNull(),
      originLng: decimal("origin_lng", { precision: 10, scale: 7 }).notNull(),
      originAddress: text("origin_address"),
      destLat: decimal("dest_lat", { precision: 10, scale: 7 }).notNull(),
      destLng: decimal("dest_lng", { precision: 10, scale: 7 }).notNull(),
      destAddress: text("dest_address"),
      provider: text("provider").default("osrm"),
      routePolyline: text("route_polyline"),
      distanceMeters: integer("distance_meters"),
      durationEstimatedSec: integer("duration_estimated_sec"),
      durationRealSec: integer("duration_real_sec"),
      startedAt: timestamp("started_at"),
      arrivedAt: timestamp("arrived_at"),
      status: travelStatusEnum("status").notNull().default("planned"),
      segmentType: travelSegmentTypeEnum("segment_type"),
      // ida, execucao, volta
      transportMode: text("transport_mode"),
      // carro, aviao, onibus, outro, nenhum
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    notifications = pgTable("notifications", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
      type: notificationTypeEnum("type").notNull(),
      title: text("title").notNull(),
      message: text("message").notNull(),
      data: text("data"),
      // JSON string with additional data (activityId, etc)
      isRead: boolean("is_read").default(false).notNull(),
      sentToPush: boolean("sent_to_push").default(false).notNull(),
      // Track if sent via OneSignal
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    userPushSubscriptions = pgTable("user_push_subscriptions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
      playerId: text("player_id").notNull().unique(),
      // OneSignal player ID
      deviceModel: text("device_model"),
      osVersion: text("os_version"),
      appVersion: text("app_version"),
      isActive: boolean("is_active").default(true).notNull(),
      lastSeenAt: timestamp("last_seen_at").defaultNow().notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    sentReminders = pgTable("sent_reminders", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      reminderType: text("reminder_type").notNull(),
      // "30min_before", "time_to_start", "time_to_complete"
      sentAt: timestamp("sent_at").defaultNow().notNull()
    });
    rats = pgTable("rats", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      reportNumber: text("report_number").notNull().unique(),
      // RAT-2024-0001 (auto-generated)
      reportNumberManual: text("report_number_manual"),
      // Manual number entered by technician
      activityId: varchar("activity_id").references(() => activities.id, { onDelete: "cascade" }).notNull(),
      technicianId: varchar("technician_id").references(() => technicians.id, { onDelete: "cascade" }).notNull(),
      clientId: varchar("client_id").references(() => clients.id),
      clientName: text("client_name").notNull(),
      // Auto-populated from activity
      clientNameEditable: text("client_name_editable"),
      // Editable version of client name
      // Project type (Obra)
      projectType: projectTypeEnum("project_type"),
      // manutencao or nova
      // Status
      status: ratStatusEnum("status").notNull().default("pendente"),
      // Dates
      openDate: timestamp("open_date").notNull(),
      // Activity checkout date
      closeDate: timestamp("close_date"),
      // When RAT was completed
      openingDate: timestamp("opening_date"),
      // Manual opening date entered by technician (pre-filled from activity date)
      closingDate: timestamp("closing_date"),
      // Manual closing date entered by technician
      // Surface fields
      surfaceMaintenanceGrade: integer("surface_maintenance_grade"),
      // ASTM D0610 (0-10)
      // Application fields
      applicationNote: text("application_note"),
      // Observação da aplicação
      // Technician signature
      technicianSignature: text("technician_signature"),
      // Base64 image of signature
      technicianSignatureName: text("technician_signature_name"),
      // Name displayed with signature
      // Form data stored as JSON for flexibility
      formData: text("form_data"),
      // JSON string
      // Photos organized by section
      photos: text("photos"),
      // JSON array of photo URLs (legacy)
      photoSections: text("photo_sections"),
      // JSON object with photos per section (3-6)
      // Send info
      sentAt: timestamp("sent_at"),
      sendChannel: ratSendChannelEnum("send_channel"),
      // Generated file
      fileUrl: text("file_url"),
      // Imported PDF (alternative to manual form)
      importedPdfUrl: text("imported_pdf_url"),
      importedPdfFilename: text("imported_pdf_filename"),
      // Simplified RAT flag
      isSimplified: boolean("is_simplified").default(false),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    usersRelations = relations(users, ({ one, many }) => ({
      technician: one(technicians, {
        fields: [users.id],
        references: [technicians.userId]
      }),
      auditLogs: many(auditLogs),
      notifications: many(notifications),
      pushSubscriptions: many(userPushSubscriptions)
    }));
    techniciansRelations = relations(technicians, ({ one, many }) => ({
      user: one(users, {
        fields: [technicians.userId],
        references: [users.id]
      }),
      activities: many(activities),
      dayMarkers: many(dayMarkers),
      locations: many(technicianLocations),
      timeEntries: many(timeEntries2),
      travelSegments: many(travelSegments)
    }));
    clientsRelations = relations(clients, ({ many }) => ({
      sites: many(clientSites),
      activities: many(activities)
    }));
    clientSitesRelations = relations(clientSites, ({ one, many }) => ({
      client: one(clients, {
        fields: [clientSites.clientId],
        references: [clients.id]
      }),
      activities: many(activities)
    }));
    activityTypesRelations = relations(activityTypes, ({ many }) => ({
      activities: many(activities)
    }));
    activitiesRelations = relations(activities, ({ one, many }) => ({
      technician: one(technicians, {
        fields: [activities.technicianId],
        references: [technicians.id]
      }),
      client: one(clients, {
        fields: [activities.clientId],
        references: [clients.id]
      }),
      site: one(clientSites, {
        fields: [activities.siteId],
        references: [clientSites.id]
      }),
      activityType: one(activityTypes, {
        fields: [activities.activityTypeId],
        references: [activityTypes.id]
      }),
      approval: one(approvals),
      attachments: many(activityAttachments),
      timeRecords: many(activityTimeRecords)
    }));
    activityTimeRecordsRelations = relations(activityTimeRecords, ({ one }) => ({
      activity: one(activities, {
        fields: [activityTimeRecords.activityId],
        references: [activities.id]
      })
    }));
    activityReschedulesRelations = relations(activityReschedules2, ({ one }) => ({
      activity: one(activities, {
        fields: [activityReschedules2.activityId],
        references: [activities.id]
      }),
      rescheduledByUser: one(users, {
        fields: [activityReschedules2.rescheduledBy],
        references: [users.id]
      })
    }));
    approvalsRelations = relations(approvals, ({ one }) => ({
      activity: one(activities, {
        fields: [approvals.activityId],
        references: [activities.id]
      }),
      submitter: one(users, {
        fields: [approvals.submittedBy],
        references: [users.id]
      }),
      reviewer: one(users, {
        fields: [approvals.reviewedBy],
        references: [users.id]
      })
    }));
    activityAttachmentsRelations = relations(activityAttachments, ({ one }) => ({
      activity: one(activities, {
        fields: [activityAttachments.activityId],
        references: [activities.id]
      })
    }));
    dayMarkersRelations = relations(dayMarkers, ({ one }) => ({
      technician: one(technicians, {
        fields: [dayMarkers.technicianId],
        references: [technicians.id]
      })
    }));
    auditLogsRelations = relations(auditLogs, ({ one }) => ({
      user: one(users, {
        fields: [auditLogs.userId],
        references: [users.id]
      })
    }));
    technicianLocationsRelations = relations(technicianLocations, ({ one }) => ({
      technician: one(technicians, {
        fields: [technicianLocations.technicianId],
        references: [technicians.id]
      })
    }));
    timeEntriesRelations = relations(timeEntries2, ({ one }) => ({
      technician: one(technicians, {
        fields: [timeEntries2.technicianId],
        references: [technicians.id]
      }),
      activityType: one(activityTypes, {
        fields: [timeEntries2.activityTypeId],
        references: [activityTypes.id]
      }),
      creator: one(users, {
        fields: [timeEntries2.createdBy],
        references: [users.id]
      }),
      agendaActivity: one(activities, {
        fields: [timeEntries2.agendaActivityId],
        references: [activities.id]
      }),
      travelSegment: one(travelSegments, {
        fields: [timeEntries2.travelSegmentId],
        references: [travelSegments.id]
      })
    }));
    travelSegmentsRelations = relations(travelSegments, ({ one, many }) => ({
      technician: one(technicians, {
        fields: [travelSegments.technicianId],
        references: [technicians.id]
      }),
      agendaActivity: one(activities, {
        fields: [travelSegments.agendaActivityId],
        references: [activities.id]
      }),
      timeEntries: many(timeEntries2)
    }));
    ratsRelations = relations(rats, ({ one }) => ({
      activity: one(activities, {
        fields: [rats.activityId],
        references: [activities.id]
      }),
      technician: one(technicians, {
        fields: [rats.technicianId],
        references: [technicians.id]
      }),
      client: one(clients, {
        fields: [rats.clientId],
        references: [clients.id]
      })
    }));
    insertUserSchema = createInsertSchema(users).omit({
      id: true,
      createdAt: true
    });
    insertTechnicianSchema = createInsertSchema(technicians).omit({
      id: true,
      createdAt: true
    }).extend({
      baseLatitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable(),
      baseLongitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable()
    });
    insertClientSchema = createInsertSchema(clients).omit({
      id: true,
      createdAt: true
    });
    insertClientSiteSchema = createInsertSchema(clientSites).omit({
      id: true,
      createdAt: true
    });
    insertActivityTypeSchema = createInsertSchema(activityTypes).omit({
      id: true
    });
    insertSegmentSchema = createInsertSchema(segments).omit({
      id: true,
      createdAt: true
    });
    insertRegionSchema = createInsertSchema(regions).omit({
      id: true,
      createdAt: true
    });
    insertActivitySchema = createInsertSchema(activities).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    }).extend({
      scheduledDate: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }),
      endDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string" && val) {
          return new Date(val);
        }
        if (val instanceof Date) {
          return val;
        }
        return null;
      }).optional().nullable(),
      checkInTime: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      checkOutTime: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      latitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable(),
      longitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable()
    });
    insertDayMarkerSchema = createInsertSchema(dayMarkers).omit({
      id: true
    });
    insertAgendaBlockSchema = createInsertSchema(agendaBlocks).omit({
      id: true,
      createdAt: true
    }).extend({
      technicianId: z.string().optional(),
      // definido pelo servidor p/ assistente; obrigatório p/ admin (validado na rota)
      startDate: z.union([z.date(), z.string()]).transform(
        (val) => typeof val === "string" ? new Date(val) : val
      ),
      endDate: z.union([z.date(), z.string()]).transform(
        (val) => typeof val === "string" ? new Date(val) : val
      ),
      startTime: z.string().optional().nullable(),
      endTime: z.string().optional().nullable(),
      description: z.string().optional().nullable(),
      createdBy: z.string().optional().nullable()
    });
    insertActivityTravelTimeSchema = createInsertSchema(activityTravelTimes).omit({
      id: true,
      createdAt: true
    });
    insertActivityTimeRecordSchema = createInsertSchema(activityTimeRecords).omit({
      id: true,
      createdAt: true
    });
    insertActivityRescheduleSchema = createInsertSchema(activityReschedules2).omit({
      id: true,
      createdAt: true
    }).extend({
      previousDate: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") return new Date(val);
        return val;
      }),
      newDate: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") return new Date(val);
        return val;
      })
    });
    insertActivityDayStatusSchema = createInsertSchema(activityDayStatus).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    }).extend({
      date: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") return new Date(val);
        return val;
      }),
      checkInTime: z.union([z.date(), z.string(), z.null(), z.undefined()]).optional().transform((val) => {
        if (!val) return void 0;
        if (typeof val === "string") return new Date(val);
        return val;
      }),
      checkOutTime: z.union([z.date(), z.string(), z.null(), z.undefined()]).optional().transform((val) => {
        if (!val) return void 0;
        if (typeof val === "string") return new Date(val);
        return val;
      })
    });
    insertApprovalSchema = createInsertSchema(approvals).omit({
      id: true,
      submittedAt: true
    });
    insertActivityAttachmentSchema = createInsertSchema(activityAttachments).omit({
      id: true,
      uploadedAt: true
    });
    insertAuditLogSchema = createInsertSchema(auditLogs).omit({
      id: true,
      createdAt: true
    });
    insertTechnicianLocationSchema = createInsertSchema(technicianLocations).omit({
      id: true,
      updatedAt: true
    });
    insertTimeEntrySchema = createInsertSchema(timeEntries2).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    }).extend({
      workDate: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      })
    });
    insertTravelSegmentSchema = createInsertSchema(travelSegments).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    }).extend({
      startedAt: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      arrivedAt: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable()
    });
    insertNotificationSchema = createInsertSchema(notifications).omit({
      id: true,
      createdAt: true
    });
    insertUserPushSubscriptionSchema = createInsertSchema(userPushSubscriptions).omit({
      id: true,
      createdAt: true,
      lastSeenAt: true
    });
    insertSentReminderSchema = createInsertSchema(sentReminders).omit({
      id: true,
      sentAt: true
    });
    insertRatSchema = createInsertSchema(rats).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    }).extend({
      // Explicitly define status to ensure it works correctly with partial()
      status: z.enum(["pendente", "rascunho", "completa"]).optional(),
      openDate: z.union([z.date(), z.string()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }),
      closeDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      openingDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      closingDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable(),
      sentAt: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") {
          return new Date(val);
        }
        return val;
      }).optional().nullable()
    });
    createRatSchema = z.object({
      activityId: z.string(),
      technicianId: z.string().optional(),
      formData: z.string().optional(),
      status: z.enum(["pendente", "rascunho", "completa"]).optional().default("pendente"),
      // New fields
      reportNumberManual: z.string().optional(),
      clientNameEditable: z.string().optional(),
      projectType: z.enum(["manutencao", "nova"]).optional(),
      openingDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return new Date(val);
        return val;
      }).optional().nullable(),
      closingDate: z.union([z.date(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return new Date(val);
        return val;
      }).optional().nullable(),
      surfaceMaintenanceGrade: z.number().min(0).max(10).optional(),
      applicationNote: z.string().optional(),
      technicianSignature: z.string().optional(),
      technicianSignatureName: z.string().optional(),
      photoSections: z.string().optional(),
      isSimplified: z.boolean().optional().default(false)
    });
    createUserAndTechnicianSchema = z.object({
      // User fields
      password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
      role: z.enum(["admin", "assistente"]),
      datasulUsername: z.string().optional().nullable(),
      // Technician fields
      name: z.string().min(1, "Nome \xE9 obrigat\xF3rio"),
      email: z.string().email("Email inv\xE1lido"),
      phone: z.string().min(1, "Telefone \xE9 obrigat\xF3rio"),
      team: z.string().min(1, "Equipe \xE9 obrigat\xF3ria"),
      baseCity: z.string().min(1, "Cidade base \xE9 obrigat\xF3ria"),
      color: z.string().default("#3b82f6"),
      avatarUrl: z.string().optional(),
      vehicleInfo: z.string().optional(),
      licenseNumber: z.string().optional(),
      workHoursPerDay: z.coerce.number().min(1).max(24).default(8),
      // Base address fields (home office)
      baseAddress: z.string().optional(),
      baseNumero: z.string().optional(),
      baseBairro: z.string().optional(),
      baseState: z.string().optional(),
      baseLatitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return void 0;
      }).optional(),
      baseLongitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return void 0;
      }).optional()
    });
    updateUserSchema = insertUserSchema.omit({ password: true }).partial();
    updateTechnicianSchema = insertTechnicianSchema.partial().extend({
      baseLatitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable(),
      baseLongitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable()
    });
    updateClientSchema = insertClientSchema.partial();
    updateClientSiteSchema = insertClientSiteSchema.partial();
    updateActivityTypeSchema = insertActivityTypeSchema.partial();
    updateSegmentSchema = insertSegmentSchema.partial();
    updateRegionSchema = insertRegionSchema.partial();
    updateActivitySchema = insertActivitySchema.partial().extend({
      latitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable(),
      longitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable()
    });
    updateApprovalSchema = insertApprovalSchema.partial();
    updateTimeEntrySchema = insertTimeEntrySchema.partial();
    updateTravelSegmentSchema = insertTravelSegmentSchema.partial();
    updateRatSchema = insertRatSchema.partial();
    updateUserAndTechnicianSchema = z.object({
      // User fields (optional) - empty string for password means "don't change"
      password: z.string().transform((val) => val === "" ? void 0 : val).pipe(z.string().min(6, "Senha deve ter pelo menos 6 caracteres")).optional(),
      role: z.enum(["admin", "assistente"]).optional(),
      datasulUsername: z.string().optional().nullable(),
      // Technician fields (partial) - these will also update user table for consistency
      name: z.string().min(1, "Nome \xE9 obrigat\xF3rio").optional(),
      email: z.string().email("Email inv\xE1lido").optional(),
      phone: z.string().min(1, "Telefone \xE9 obrigat\xF3rio").optional(),
      team: z.string().min(1, "Equipe \xE9 obrigat\xF3ria").optional(),
      baseCity: z.string().min(1, "Cidade base \xE9 obrigat\xF3ria").optional(),
      color: z.string().optional(),
      avatarUrl: z.string().optional(),
      vehicleInfo: z.string().optional(),
      licenseNumber: z.string().optional(),
      workHoursPerDay: z.coerce.number().min(1).max(24).optional(),
      // Base address fields (home office)
      baseAddress: z.string().optional(),
      baseNumero: z.string().optional(),
      baseBairro: z.string().optional(),
      baseState: z.string().optional(),
      // Accept numbers/strings/null and convert numbers to strings for Drizzle decimal types
      baseLatitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable(),
      baseLongitude: z.union([z.number(), z.string(), z.null(), z.undefined()]).transform((val) => {
        if (typeof val === "string") return val;
        if (typeof val === "number") return val.toString();
        return val;
      }).optional().nullable()
    });
    loginSchema = z.object({
      email: z.string().email("Email inv\xE1lido").min(1, "Email \xE9 obrigat\xF3rio"),
      password: z.string().min(1, "Senha \xE9 obrigat\xF3ria")
    });
  }
});

// server/db.ts
var connectionString, forcedDriver, looksLikeNeon, useNeon, pool, db;
var init_db = __esm({
  async "server/db.ts"() {
    "use strict";
    init_schema();
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    connectionString = process.env.DATABASE_URL;
    forcedDriver = process.env.DB_DRIVER?.toLowerCase();
    looksLikeNeon = /neon\.tech|pooler\.|\.neon\./i.test(connectionString);
    useNeon = forcedDriver === "neon" || forcedDriver !== "pg" && looksLikeNeon;
    if (useNeon) {
      const { Pool, neonConfig } = await import("@neondatabase/serverless");
      const { drizzle } = await import("drizzle-orm/neon-serverless");
      const ws = (await import("ws")).default;
      neonConfig.webSocketConstructor = ws;
      pool = new Pool({ connectionString });
      db = drizzle({ client: pool, schema: schema_exports });
      console.log("\u{1F5C4}\uFE0F  DB driver: neon-serverless");
    } else {
      const pg = (await import("pg")).default;
      const { drizzle } = await import("drizzle-orm/node-postgres");
      pool = new pg.Pool({ connectionString });
      db = drizzle(pool, { schema: schema_exports });
      console.log("\u{1F5C4}\uFE0F  DB driver: node-postgres");
    }
  }
});

// server/auth.ts
var auth_exports = {};
__export(auth_exports, {
  comparePassword: () => comparePassword,
  generateToken: () => generateToken,
  hashPassword: () => hashPassword,
  verifyToken: () => verifyToken
});
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
async function hashPassword(password) {
  return bcrypt.hash(password, 10);
}
async function comparePassword(password, hashedPassword) {
  return bcrypt.compare(password, hashedPassword);
}
function generateToken(user) {
  const payload = {
    userId: user.id,
    username: user.username || "",
    role: user.role
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}
function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}
var JWT_SECRET, JWT_EXPIRES_IN;
var init_auth = __esm({
  "server/auth.ts"() {
    "use strict";
    if (!process.env.SESSION_SECRET) {
      throw new Error("SESSION_SECRET environment variable is required for JWT signing");
    }
    JWT_SECRET = process.env.SESSION_SECRET;
    JWT_EXPIRES_IN = "7d";
  }
});

// server/storage.ts
import { eq, and, gte, lte, desc, sql as sql2, like, ilike, or, isNotNull } from "drizzle-orm";
function filterUndefined(obj) {
  return Object.fromEntries(
    Object.entries(obj).filter(([_, v]) => v !== void 0)
  );
}
var DatabaseStorage, storage;
var init_storage = __esm({
  async "server/storage.ts"() {
    "use strict";
    init_schema();
    await init_db();
    DatabaseStorage = class {
      // Users
      async getUser(id) {
        const [user] = await db.select().from(users).where(eq(users.id, id));
        return user || void 0;
      }
      async getUserByUsername(username) {
        const [user] = await db.select().from(users).where(eq(users.username, username));
        return user || void 0;
      }
      async getUserByEmail(email) {
        const [user] = await db.select().from(users).where(eq(users.email, email));
        return user || void 0;
      }
      async getUserByDatasulUsername(datasulUsername) {
        const [user] = await db.select().from(users).where(eq(users.datasulUsername, datasulUsername));
        return user || void 0;
      }
      async createUser(insertUser) {
        const [user] = await db.insert(users).values(insertUser).returning();
        return user;
      }
      async getAllUsers() {
        return await db.select().from(users);
      }
      async updateUser(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [user] = await db.update(users).set(filtered).where(eq(users.id, id)).returning();
        return user;
      }
      async deleteUser(id) {
        const technician = await this.getTechnicianByUserId(id);
        if (technician) {
          await db.delete(dayMarkers).where(eq(dayMarkers.technicianId, technician.id));
          await db.delete(activities).where(eq(activities.technicianId, technician.id));
        }
        await db.delete(auditLogs).where(eq(auditLogs.userId, id));
        await db.delete(activityReschedules).where(eq(activityReschedules.rescheduledBy, id));
        await db.delete(approvals).where(or(eq(approvals.submittedBy, id), eq(approvals.reviewedBy, id)));
        await db.delete(timeEntries).where(eq(timeEntries.createdBy, id));
        await db.update(activities).set({ responsibleUserId: null }).where(eq(activities.responsibleUserId, id));
        await db.delete(notifications).where(eq(notifications.userId, id));
        await db.delete(userPushSubscriptions).where(eq(userPushSubscriptions.userId, id));
        await db.delete(users).where(eq(users.id, id));
      }
      // Technicians
      async getTechnician(id) {
        const [technician] = await db.select().from(technicians).where(eq(technicians.id, id));
        return technician || void 0;
      }
      async getTechnicianByUserId(userId) {
        const [technician] = await db.select().from(technicians).where(eq(technicians.userId, userId));
        return technician || void 0;
      }
      async getAllTechnicians() {
        return await db.select().from(technicians);
      }
      async createTechnician(insertTechnician) {
        const [technician] = await db.insert(technicians).values(insertTechnician).returning();
        return technician;
      }
      async createUserAndTechnician(data) {
        return await db.transaction(async (tx) => {
          const [user] = await tx.insert(users).values(data.user).returning();
          const [technician] = await tx.insert(technicians).values({
            ...data.technician,
            userId: user.id
          }).returning();
          return { user, technician };
        });
      }
      async updateTechnician(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [technician] = await db.update(technicians).set(filtered).where(eq(technicians.id, id)).returning();
        return technician;
      }
      async updateUserAndTechnician(technicianId, data) {
        const existingTechnician = await this.getTechnician(technicianId);
        if (!existingTechnician) {
          throw new Error("T\xE9cnico n\xE3o encontrado");
        }
        return await db.transaction(async (tx) => {
          const { password, role, name, email, datasulUsername, ...technicianData } = data;
          const userUpdate = {};
          if (role) userUpdate.role = role;
          if (name) userUpdate.name = name;
          if (email) userUpdate.email = email;
          if (datasulUsername !== void 0) userUpdate.datasulUsername = datasulUsername || null;
          if (password) {
            const { hashPassword: hashPassword2 } = await Promise.resolve().then(() => (init_auth(), auth_exports));
            userUpdate.password = await hashPassword2(password);
          }
          let user;
          const filteredUserUpdate = filterUndefined(userUpdate);
          if (Object.keys(filteredUserUpdate).length > 0) {
            const [updatedUser] = await tx.update(users).set(filteredUserUpdate).where(eq(users.id, existingTechnician.userId)).returning();
            user = updatedUser;
          } else {
            const [existingUser] = await tx.select().from(users).where(eq(users.id, existingTechnician.userId));
            user = existingUser;
          }
          const technicianUpdate = {};
          if (name) technicianUpdate.name = name;
          if (email) technicianUpdate.email = email;
          Object.assign(technicianUpdate, technicianData);
          let technician;
          const filteredTechUpdate = filterUndefined(technicianUpdate);
          if (Object.keys(filteredTechUpdate).length > 0) {
            const [updatedTech] = await tx.update(technicians).set(filteredTechUpdate).where(eq(technicians.id, technicianId)).returning();
            technician = updatedTech;
          } else {
            technician = existingTechnician;
          }
          if (!user) {
            throw new Error("Usu\xE1rio n\xE3o encontrado");
          }
          return { user, technician };
        });
      }
      async updateTechnicianDatasulProfile(technicianId, datasulUsername) {
        const existingTechnician = await this.getTechnician(technicianId);
        if (!existingTechnician || !existingTechnician.userId) {
          throw new Error("T\xE9cnico n\xE3o encontrado");
        }
        const [updatedUser] = await db.update(users).set({ datasulUsername: datasulUsername || null }).where(eq(users.id, existingTechnician.userId)).returning();
        if (!updatedUser) {
          throw new Error("Usu\xE1rio n\xE3o encontrado");
        }
        return updatedUser;
      }
      async deleteTechnician(id) {
        const technician = await this.getTechnician(id);
        if (!technician) {
          throw new Error("T\xE9cnico n\xE3o encontrado");
        }
        await db.delete(dayMarkers).where(eq(dayMarkers.technicianId, id));
        await db.delete(activities).where(eq(activities.technicianId, id));
        await db.delete(auditLogs).where(eq(auditLogs.userId, technician.userId));
        await db.delete(users).where(eq(users.id, technician.userId));
      }
      async countActivitiesByTechnicianId(technicianId) {
        const result = await db.select({ count: sql2`count(*)` }).from(activities).where(eq(activities.technicianId, technicianId));
        return result[0]?.count || 0;
      }
      // Clients
      async getClient(id) {
        const [client2] = await db.select().from(clients).where(eq(clients.id, id));
        return client2 || void 0;
      }
      async getAllClients() {
        return await db.select().from(clients);
      }
      async listClients(filters) {
        const page = filters?.page || 1;
        const limit = filters?.limit || 50;
        const offset = (page - 1) * limit;
        const conditions = [];
        if (filters?.search) {
          conditions.push(
            or(
              ilike(clients.companyName, `%${filters.search}%`),
              ilike(clients.cnpj, `%${filters.search}%`),
              ilike(clients.contactName, `%${filters.search}%`)
            )
          );
        }
        if (filters?.region) {
          conditions.push(eq(clients.region, filters.region));
        }
        if (filters?.segment) {
          conditions.push(eq(clients.segment, filters.segment));
        }
        if (filters?.active !== void 0) {
          conditions.push(eq(clients.active, filters.active));
        }
        const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
        const countResult = await db.select({ count: sql2`count(*)` }).from(clients).where(whereClause);
        const total = countResult[0]?.count || 0;
        const clientsList = await db.select().from(clients).where(whereClause).orderBy(desc(clients.createdAt)).limit(limit).offset(offset);
        return { clients: clientsList, total };
      }
      async createClient(insertClient) {
        const [client2] = await db.insert(clients).values(insertClient).returning();
        return client2;
      }
      async updateClient(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [client2] = await db.update(clients).set(filtered).where(eq(clients.id, id)).returning();
        return client2;
      }
      async deleteClient(id) {
        await db.delete(clients).where(eq(clients.id, id));
      }
      // Client Sites
      async getClientSite(id) {
        const [site] = await db.select().from(clientSites).where(eq(clientSites.id, id));
        return site || void 0;
      }
      async getClientSitesByClientId(clientId) {
        return await db.select().from(clientSites).where(eq(clientSites.clientId, clientId));
      }
      async createClientSite(insertSite) {
        const [site] = await db.insert(clientSites).values(insertSite).returning();
        return site;
      }
      async updateClientSite(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [site] = await db.update(clientSites).set(filtered).where(eq(clientSites.id, id)).returning();
        return site;
      }
      async deleteClientSite(id) {
        await db.delete(clientSites).where(eq(clientSites.id, id));
      }
      // Activity Types
      async getActivityType(id) {
        const [type] = await db.select().from(activityTypes).where(eq(activityTypes.id, id));
        return type || void 0;
      }
      async getAllActivityTypes() {
        return await db.select().from(activityTypes).orderBy(activityTypes.name);
      }
      async createActivityType(insertType) {
        const [type] = await db.insert(activityTypes).values(insertType).returning();
        return type;
      }
      async updateActivityType(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [type] = await db.update(activityTypes).set(filtered).where(eq(activityTypes.id, id)).returning();
        return type;
      }
      async deleteActivityType(id) {
        await db.delete(activityTypes).where(eq(activityTypes.id, id));
      }
      // Segments
      async getSegment(id) {
        const [segment] = await db.select().from(segments).where(eq(segments.id, id));
        return segment || void 0;
      }
      async getAllSegments() {
        return await db.select().from(segments).where(eq(segments.active, true)).orderBy(segments.name);
      }
      async createSegment(insertSegment) {
        const [segment] = await db.insert(segments).values(insertSegment).returning();
        return segment;
      }
      async updateSegment(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [segment] = await db.update(segments).set(filtered).where(eq(segments.id, id)).returning();
        return segment;
      }
      async deleteSegment(id) {
        await db.delete(segments).where(eq(segments.id, id));
      }
      // Regions
      async getRegion(id) {
        const [region] = await db.select().from(regions).where(eq(regions.id, id));
        return region || void 0;
      }
      async getAllRegions() {
        return await db.select().from(regions).where(eq(regions.active, true)).orderBy(regions.name);
      }
      async createRegion(insertRegion) {
        const [region] = await db.insert(regions).values(insertRegion).returning();
        return region;
      }
      async updateRegion(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [region] = await db.update(regions).set(filtered).where(eq(regions.id, id)).returning();
        return region;
      }
      async deleteRegion(id) {
        await db.delete(regions).where(eq(regions.id, id));
      }
      // Activities
      async getActivity(id) {
        const [activity] = await db.select().from(activities).where(eq(activities.id, id));
        return activity || void 0;
      }
      async getActivitiesByTechnicianId(technicianId) {
        const results = await db.select({
          activity: activities,
          client: {
            contactName: clients.contactName,
            contactPhone: clients.contactPhone,
            contactEmail: clients.contactEmail
          }
        }).from(activities).leftJoin(clients, eq(activities.clientId, clients.id)).where(eq(activities.technicianId, technicianId)).orderBy(desc(activities.scheduledDate));
        return results.map((r) => ({ ...r.activity, client: r.client }));
      }
      async getActivitiesByDateRange(startDate, endDate) {
        console.log(`[Storage] getActivitiesByDateRange called: ${startDate.toISOString()} to ${endDate.toISOString()}`);
        const results = await db.select({
          activity: activities,
          client: {
            id: clients.id,
            name: clients.companyName,
            contactName: clients.contactName,
            contactPhone: clients.contactPhone,
            contactEmail: clients.contactEmail
          },
          technician: {
            id: technicians.id,
            name: technicians.name,
            color: technicians.color
          },
          activityType: {
            id: activityTypes.id,
            name: activityTypes.name
          }
        }).from(activities).leftJoin(clients, eq(activities.clientId, clients.id)).leftJoin(technicians, eq(activities.technicianId, technicians.id)).leftJoin(activityTypes, eq(activities.activityTypeId, activityTypes.id)).where(
          or(
            // Atividade inicia dentro do período
            and(
              gte(activities.scheduledDate, startDate),
              lte(activities.scheduledDate, endDate)
            ),
            // Atividade multi-dia termina dentro do período
            and(
              isNotNull(activities.endDate),
              gte(activities.endDate, startDate),
              lte(activities.endDate, endDate)
            ),
            // Atividade multi-dia abrange todo o período
            and(
              isNotNull(activities.endDate),
              lte(activities.scheduledDate, startDate),
              gte(activities.endDate, endDate)
            )
          )
        ).orderBy(activities.scheduledDate);
        console.log(`[Storage] Found ${results.length} activities in range`);
        return results.map((r) => ({
          ...r.activity,
          client: r.client,
          technician: r.technician,
          activityType: r.activityType
        }));
      }
      async createActivity(insertActivity) {
        const [activity] = await db.insert(activities).values(insertActivity).returning();
        return activity;
      }
      async updateActivity(id, updateData) {
        const filtered = filterUndefined(updateData);
        const updatedData = { ...filtered, updatedAt: /* @__PURE__ */ new Date() };
        const [activity] = await db.update(activities).set(updatedData).where(eq(activities.id, id)).returning();
        return activity;
      }
      async deleteActivity(id) {
        await db.delete(activities).where(eq(activities.id, id));
      }
      // Approvals
      async getApproval(id) {
        const [approval] = await db.select().from(approvals).where(eq(approvals.id, id));
        return approval || void 0;
      }
      async getApprovalByActivityId(activityId) {
        const [approval] = await db.select().from(approvals).where(eq(approvals.activityId, activityId));
        return approval || void 0;
      }
      async getPendingApprovals() {
        return await db.select().from(approvals).where(eq(approvals.status, "pendente")).orderBy(desc(approvals.submittedAt));
      }
      async createApproval(insertApproval) {
        const [approval] = await db.insert(approvals).values(insertApproval).returning();
        return approval;
      }
      async updateApproval(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [approval] = await db.update(approvals).set(filtered).where(eq(approvals.id, id)).returning();
        return approval;
      }
      // Day Markers
      async getDayMarkersByTechnicianId(technicianId) {
        return await db.select().from(dayMarkers).where(eq(dayMarkers.technicianId, technicianId));
      }
      async getDayMarkersByDateRange(startDate, endDate) {
        return await db.select().from(dayMarkers).where(
          and(
            gte(dayMarkers.date, startDate),
            lte(dayMarkers.date, endDate)
          )
        );
      }
      async createDayMarker(insertMarker) {
        const [marker] = await db.insert(dayMarkers).values(insertMarker).returning();
        return marker;
      }
      async deleteDayMarker(id) {
        await db.delete(dayMarkers).where(eq(dayMarkers.id, id));
      }
      // Agenda Blocks (indisponibilidade)
      async getAgendaBlock(id) {
        const [block] = await db.select().from(agendaBlocks).where(eq(agendaBlocks.id, id));
        return block || void 0;
      }
      async getAgendaBlocksByTechnicianId(technicianId) {
        return await db.select().from(agendaBlocks).where(eq(agendaBlocks.technicianId, technicianId));
      }
      async getAgendaBlocksByDateRange(startDate, endDate) {
        return await db.select().from(agendaBlocks).where(
          and(
            lte(agendaBlocks.startDate, endDate),
            gte(agendaBlocks.endDate, startDate)
          )
        );
      }
      async createAgendaBlock(insertBlock) {
        const [block] = await db.insert(agendaBlocks).values(insertBlock).returning();
        return block;
      }
      async deleteAgendaBlock(id) {
        await db.delete(agendaBlocks).where(eq(agendaBlocks.id, id));
      }
      // Activity Attachments
      async getActivityAttachments(activityId) {
        return await db.select().from(activityAttachments).where(eq(activityAttachments.activityId, activityId));
      }
      async createActivityAttachment(insertAttachment) {
        const [attachment] = await db.insert(activityAttachments).values(insertAttachment).returning();
        return attachment;
      }
      async deleteActivityAttachment(id) {
        await db.delete(activityAttachments).where(eq(activityAttachments.id, id));
      }
      // Audit Logs
      async createAuditLog(insertLog) {
        const [log2] = await db.insert(auditLogs).values(insertLog).returning();
        return log2;
      }
      async getAuditLogsByEntityId(entityId) {
        return await db.select().from(auditLogs).where(eq(auditLogs.entityId, entityId)).orderBy(desc(auditLogs.createdAt));
      }
      // Technician Locations (GPS telemetry)
      async createTechnicianLocation(insertLocation) {
        const [location] = await db.insert(technicianLocations).values(insertLocation).returning();
        return location;
      }
      async getLastTechnicianLocation(technicianId) {
        const [location] = await db.select().from(technicianLocations).where(eq(technicianLocations.technicianId, technicianId)).orderBy(desc(technicianLocations.updatedAt)).limit(1);
        return location || void 0;
      }
      async getTechnicianLocationHistory(technicianId, limit = 100) {
        return await db.select().from(technicianLocations).where(eq(technicianLocations.technicianId, technicianId)).orderBy(desc(technicianLocations.updatedAt)).limit(limit);
      }
      // Map/Geo queries
      async getClientsForMap(filters) {
        const conditions = [];
        conditions.push(isNotNull(clients.latitude));
        conditions.push(isNotNull(clients.longitude));
        if (filters?.region) {
          conditions.push(eq(clients.region, filters.region));
        }
        if (filters?.segment) {
          conditions.push(eq(clients.segment, filters.segment));
        }
        if (filters?.search) {
          conditions.push(
            or(
              ilike(clients.companyName, `%${filters.search}%`),
              ilike(clients.contactName, `%${filters.search}%`),
              ilike(clients.internalCode, `%${filters.search}%`)
            )
          );
        }
        const clientsData = await db.select().from(clients).where(and(...conditions));
        const clientsWithSites = clientsData.map((client2) => ({
          ...client2,
          sites: [{
            id: client2.id,
            // Use client ID as site ID
            clientId: client2.id,
            siteName: client2.companyName,
            // Use company name as site name
            address: client2.address || "",
            city: client2.city || "",
            state: client2.state || "",
            zipCode: null,
            latitude: client2.latitude,
            longitude: client2.longitude,
            accessRequirements: null,
            createdAt: client2.createdAt
          }]
        }));
        return clientsWithSites;
      }
      // Notifications
      async getUserNotifications(userId, limit = 50) {
        return await db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(limit);
      }
      async getNotification(id) {
        const [notification] = await db.select().from(notifications).where(eq(notifications.id, id));
        return notification || void 0;
      }
      async createNotification(insertNotification) {
        const [notification] = await db.insert(notifications).values(insertNotification).returning();
        return notification;
      }
      async markNotificationAsRead(id, userId) {
        await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
      }
      async markAllNotificationsAsRead(userId) {
        await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
      }
      // Push Subscriptions
      async upsertPushSubscription(subscription) {
        const existing = await db.select().from(userPushSubscriptions).where(eq(userPushSubscriptions.playerId, subscription.playerId));
        if (existing.length > 0) {
          const [updated] = await db.update(userPushSubscriptions).set({
            userId: subscription.userId,
            isActive: true,
            lastSeenAt: /* @__PURE__ */ new Date()
          }).where(eq(userPushSubscriptions.playerId, subscription.playerId)).returning();
          return updated;
        } else {
          const [created] = await db.insert(userPushSubscriptions).values({
            userId: subscription.userId,
            playerId: subscription.playerId
          }).returning();
          return created;
        }
      }
      async getUserPushSubscriptions(userId) {
        return await db.select().from(userPushSubscriptions).where(and(
          eq(userPushSubscriptions.userId, userId),
          eq(userPushSubscriptions.isActive, true)
        ));
      }
      // RATs (Relatório de Assistência Técnica)
      async getRat(id) {
        const [rat] = await db.select().from(rats).where(eq(rats.id, id));
        return rat || void 0;
      }
      async getRatByActivityId(activityId) {
        const [rat] = await db.select().from(rats).where(eq(rats.activityId, activityId));
        return rat || void 0;
      }
      async getRatsByTechnicianId(technicianId, filters) {
        let conditions = [eq(rats.technicianId, technicianId)];
        if (filters?.status) {
          conditions.push(eq(rats.status, filters.status));
        }
        if (filters?.startDate) {
          conditions.push(gte(rats.openDate, filters.startDate));
        }
        if (filters?.endDate) {
          conditions.push(lte(rats.openDate, filters.endDate));
        }
        return await db.select().from(rats).where(and(...conditions)).orderBy(desc(rats.createdAt));
      }
      async getAllRats(filters) {
        let conditions = [];
        if (filters?.technicianId) {
          conditions.push(eq(rats.technicianId, filters.technicianId));
        }
        if (filters?.clientId) {
          conditions.push(eq(rats.clientId, filters.clientId));
        }
        if (filters?.status) {
          conditions.push(eq(rats.status, filters.status));
        }
        if (filters?.startDate) {
          conditions.push(gte(rats.openDate, filters.startDate));
        }
        if (filters?.endDate) {
          conditions.push(lte(rats.openDate, filters.endDate));
        }
        const query = conditions.length > 0 ? db.select().from(rats).where(and(...conditions)).orderBy(desc(rats.createdAt)) : db.select().from(rats).orderBy(desc(rats.createdAt));
        return await query;
      }
      async createRat(insertRat) {
        const [rat] = await db.insert(rats).values(insertRat).returning();
        return rat;
      }
      async updateRat(id, updateData) {
        const filtered = filterUndefined(updateData);
        const [rat] = await db.update(rats).set({ ...filtered, updatedAt: /* @__PURE__ */ new Date() }).where(eq(rats.id, id)).returning();
        return rat;
      }
      async deleteRat(id) {
        await db.delete(rats).where(eq(rats.id, id));
      }
      async getNextRatNumber() {
        const year = (/* @__PURE__ */ new Date()).getFullYear();
        const prefix = `RAT-${year}-`;
        const result = await db.select({ reportNumber: rats.reportNumber }).from(rats).where(like(rats.reportNumber, `${prefix}%`)).orderBy(desc(rats.reportNumber)).limit(1);
        if (result.length === 0) {
          return `${prefix}0001`;
        }
        const lastNumber = result[0].reportNumber;
        const numPart = parseInt(lastNumber.replace(prefix, ""), 10);
        const nextNum = (numPart + 1).toString().padStart(4, "0");
        return `${prefix}${nextNum}`;
      }
      async getPendingRatsCount(technicianId) {
        const result = await db.select({ count: sql2`count(*)::int` }).from(rats).where(and(
          eq(rats.technicianId, technicianId),
          eq(rats.status, "pendente")
        ));
        return result[0]?.count || 0;
      }
    };
    storage = new DatabaseStorage();
  }
});

// server/utils/geo.ts
var geo_exports = {};
__export(geo_exports, {
  calculateDistance: () => calculateDistance,
  isValidCoordinates: () => isValidCoordinates,
  parseGoogleMapsUrl: () => parseGoogleMapsUrl,
  reverseGeocode: () => reverseGeocode
});
function parseGoogleMapsUrl(url) {
  const result = {
    latitude: null,
    longitude: null,
    address: null,
    placeId: null,
    zoom: null
  };
  try {
    const urlObj = new URL(url);
    const patterns = [
      // Pattern 1: @lat,lng,zoom format
      /@(-?\d+\.\d+),(-?\d+\.\d+),(\d+\.?\d*)z/,
      // Pattern 2: ?q=lat,lng format
      /q=(-?\d+\.\d+),(-?\d+\.\d+)/,
      // Pattern 3: /maps/place/.../@lat,lng format
      /place\/[^/]+\/@(-?\d+\.\d+),(-?\d+\.\d+)/,
      // Pattern 4: ll= parameter
      /ll=(-?\d+\.\d+),(-?\d+\.\d+)/
    ];
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        result.latitude = parseFloat(match[1]);
        result.longitude = parseFloat(match[2]);
        if (match[3]) {
          result.zoom = parseFloat(match[3]);
        }
        break;
      }
    }
    const placeMatch = url.match(/place\/([^/@]+)/);
    if (placeMatch) {
      result.address = decodeURIComponent(placeMatch[1].replace(/\+/g, " "));
    }
    const placeIdMatch = url.match(/place\/[^/]+\/([^/]+)/);
    if (placeIdMatch) {
      result.placeId = placeIdMatch[1];
    }
    return result;
  } catch (error) {
    console.error("Error parsing Google Maps URL:", error);
    return result;
  }
}
function reverseGeocode(lat, lng) {
  return Promise.resolve(`Location at ${lat.toFixed(6)}, ${lng.toFixed(6)}`);
}
function isValidCoordinates(lat, lng) {
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180 && !isNaN(lat) && !isNaN(lng);
}
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
function toRad(degrees) {
  return degrees * (Math.PI / 180);
}
var init_geo = __esm({
  "server/utils/geo.ts"() {
    "use strict";
  }
});

// server/services/geocoding.ts
var geocoding_exports = {};
__export(geocoding_exports, {
  geocodeAddress: () => geocodeAddress,
  reverseGeocode: () => reverseGeocode2,
  reverseGeocodeDetailed: () => reverseGeocodeDetailed
});
import { z as z3 } from "zod";
async function waitForNominatimRateLimit() {
  const now = Date.now();
  const timeSinceLastRequest = now - lastNominatimRequestTime;
  if (timeSinceLastRequest < NOMINATIM_RATE_LIMIT_MS) {
    const waitTime = NOMINATIM_RATE_LIMIT_MS - timeSinceLastRequest;
    await new Promise((resolve) => setTimeout(resolve, waitTime));
  }
  lastNominatimRequestTime = Date.now();
}
async function tryMapboxGeocode(query) {
  if (!MAPBOX_ACCESS_TOKEN) {
    console.log("[Mapbox] No access token configured, skipping");
    return null;
  }
  try {
    const encodedQuery = encodeURIComponent(query);
    const url = `${MAPBOX_BASE_URL}/${encodedQuery}.json?access_token=${MAPBOX_ACCESS_TOKEN}&country=BR&language=pt&limit=1`;
    const response = await fetch(url, {
      headers: {
        "Accept": "application/json"
      }
    });
    if (!response.ok) {
      console.log(`[Mapbox] HTTP ${response.status}: ${response.statusText}`);
      return null;
    }
    const data = await response.json();
    const parsed = MapboxResponseSchema.safeParse(data);
    if (!parsed.success || parsed.data.features.length === 0) {
      return null;
    }
    const feature = parsed.data.features[0];
    const [longitude, latitude] = feature.center;
    let city;
    let state;
    let postcode;
    let bairro;
    if (feature.context) {
      for (const ctx of feature.context) {
        if (ctx.id.startsWith("place.")) {
          city = ctx.text;
        } else if (ctx.id.startsWith("region.")) {
          state = ctx.text;
        } else if (ctx.id.startsWith("postcode.")) {
          postcode = ctx.text;
        } else if (ctx.id.startsWith("neighborhood.") || ctx.id.startsWith("locality.")) {
          bairro = ctx.text;
        }
      }
    }
    console.log(`[Mapbox] \u2713 Found: ${feature.place_name}`);
    return {
      latitude,
      longitude,
      displayName: feature.place_name,
      found: true,
      city,
      state,
      postcode,
      bairro,
      country: "Brasil",
      source: "mapbox"
    };
  } catch (error) {
    console.error("[Mapbox] Error:", error);
    return null;
  }
}
async function tryNominatimGeocode(query) {
  await waitForNominatimRateLimit();
  try {
    const url = new URL(`${NOMINATIM_BASE_URL}/search`);
    url.searchParams.set("q", query);
    url.searchParams.set("format", "json");
    url.searchParams.set("limit", "1");
    url.searchParams.set("addressdetails", "1");
    const response = await fetch(url.toString(), {
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8"
      }
    });
    if (!response.ok) {
      return null;
    }
    const data = await response.json();
    const results = NominatimResponseSchema.parse(data);
    if (results.length === 0) {
      return null;
    }
    const result = results[0];
    const addressDetails = result.address;
    const city = addressDetails?.city || addressDetails?.municipality || addressDetails?.town || addressDetails?.village || addressDetails?.county || void 0;
    const bairro = addressDetails?.suburb || addressDetails?.neighbourhood || addressDetails?.quarter || addressDetails?.city_district || addressDetails?.district || addressDetails?.borough || void 0;
    const roadName = addressDetails?.road || addressDetails?.pedestrian || addressDetails?.footway || void 0;
    const stateName = addressDetails?.state || addressDetails?.state_district || addressDetails?.region || void 0;
    console.log(`[Nominatim] \u2713 Found: ${result.display_name}`);
    return {
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon),
      displayName: result.display_name,
      found: true,
      address: roadName,
      numero: addressDetails?.house_number,
      bairro,
      city,
      state: stateName,
      postcode: addressDetails?.postcode,
      country: addressDetails?.country,
      source: "nominatim"
    };
  } catch (error) {
    return null;
  }
}
function buildQueries(address, numero, bairro, city, state, country) {
  let cleanCity = city;
  if (cleanCity) {
    cleanCity = cleanCity.split(",")[0].trim();
  }
  const queries = [];
  const fullParts = [];
  if (address) {
    fullParts.push(numero ? `${address}, ${numero}` : address);
  }
  if (bairro) fullParts.push(bairro);
  if (cleanCity) fullParts.push(cleanCity);
  if (state) fullParts.push(state);
  if (country) fullParts.push(country);
  if (fullParts.length > 0) {
    queries.push(fullParts.join(", "));
  }
  if (bairro) {
    const noBairroParts = [];
    if (address) {
      noBairroParts.push(numero ? `${address}, ${numero}` : address);
    }
    if (cleanCity) noBairroParts.push(cleanCity);
    if (state) noBairroParts.push(state);
    if (country) noBairroParts.push(country);
    if (noBairroParts.length > 0) {
      queries.push(noBairroParts.join(", "));
    }
  }
  if (address && cleanCity) {
    queries.push(`${address}, ${cleanCity}, ${country || "Brasil"}`);
  }
  if (cleanCity) {
    const cityParts = [cleanCity];
    if (state) cityParts.push(state);
    if (country) cityParts.push(country);
    queries.push(cityParts.join(", "));
  }
  if (address && !cleanCity) {
    const addrParts = [numero ? `${address}, ${numero}` : address];
    if (state) addrParts.push(state);
    addrParts.push(country || "Brasil");
    queries.push(addrParts.join(", "));
  }
  return Array.from(new Set(queries));
}
async function geocodeAddress(address, numero, bairro, city, state, country) {
  const queries = buildQueries(address, numero, bairro, city, state, country);
  if (queries.length === 0) {
    return {
      latitude: 0,
      longitude: 0,
      displayName: "",
      found: false
    };
  }
  if (MAPBOX_ACCESS_TOKEN) {
    for (let i = 0; i < queries.length; i++) {
      console.log(`[Geocode] Mapbox attempt ${i + 1}: ${queries[i]}`);
      const result = await tryMapboxGeocode(queries[i]);
      if (result) {
        return result;
      }
    }
    console.log("[Geocode] Mapbox failed, trying Nominatim fallback...");
  }
  for (let i = 0; i < queries.length; i++) {
    console.log(`[Geocode] Nominatim attempt ${i + 1}: ${queries[i]}`);
    const result = await tryNominatimGeocode(queries[i]);
    if (result) {
      return result;
    }
  }
  console.warn(`[Geocode] \u2717 All geocoding strategies failed`);
  return {
    latitude: 0,
    longitude: 0,
    displayName: queries[0],
    found: false
  };
}
async function reverseGeocode2(latitude, longitude) {
  if (MAPBOX_ACCESS_TOKEN) {
    try {
      const url = `${MAPBOX_BASE_URL}/${longitude},${latitude}.json?access_token=${MAPBOX_ACCESS_TOKEN}&language=pt&limit=1`;
      const response = await fetch(url, {
        headers: { "Accept": "application/json" }
      });
      if (response.ok) {
        const data = await response.json();
        const parsed = MapboxResponseSchema.safeParse(data);
        if (parsed.success && parsed.data.features.length > 0) {
          return {
            address: parsed.data.features[0].place_name,
            found: true,
            source: "mapbox"
          };
        }
      }
    } catch (error) {
      console.error("[Mapbox Reverse] Error:", error);
    }
  }
  await waitForNominatimRateLimit();
  try {
    const url = new URL(`${NOMINATIM_BASE_URL}/reverse`);
    url.searchParams.set("lat", latitude.toString());
    url.searchParams.set("lon", longitude.toString());
    url.searchParams.set("format", "json");
    url.searchParams.set("addressdetails", "1");
    const response = await fetch(url.toString(), {
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8"
      }
    });
    if (!response.ok) {
      return { address: "", found: false };
    }
    const data = await response.json();
    return {
      address: data.display_name || "",
      found: true,
      source: "nominatim"
    };
  } catch (error) {
    console.error("[Nominatim Reverse] Error:", error);
    return { address: "", found: false };
  }
}
async function reverseGeocodeDetailed(latitude, longitude) {
  if (MAPBOX_ACCESS_TOKEN) {
    try {
      const url = `${MAPBOX_BASE_URL}/${longitude},${latitude}.json?access_token=${MAPBOX_ACCESS_TOKEN}&language=pt&limit=1`;
      const response = await fetch(url, {
        headers: { "Accept": "application/json" }
      });
      if (response.ok) {
        const data = await response.json();
        const parsed = MapboxResponseSchema.safeParse(data);
        if (parsed.success && parsed.data.features.length > 0) {
          const feature = parsed.data.features[0];
          let city = null;
          let state = null;
          let bairro = null;
          if (feature.context) {
            for (const ctx of feature.context) {
              if (ctx.id.startsWith("place.")) {
                city = ctx.text;
              } else if (ctx.id.startsWith("region.")) {
                state = ctx.text;
              } else if (ctx.id.startsWith("neighborhood.") || ctx.id.startsWith("locality.")) {
                bairro = ctx.text;
              }
            }
          }
          return {
            address: feature.place_name,
            city,
            state,
            bairro,
            found: true,
            source: "mapbox"
          };
        }
      }
    } catch (error) {
      console.error("[Mapbox Reverse Detailed] Error:", error);
    }
  }
  await waitForNominatimRateLimit();
  try {
    const url = new URL(`${NOMINATIM_BASE_URL}/reverse`);
    url.searchParams.set("lat", latitude.toString());
    url.searchParams.set("lon", longitude.toString());
    url.searchParams.set("format", "json");
    url.searchParams.set("addressdetails", "1");
    const response = await fetch(url.toString(), {
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8"
      }
    });
    if (!response.ok) {
      return { address: "", city: null, state: null, bairro: null, found: false };
    }
    const data = await response.json();
    const addressDetails = data.address;
    const city = addressDetails?.city || addressDetails?.municipality || addressDetails?.town || addressDetails?.village || addressDetails?.county || null;
    const state = addressDetails?.state || addressDetails?.state_district || addressDetails?.region || null;
    const bairro = addressDetails?.suburb || addressDetails?.neighbourhood || addressDetails?.quarter || addressDetails?.city_district || addressDetails?.district || addressDetails?.borough || null;
    return {
      address: data.display_name || "",
      city,
      state,
      bairro,
      found: true,
      source: "nominatim"
    };
  } catch (error) {
    console.error("[Nominatim Reverse Detailed] Error:", error);
    return { address: "", city: null, state: null, bairro: null, found: false };
  }
}
var MAPBOX_BASE_URL, MAPBOX_ACCESS_TOKEN, NOMINATIM_BASE_URL, USER_AGENT, NOMINATIM_RATE_LIMIT_MS, lastNominatimRequestTime, MapboxFeatureSchema, MapboxResponseSchema, NominatimResponseSchema;
var init_geocoding = __esm({
  "server/services/geocoding.ts"() {
    "use strict";
    MAPBOX_BASE_URL = "https://api.mapbox.com/geocoding/v5/mapbox.places";
    MAPBOX_ACCESS_TOKEN = process.env.MAPBOX_ACCESS_TOKEN;
    NOMINATIM_BASE_URL = "https://nominatim.openstreetmap.org";
    USER_AGENT = "ASTEC-Renner/1.0 (renner@astec.com)";
    NOMINATIM_RATE_LIMIT_MS = 1e3;
    lastNominatimRequestTime = 0;
    MapboxFeatureSchema = z3.object({
      id: z3.string(),
      type: z3.literal("Feature"),
      place_type: z3.array(z3.string()),
      relevance: z3.number(),
      text: z3.string(),
      place_name: z3.string(),
      center: z3.tuple([z3.number(), z3.number()]),
      // [longitude, latitude]
      context: z3.array(z3.object({
        id: z3.string(),
        text: z3.string(),
        short_code: z3.string().optional()
      })).optional()
    });
    MapboxResponseSchema = z3.object({
      type: z3.literal("FeatureCollection"),
      features: z3.array(MapboxFeatureSchema)
    });
    NominatimResponseSchema = z3.array(z3.object({
      lat: z3.string(),
      lon: z3.string(),
      display_name: z3.string(),
      importance: z3.number().optional(),
      place_id: z3.number(),
      address: z3.object({
        road: z3.string().optional(),
        pedestrian: z3.string().optional(),
        footway: z3.string().optional(),
        house_number: z3.string().optional(),
        suburb: z3.string().optional(),
        neighbourhood: z3.string().optional(),
        quarter: z3.string().optional(),
        city_district: z3.string().optional(),
        district: z3.string().optional(),
        borough: z3.string().optional(),
        city: z3.string().optional(),
        municipality: z3.string().optional(),
        town: z3.string().optional(),
        village: z3.string().optional(),
        county: z3.string().optional(),
        state: z3.string().optional(),
        state_district: z3.string().optional(),
        region: z3.string().optional(),
        postcode: z3.string().optional(),
        country: z3.string().optional()
      }).optional()
    }));
  }
});

// server/services/routing.ts
var routing_exports = {};
__export(routing_exports, {
  calculateOptimizedRoute: () => calculateOptimizedRoute,
  calculateRoute: () => calculateRoute,
  generateNavigationLinks: () => generateNavigationLinks,
  getLastServiceUsed: () => getLastServiceUsed
});
import { z as z4 } from "zod";
async function calculateRouteMapbox(waypoints, profile = "driving") {
  if (!MAPBOX_ACCESS_TOKEN2) {
    console.warn("Mapbox token not configured, skipping Mapbox routing");
    return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
  }
  try {
    const coordinates = waypoints.map((w) => `${w.longitude},${w.latitude}`).join(";");
    const url = `${MAPBOX_BASE_URL2}/${profile}/${coordinates}`;
    const params = new URLSearchParams({
      access_token: MAPBOX_ACCESS_TOKEN2,
      steps: "true",
      geometries: "geojson",
      overview: "full"
    });
    const response = await fetch(`${url}?${params.toString()}`);
    if (!response.ok) {
      console.error(`Mapbox error: ${response.status} ${response.statusText}`);
      return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
    }
    const data = await response.json();
    const parsed = MapboxRouteSchema.parse(data);
    if (parsed.code !== "Ok" || parsed.routes.length === 0) {
      console.warn(`Mapbox route calculation failed: ${parsed.code}`);
      return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
    }
    const route = parsed.routes[0];
    lastServiceUsed = "mapbox";
    const legs = route.legs.map((leg) => ({
      distance: leg.distance,
      duration: leg.duration,
      steps: (leg.steps || []).map((step) => ({
        distance: step.distance,
        duration: step.duration,
        instruction: step.maneuver?.instruction || step.name || "",
        location: step.maneuver?.location || [0, 0]
      }))
    }));
    console.log(`[Mapbox] Route calculated: ${Math.round(route.distance / 1e3 * 10) / 10} km, ${Math.round(route.duration / 60)} min`);
    return {
      distance: route.distance,
      duration: route.duration,
      distanceKm: Math.round(route.distance / 1e3 * 10) / 10,
      durationMinutes: Math.round(route.duration / 60),
      geometry: route.geometry,
      legs,
      waypoints: parsed.waypoints.map((wp) => ({
        name: wp.name,
        location: wp.location
      })),
      success: true
    };
  } catch (error) {
    console.error("Mapbox routing error:", error);
    return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
  }
}
async function calculateRouteOSRM(waypoints, profile = "car") {
  try {
    const coordinates = waypoints.map((w) => `${w.longitude},${w.latitude}`).join(";");
    const url = `${OSRM_BASE_URL}/route/v1/${profile}/${coordinates}`;
    const params = new URLSearchParams({
      steps: "true",
      geometries: "geojson",
      overview: "full",
      annotations: "true"
    });
    const response = await fetch(`${url}?${params.toString()}`);
    if (!response.ok) {
      console.error(`OSRM error: ${response.status} ${response.statusText}`);
      return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
    }
    const data = await response.json();
    const parsed = OSRMRouteSchema.parse(data);
    if (parsed.code !== "Ok" || parsed.routes.length === 0) {
      console.warn(`OSRM route calculation failed: ${parsed.code}`);
      return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
    }
    const route = parsed.routes[0];
    lastServiceUsed = "osrm";
    const legs = route.legs.map((leg) => ({
      distance: leg.distance,
      duration: leg.duration,
      steps: (leg.steps || []).map((step) => ({
        distance: step.distance,
        duration: step.duration,
        instruction: step.name || "",
        location: step.maneuver?.location || [0, 0]
      }))
    }));
    console.log(`[OSRM Fallback] Route calculated: ${Math.round(route.distance / 1e3 * 10) / 10} km, ${Math.round(route.duration / 60)} min`);
    return {
      distance: route.distance,
      duration: route.duration,
      distanceKm: Math.round(route.distance / 1e3 * 10) / 10,
      durationMinutes: Math.round(route.duration / 60),
      geometry: route.geometry,
      legs,
      waypoints: parsed.waypoints.map((wp) => ({
        name: wp.name,
        location: wp.location
      })),
      success: true
    };
  } catch (error) {
    console.error("OSRM routing error:", error);
    return { distance: 0, duration: 0, distanceKm: 0, durationMinutes: 0, geometry: null, legs: [], waypoints: [], success: false };
  }
}
async function calculateRoute(waypoints, profile = "car") {
  if (waypoints.length < 2) {
    return {
      distance: 0,
      duration: 0,
      distanceKm: 0,
      durationMinutes: 0,
      geometry: null,
      legs: [],
      waypoints: [],
      success: false
    };
  }
  const mapboxProfile = profile === "car" ? "driving-traffic" : profile === "bike" ? "cycling" : "walking";
  if (MAPBOX_ACCESS_TOKEN2) {
    const mapboxResult = await calculateRouteMapbox(waypoints, mapboxProfile);
    if (mapboxResult.success) {
      return mapboxResult;
    }
    console.warn("Mapbox failed, falling back to OSRM");
  }
  return calculateRouteOSRM(waypoints, profile);
}
function getLastServiceUsed() {
  return lastServiceUsed;
}
async function calculateOptimizedRoute(waypoints, profile = "car", options = {}) {
  if (waypoints.length < 2) {
    return {
      distance: 0,
      duration: 0,
      distanceKm: 0,
      durationMinutes: 0,
      geometry: null,
      legs: [],
      waypoints: [],
      waypointOrder: [],
      success: false
    };
  }
  try {
    const coordinates = waypoints.map((w) => `${w.longitude},${w.latitude}`).join(";");
    const url = `${OSRM_BASE_URL}/trip/v1/${profile}/${coordinates}`;
    const params = new URLSearchParams({
      steps: "true",
      geometries: "geojson",
      overview: "full",
      source: options.fixedStart ? "first" : "any",
      destination: options.roundTrip ? "any" : "last"
    });
    const response = await fetch(`${url}?${params.toString()}`);
    if (!response.ok) {
      console.error(`OSRM trip error: ${response.status}`);
      const regularRoute = await calculateRoute(waypoints, profile);
      return {
        ...regularRoute,
        waypointOrder: waypoints.map((_, i) => i)
      };
    }
    const data = await response.json();
    const parsed = OSRMTripSchema.parse(data);
    if (parsed.code !== "Ok" || parsed.trips.length === 0) {
      const regularRoute = await calculateRoute(waypoints, profile);
      return {
        ...regularRoute,
        waypointOrder: waypoints.map((_, i) => i)
      };
    }
    const waypointOrder = parsed.waypoints.map((wp) => wp.waypoint_index);
    const optimizedWaypoints = waypointOrder.map((i) => waypoints[i]);
    if (MAPBOX_ACCESS_TOKEN2) {
      const mapboxRoute = await calculateRoute(optimizedWaypoints, profile);
      if (mapboxRoute.success) {
        console.log(`[Optimized Route] Order: ${waypointOrder.join(" \u2192 ")}, Distance: ${mapboxRoute.distanceKm} km (Mapbox)`);
        return {
          ...mapboxRoute,
          waypointOrder
        };
      }
    }
    const trip = parsed.trips[0];
    lastServiceUsed = "osrm";
    const legs = trip.legs.map((leg) => ({
      distance: leg.distance,
      duration: leg.duration,
      steps: (leg.steps || []).map((step) => ({
        distance: step.distance,
        duration: step.duration,
        instruction: step.name || "",
        location: step.maneuver?.location || [0, 0]
      }))
    }));
    console.log(`[Optimized Route] Order: ${waypointOrder.join(" \u2192 ")}, Distance: ${Math.round(trip.distance / 1e3 * 10) / 10} km (OSRM)`);
    return {
      distance: trip.distance,
      duration: trip.duration,
      distanceKm: Math.round(trip.distance / 1e3 * 10) / 10,
      durationMinutes: Math.round(trip.duration / 60),
      geometry: trip.geometry,
      legs,
      waypoints: parsed.waypoints.map((wp) => ({
        name: wp.name,
        location: wp.location
      })),
      waypointOrder,
      success: true
    };
  } catch (error) {
    console.error("OSRM trip optimization error:", error);
    const regularRoute = await calculateRoute(waypoints, profile);
    return {
      ...regularRoute,
      waypointOrder: waypoints.map((_, i) => i)
    };
  }
}
function generateNavigationLinks(origin, destination, waypoints) {
  const originStr = `${origin.latitude},${origin.longitude}`;
  const destStr = `${destination.latitude},${destination.longitude}`;
  let googleMaps = `https://www.google.com/maps/dir/?api=1&origin=${originStr}&destination=${destStr}&travelmode=driving`;
  if (waypoints && waypoints.length > 0) {
    const waypointsStr = waypoints.map((w) => `${w.latitude},${w.longitude}`).join("|");
    googleMaps += `&waypoints=${waypointsStr}`;
  }
  const waze = `https://waze.com/ul?ll=${destination.latitude},${destination.longitude}&navigate=yes`;
  const appleMaps = `http://maps.apple.com/?daddr=${destStr}&dirflg=d`;
  return {
    googleMaps,
    waze,
    appleMaps
  };
}
var MAPBOX_BASE_URL2, MAPBOX_ACCESS_TOKEN2, OSRM_BASE_URL, MapboxRouteSchema, lastServiceUsed, OSRMRouteSchema, OSRMTripSchema;
var init_routing = __esm({
  "server/services/routing.ts"() {
    "use strict";
    MAPBOX_BASE_URL2 = "https://api.mapbox.com/directions/v5/mapbox";
    MAPBOX_ACCESS_TOKEN2 = process.env.MAPBOX_ACCESS_TOKEN;
    OSRM_BASE_URL = "http://router.project-osrm.org";
    MapboxRouteSchema = z4.object({
      code: z4.string(),
      routes: z4.array(z4.object({
        distance: z4.number(),
        // meters
        duration: z4.number(),
        // seconds
        geometry: z4.any(),
        // GeoJSON LineString or polyline
        legs: z4.array(z4.object({
          distance: z4.number(),
          duration: z4.number(),
          summary: z4.string().optional(),
          steps: z4.array(z4.object({
            distance: z4.number(),
            duration: z4.number(),
            name: z4.string().optional(),
            maneuver: z4.object({
              type: z4.string(),
              location: z4.array(z4.number()),
              instruction: z4.string().optional()
            }).optional()
          })).optional()
        }))
      })),
      waypoints: z4.array(z4.object({
        name: z4.string().optional(),
        location: z4.array(z4.number())
      }))
    });
    lastServiceUsed = "osrm";
    OSRMRouteSchema = z4.object({
      code: z4.string(),
      routes: z4.array(z4.object({
        distance: z4.number(),
        // meters
        duration: z4.number(),
        // seconds
        geometry: z4.any(),
        // GeoJSON LineString
        legs: z4.array(z4.object({
          distance: z4.number(),
          duration: z4.number(),
          steps: z4.array(z4.object({
            distance: z4.number(),
            duration: z4.number(),
            name: z4.string().optional(),
            maneuver: z4.object({
              type: z4.string(),
              location: z4.array(z4.number())
            }).optional()
          })).optional()
        }))
      })),
      waypoints: z4.array(z4.object({
        name: z4.string().optional(),
        location: z4.array(z4.number())
      }))
    });
    OSRMTripSchema = z4.object({
      code: z4.string(),
      trips: z4.array(z4.object({
        distance: z4.number(),
        // meters
        duration: z4.number(),
        // seconds
        geometry: z4.any(),
        // GeoJSON LineString
        legs: z4.array(z4.object({
          distance: z4.number(),
          duration: z4.number(),
          steps: z4.array(z4.object({
            distance: z4.number(),
            duration: z4.number(),
            name: z4.string().optional(),
            maneuver: z4.object({
              type: z4.string(),
              location: z4.array(z4.number())
            }).optional()
          })).optional()
        }))
      })),
      waypoints: z4.array(z4.object({
        name: z4.string().optional(),
        location: z4.array(z4.number()),
        waypoint_index: z4.number(),
        trips_index: z4.number()
      }))
    });
  }
});

// server/services/onesignal.ts
var onesignal_exports = {};
__export(onesignal_exports, {
  sendBulkNotifications: () => sendBulkNotifications,
  sendPushNotification: () => sendPushNotification
});
import * as OneSignal from "onesignal-node";
import { eq as eq3 } from "drizzle-orm";
async function sendPushNotification(options) {
  try {
    const notificationData = {
      userId: options.userId,
      type: options.type,
      title: options.title,
      message: options.message,
      data: options.data ? JSON.stringify(options.data) : null,
      isRead: false,
      sentToPush: false
    };
    const savedNotification = await storage.createNotification(notificationData);
    if (!client) {
      console.warn("OneSignal client not initialized - notification saved to database only");
      return;
    }
    const subscriptions = await storage.getUserPushSubscriptions(options.userId);
    if (subscriptions.length === 0) {
      console.log(`User ${options.userId} has no active push subscriptions`);
      return;
    }
    const playerIds = subscriptions.map((sub) => sub.playerId);
    const notification = {
      headings: { en: options.title, pt: options.title },
      contents: { en: options.message, pt: options.message },
      include_player_ids: playerIds,
      data: {
        notificationId: savedNotification.id,
        type: options.type,
        ...options.data || {}
      },
      ...options.url ? { url: options.url } : {}
    };
    const response = await client.createNotification(notification);
    await db.update(notifications).set({ sentToPush: true }).where(eq3(notifications.id, savedNotification.id));
    console.log(`Push notification sent to ${playerIds.length} devices for user ${options.userId}:`, response);
  } catch (error) {
    console.error("Failed to send push notification:", error);
    throw error;
  }
}
async function sendBulkNotifications(notifications2) {
  await Promise.allSettled(
    notifications2.map((notification) => sendPushNotification(notification))
  );
}
var appId, apiKey, client;
var init_onesignal = __esm({
  async "server/services/onesignal.ts"() {
    "use strict";
    await init_storage();
    await init_db();
    init_schema();
    appId = process.env.ONESIGNAL_APP_ID;
    apiKey = process.env.ONESIGNAL_API_KEY;
    if (!appId || !apiKey) {
      console.warn("OneSignal credentials not configured - push notifications will be disabled");
    }
    client = appId && apiKey ? new OneSignal.Client(appId, apiKey) : null;
  }
});

// server/services/notifications.ts
var notifications_exports = {};
__export(notifications_exports, {
  checkAndSendReminders: () => checkAndSendReminders,
  sendActivityCreatedNotification: () => sendActivityCreatedNotification,
  startReminderScheduler: () => startReminderScheduler,
  stopReminderScheduler: () => stopReminderScheduler
});
import { eq as eq4, and as and2, gte as gte2, lte as lte2, sql as sql3 } from "drizzle-orm";
async function checkAndSendReminders() {
  try {
    const now = /* @__PURE__ */ new Date();
    const today = new Date(now);
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 2);
    const plannedActivities = await db.select({
      activity: activities,
      technicianName: technicians.name,
      technicianUserId: technicians.userId
    }).from(activities).leftJoin(technicians, eq4(activities.technicianId, technicians.id)).where(
      and2(
        gte2(activities.scheduledDate, today),
        lte2(activities.scheduledDate, tomorrow),
        eq4(activities.status, "planejado")
      )
    );
    const inProgressActivities = await db.select({
      activity: activities,
      technicianName: technicians.name,
      technicianUserId: technicians.userId
    }).from(activities).leftJoin(technicians, eq4(activities.technicianId, technicians.id)).where(eq4(activities.status, "emExecucao"));
    const activitiesToCheck = [...plannedActivities, ...inProgressActivities];
    for (const { activity, technicianName, technicianUserId } of activitiesToCheck) {
      if (!technicianUserId || !technicianName) continue;
      for (const config of REMINDER_CONFIGS) {
        if (config.checkCondition(activity, now)) {
          const alreadySent = await db.select().from(sentReminders).where(
            and2(
              eq4(sentReminders.activityId, activity.id),
              eq4(sentReminders.reminderType, config.type)
            )
          ).limit(1);
          if (alreadySent.length === 0) {
            const { title, message } = config.notificationData(activity, technicianName);
            await sendPushNotification({
              userId: technicianUserId,
              type: "lembrete_atividade",
              title,
              message,
              data: {
                activityId: activity.id,
                reminderType: config.type
              },
              url: `/minha-agenda?highlight=${activity.id}`
            });
            await db.insert(sentReminders).values({
              activityId: activity.id,
              reminderType: config.type
            });
            console.log(`\u2705 Sent ${config.type} reminder for activity ${activity.id}`);
          }
        }
      }
    }
  } catch (error) {
    console.error("Error checking and sending reminders:", error);
  }
}
async function sendActivityCreatedNotification(activityId, createdByUserId) {
  try {
    const result = await db.select({
      activity: activities,
      technicianName: technicians.name,
      technicianUserId: technicians.userId,
      activityTypeName: activityTypes.name,
      creatorName: sql3`(SELECT name FROM users WHERE id = ${createdByUserId})`.as("creator_name")
    }).from(activities).leftJoin(technicians, eq4(activities.technicianId, technicians.id)).leftJoin(activityTypes, eq4(activities.activityTypeId, activityTypes.id)).where(eq4(activities.id, activityId)).limit(1);
    if (result.length === 0) return;
    const { activity, technicianName, technicianUserId, activityTypeName, creatorName } = result[0];
    if (!technicianUserId || !technicianName) return;
    const scheduledTime = new Date(activity.scheduledDate);
    if (activity.startTime) {
      const [hours, minutes] = activity.startTime.split(":");
      scheduledTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    }
    const formattedDate = scheduledTime.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
    const formattedTime = activity.startTime || "00:00";
    const title = "Nova Atividade Atribu\xEDda";
    const message = `${technicianName}, voc\xEA tem uma nova atividade agendada para ${formattedDate} \xE0s ${formattedTime}. ${activityTypeName ? `Tipo: ${activityTypeName}.` : ""} ${activity.description ? `Descri\xE7\xE3o: ${activity.description}.` : ""} Atribu\xEDda por ${creatorName || "Admin"}.`;
    await sendPushNotification({
      userId: technicianUserId,
      type: "nova_atividade",
      title,
      message,
      data: {
        activityId: activity.id,
        scheduledDate: formattedDate,
        scheduledTime: formattedTime
      },
      url: `/minha-agenda?highlight=${activity.id}`
    });
    console.log(`\u2705 Sent activity creation notification for activity ${activityId}`);
  } catch (error) {
    console.error("Error sending activity created notification:", error);
  }
}
function startReminderScheduler() {
  if (reminderInterval) {
    console.log("\u26A0\uFE0F Reminder scheduler already running");
    return;
  }
  console.log("\u{1F680} Starting notification reminder scheduler...");
  checkAndSendReminders();
  reminderInterval = setInterval(() => {
    checkAndSendReminders();
  }, 5 * 60 * 1e3);
  console.log("\u2705 Reminder scheduler started (checking every 5 minutes)");
}
function stopReminderScheduler() {
  if (reminderInterval) {
    clearInterval(reminderInterval);
    reminderInterval = null;
    console.log("\u{1F6D1} Reminder scheduler stopped");
  }
}
var REMINDER_CONFIGS, reminderInterval;
var init_notifications = __esm({
  async "server/services/notifications.ts"() {
    "use strict";
    await init_onesignal();
    await init_db();
    init_schema();
    REMINDER_CONFIGS = [
      {
        type: "30min_before",
        checkCondition: (activity, now) => {
          if (activity.status !== "planejado") return false;
          const scheduledTime = new Date(activity.scheduledDate);
          scheduledTime.setHours(
            parseInt(activity.startTime?.split(":")[0] || "0"),
            parseInt(activity.startTime?.split(":")[1] || "0"),
            0,
            0
          );
          const thirtyMinBefore = new Date(scheduledTime.getTime() - 30 * 60 * 1e3);
          const fiveMinAfter = new Date(scheduledTime.getTime() - 25 * 60 * 1e3);
          return now >= thirtyMinBefore && now < fiveMinAfter;
        },
        notificationData: (activity, technicianName) => ({
          title: "Lembrete: Atividade em 30 minutos",
          message: `Ol\xE1 ${technicianName}, sua atividade est\xE1 agendada para come\xE7ar em 30 minutos. ${activity.description ? `Descri\xE7\xE3o: ${activity.description}` : ""}`
        })
      },
      {
        type: "time_to_start",
        checkCondition: (activity, now) => {
          if (activity.status !== "planejado") return false;
          const scheduledTime = new Date(activity.scheduledDate);
          scheduledTime.setHours(
            parseInt(activity.startTime?.split(":")[0] || "0"),
            parseInt(activity.startTime?.split(":")[1] || "0"),
            0,
            0
          );
          const fiveMinWindow = 5 * 60 * 1e3;
          const timeDiff = now.getTime() - scheduledTime.getTime();
          return timeDiff >= 0 && timeDiff < fiveMinWindow;
        },
        notificationData: (activity, technicianName) => ({
          title: "Hora de Iniciar Atividade",
          message: `${technicianName}, est\xE1 na hora de iniciar a atividade. ${activity.description ? `Descri\xE7\xE3o: ${activity.description}.` : ""} Clique para fazer check-in.`
        })
      },
      {
        type: "time_to_complete",
        checkCondition: (activity, now) => {
          if (activity.status !== "emExecucao") return false;
          if (!activity.checkInTime) return false;
          const checkInTime = new Date(activity.checkInTime);
          const twoHoursAgo = new Date(now.getTime() - 2 * 60 * 60 * 1e3);
          return checkInTime <= twoHoursAgo;
        },
        notificationData: (activity, technicianName) => ({
          title: "Lembrete: Concluir Atividade",
          message: `${technicianName}, voc\xEA est\xE1 trabalhando nesta atividade h\xE1 mais de 2 horas. ${activity.description ? `Descri\xE7\xE3o: ${activity.description}.` : ""} N\xE3o se esque\xE7a de fazer o check-out ao finalizar.`
        })
      }
    ];
    reminderInterval = null;
  }
});

// server/index.ts
import "dotenv/config";
import express2 from "express";

// server/routes.ts
import { createServer } from "http";
import multer from "multer";
import archiver from "archiver";

// server/browser-pool.ts
import puppeteer from "puppeteer";
var browserInstance = null;
var browserCloseTimeout = null;
var activePages = 0;
var browserLaunching = false;
var browserWaitQueue = [];
var slotWaitQueue = [];
var BROWSER_IDLE_TIMEOUT = 6e4;
var MAX_CONCURRENT_PAGES = 5;
var SLOT_WAIT_TIMEOUT_MS = 6e4;
async function getBrowserPath() {
  const { execSync } = await import("child_process");
  let chromiumPath;
  try {
    const foundPath = execSync("which chromium || which chromium-browser || which google-chrome 2>/dev/null", { encoding: "utf-8" }).trim();
    if (foundPath && foundPath.length > 0) {
      chromiumPath = foundPath;
      console.log(`[Browser Pool] Using system Chromium at: ${chromiumPath}`);
    }
  } catch {
  }
  if (!chromiumPath) {
    try {
      chromiumPath = puppeteer.executablePath();
      console.log(`[Browser Pool] Using Puppeteer bundled Chromium at: ${chromiumPath}`);
    } catch {
      console.log("[Browser Pool] Could not get Puppeteer executable path, will use default");
      chromiumPath = void 0;
    }
  }
  return chromiumPath;
}
async function launchBrowser() {
  const chromiumPath = await getBrowserPath();
  console.log(`[Browser Pool] Launching new browser instance...`);
  const browser = await puppeteer.launch({
    headless: true,
    ...chromiumPath ? { executablePath: chromiumPath } : {},
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      "--disable-software-rasterizer",
      "--single-process",
      "--font-render-hinting=none",
      "--disable-extensions",
      "--disable-background-networking",
      "--disable-sync",
      "--disable-translate",
      "--metrics-recording-only",
      "--mute-audio",
      "--no-first-run",
      "--safebrowsing-disable-auto-update"
    ]
  });
  browser.on("disconnected", () => {
    console.log("[Browser Pool] Browser disconnected");
    browserInstance = null;
    browserLaunching = false;
  });
  console.log(`[Browser Pool] Browser launched successfully`);
  return browser;
}
function scheduleClose() {
  if (!browserInstance || activePages > 0) {
    return;
  }
  if (browserCloseTimeout) {
    clearTimeout(browserCloseTimeout);
  }
  browserCloseTimeout = setTimeout(async () => {
    if (browserInstance && activePages === 0) {
      console.log("[Browser Pool] Closing idle browser to free memory");
      try {
        await browserInstance.close();
      } catch (e) {
        console.error("[Browser Pool] Error closing browser:", e);
      }
      browserInstance = null;
    }
  }, BROWSER_IDLE_TIMEOUT);
}
function isBrowserConnected() {
  if (!browserInstance) return false;
  try {
    return typeof browserInstance.isConnected === "function" ? browserInstance.isConnected() : true;
  } catch {
    return false;
  }
}
async function getBrowser() {
  if (browserCloseTimeout) {
    clearTimeout(browserCloseTimeout);
    browserCloseTimeout = null;
  }
  if (browserInstance && isBrowserConnected()) {
    return browserInstance;
  }
  if (browserLaunching) {
    return new Promise((resolve, reject) => {
      browserWaitQueue.push({ resolve, reject });
    });
  }
  browserLaunching = true;
  try {
    browserInstance = await launchBrowser();
    browserLaunching = false;
    while (browserWaitQueue.length > 0) {
      const waiter = browserWaitQueue.shift();
      if (waiter && browserInstance) {
        waiter.resolve(browserInstance);
      }
    }
    return browserInstance;
  } catch (error) {
    browserLaunching = false;
    browserInstance = null;
    const err = error;
    while (browserWaitQueue.length > 0) {
      const waiter = browserWaitQueue.shift();
      if (waiter) {
        waiter.reject(err);
      }
    }
    throw error;
  }
}
function processSlotQueue() {
  if (slotWaitQueue.length > 0 && activePages < MAX_CONCURRENT_PAGES) {
    const next = slotWaitQueue.shift();
    if (next) {
      clearTimeout(next.timer);
      next.resolve();
    }
  }
}
async function acquireSlot() {
  if (activePages < MAX_CONCURRENT_PAGES) {
    activePages++;
    return;
  }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      const index = slotWaitQueue.findIndex((entry) => entry.timer === timer);
      if (index !== -1) {
        slotWaitQueue.splice(index, 1);
      }
      reject(new Error("PDF generation queue timeout. Server is busy, please try again later."));
    }, SLOT_WAIT_TIMEOUT_MS);
    slotWaitQueue.push({
      resolve: () => {
        activePages++;
        resolve();
      },
      reject,
      timer
    });
  });
}
function releaseSlot() {
  activePages = Math.max(0, activePages - 1);
  processSlotQueue();
}
async function generatePdfFromHtml(html) {
  await acquireSlot();
  let page = null;
  try {
    const browser = await getBrowser();
    page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0", timeout: 3e4 });
    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "10mm", right: "10mm", bottom: "10mm", left: "10mm" }
    });
    return Buffer.from(pdfBuffer);
  } finally {
    if (page) {
      try {
        await page.close();
      } catch (e) {
        console.error("[Browser Pool] Error closing page:", e);
      }
    }
    releaseSlot();
    if (browserInstance && activePages === 0) {
      scheduleClose();
    }
  }
}
async function closeBrowser() {
  if (browserCloseTimeout) {
    clearTimeout(browserCloseTimeout);
    browserCloseTimeout = null;
  }
  while (slotWaitQueue.length > 0) {
    const waiter = slotWaitQueue.shift();
    if (waiter) {
      clearTimeout(waiter.timer);
      waiter.reject(new Error("Browser pool shutting down"));
    }
  }
  while (browserWaitQueue.length > 0) {
    const waiter = browserWaitQueue.shift();
    if (waiter) {
      waiter.reject(new Error("Browser pool shutting down"));
    }
  }
  if (browserInstance) {
    console.log("[Browser Pool] Force closing browser");
    try {
      await browserInstance.close();
    } catch (e) {
      console.error("[Browser Pool] Error force closing browser:", e);
    }
    browserInstance = null;
  }
  browserLaunching = false;
  activePages = 0;
}

// server/logo-base64.ts
var RENNER_LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAS8AAABJCAYAAABsBKArAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFxEAABcRAcom8z8AADZiSURBVHhe7Z11mFzV2cB/59rY7kaJEOLuCXElQiAETwsUL0VaihRo4QOKU6RYg0tboEJb3AOBJMTd3YkRt7WxK+f748za7O7MhCRkS+f3PPdJdu6ZO2funPue97znFciSJUuWLFmyZMnywyCSX8gUKaUlpewDjJTQGNABmdwuS5YsWcohBLge7NTgayHEAiGEndwoE76X8PI8ryNwLzASz8vDdU0p5fe6VpYsWf73EIYeR9MLJHwt4GFN09Ymt0nHYQucWCzW1bCs5zXPO4UNG4h/8DHOhg3guEqmZsmSJUt1SAmGjtGuHdb55yJbt0IKMdmx7Zt9Pt/K5OapOCxpI6WsLaV8WMCNzsefUvTw43h794LnZReMWbJkyQwBCB2tUQNy7r8L48wxSBh34MCB++vXr1+Q3Lw6Dkt4eZ43BPhALFteP/+m23BXrQXLBKEd5pWyZMnyP4sEpAfxOHrXztR67hlkl067HMf5qWVZM5ObV4eW/EIa2ggh6sfmL8BZsgz8PtB10IRaMmaP7JE9ske6QxNKbvj9OAuXEFuwECFEI8MwWiYLnFQcrvCqD+Du2g2apjqSJUuWLN+HhDDzdu8ueaVuxQapyVh4JXYTlbTyEh+cJUuWLEdCRTmSsTzicBtnyZIlS02hZgsv20HGYuqIRpHhMLKoGFlUhIxGwXHAdRO7ndntzixZ/peomcJLSmQshqiVi96qJXqLZuhtW2P06IY5eADmkEHo7dpAMAC6pgSYbat/s2TJ8j9BxoYrKaWQUt4uhPhj+KHHiPzpOUROTnKzI0NKZCSK0AR6105YY89Db9oEUbcOwrQQ9eqiNWoIuo67bAX27LnIwkK8vXvx1m3AWbcRCovANNS1XA+ha2CayZ+UJUuWGoAsLCJ4520E7rwdKeWtmqaNS25THTVH85ISTBOjUweMnt0IPfYQgV9eg3fgAFqdOhh9eqO3bYvIzUMEQxj9+xG49WaC9/2enOfHEbj/LqwzT0M0agABP6JObYwuHdFaNlfaWXZZmSXLj4qaI7w8D2GZ+G+8luCjD2L064csKsKZPQd77nzsRYtKm8p4HBmLJf7wkAUF6O3bE7j5RoIP30vgt78hcNvN+H56Hnrzpkq/zAqvLFl+VNQc4SUEMhzBXbEKo9fJ6jXLwnfxRfh+OhYRDJYJoHgMb8MG3MWLsRcsxFm+HG/9BrS8XHznn0fghl9h9O+DPX8h9qSpyL37kY6TvC2bJUuW/2JqjvDSNLBtYh98gjxwEAARCGD07Inw+TA6dy4VPiIYQgRDePmFCA/0Ro0RdeviRSJQopkVhzFP7onvwp/gu+pyzN4ng2NnNbAsWX4k1Bzh5XlIT2KdPgpKNgI0DVG7Nvj9FdtqGlrLFpjDhmL064PWuhV6u3boLVV0gbAszP798N98A8FxTxB8+D709m2RRcVZ7StLlh8JGT/Jx3S3UUqQEr17V3Kefxq9devkFkeG6xJ97iXCz70IsbiKq6qJeB6yuDiRXojKP0/pn2l+NiGUJmvoCNOs/vsKAXEbGS4G7xhopJqGyM1RfQGIxZV/HjL9dyAxLiwLEQwkn1H3KhIBO7U5QAT8YFmlf8visPIPzIhEP30WIhCoqLULAfG46oOs7vtIEAIRCoGhdsCREllYBK5TzXuOAAEEAoiSyT4WU/3zVD8qkcl4EiXjSS8bTyW/51HgSHYbU/S6IsdUeLkumCbBe+/Af83VyWerJxpFxuOIvLzkMxVwl63AWTCf2LsfYs9fpAZiTcPzEDk5mCOHoTdtgozFlfMtasAjpRqEEmTJ61XhechoDFlQgLdjJ+6GjcgDB9UDlCTEZCyO3qIZ1ohhStv1vArnjwhdR0ajxN//EHkoH3QdrXVLzH591MOQwfJd+Hw4a9bizJlX8QGUHsLvxxjYH715M2Q8nvxW1VYInIWLcdeuV36AuoE5qB9ai+aqTbo+JPrprlqjxo1plJ6S8Th6qxYY/fsqAelWce+EAAH219/gbv8OYRig6/jOPwetYQOknakQzQBN3Rtn7nzsufMBgd6hLdbggRAIKIFdMo4oGUsS6an7We14chxkJII8lI+3bTvu+o3IuK0mlKoE4mHy4xBelkXuq89hnn4asrCQ+GefY51/XtkskkCGw7hbt2B06Ii3azfepk3ofXqrGaEa7ImTif75rzir1yH37lOzYA1DhiNYo0cSevIxtBNPLH8macCVCK9qkB5E48iiQrzde/C+/RZ72gziX0xEFhaWfXcpkcVhfL+4nJzH/3BMfOHc1aspvOgK3B07EXXrEPr9HVgXX5S58LIsYh9+RPEd90BxuFT4ykgE65TBBB95AL1De2S8iizCAvBcin7xK+KTpyGkRNSvR96/3kTr2F61SdeFRD9jr/+N4rvuKzfeJbK4mMBN1xO44zaVXcWt4mJC4G3YQNFNv8VZtBTh96H36k7en19BNGqY3PqI8Q4eJHz3/cT+/S4Agbt+S/B3t4BefryXmwwrCK9qcF2lJOQX4O3cibNuA/aXE7AnT1Nj5ggF2JEIr6On/x0FSgeHJ5H5+YgqBri7bSvuMpVwUeTm4kWj2FOnJTergNG3FyIQxNv47TF5SI+YhHAyRwxDO7Fx0kmRyJemq0FoGAjLqv7w+RG18tCaNME4uSfWT8YSfPh+Ar+9GZGXW7o8lLaNdtKJmIMGHJt7IiXxL7/CK1C55bTGjbDOHKP6aJqV+13FAaDVro2WW04rlBJcF3PEcPT27QBR6X3qMyzctetx12yAuA2Ggdm/D1qH9srh2aziPclHST/z8iosq2XMRm/RHGPwIEQoB6FX831ME3vqTLwt25TWZtv4zjkTcUL90msdTZzFS7BnzAJNQ2/dEqtf3yTBRdl40tR4Emaa8RQIIOrUQWvRHGNAf/xXXkbo0Qfx/fS8Mm3uOFEzhJeUoGuIBicAIPJy8V1ycSVDvdy/H/vryRjdu6l2oSBabi7u0mUV2lXAcxF5eWqm0zKb8X9opG1jdGyP0aPH4SjDGSPyauG/4hLM0aOQdkJLiUYxunTCHH5KcvOjgiwqJP7FVypiIhTCGjIQUb9ecrO0CJ8fEQqVapvSttHbt8Xo00s9hCmIv/cR3r59CEMHXcM67xy1dDtc/FbFcROJoPfupZbAKZDhMPaMWXj794OuIxqegNGvX6Xl+1HBcXAXLMTbuh3sOOaAfui9eia3OipoLVvh/9W1iBPqHV1Tw2GS+tf/IZDKlqE1OAFRq5Z6TQg125VTSeWBA8TefV/FOrZvV/q6qFsXcnLwNn1b+lp5nDVrsWfPgVgs7WA/boQjmMOGopcsZ44FgSDmwP5qtnRcRG4uRq+eaHXqJLc8KjjLVuBt3gq2jZaXizX2vOQmGSGCAWWvKxEe4Qjm8FPQu3RKbloBb+8+7Nnz1A6zrqM1b6YE3vcwNgt/QIWZJbQ+rW4dzL6909panfkLcNdvUOPY8zCHnYLWtGlys6OCt/077NlzlSZatw5Gv96I3NzkZkcN0agheqa2w2PE4f+SxwIh0Fq3Qvh8yWcgYTuJ/u0faG3bYI06tcI5vXFDtHp1cZYsrfB6CTIcIfbW29jTZypH15qG66I1qK8Mvxn0L/7ZeCLPv0zsP+/gbtqUfDo1hgECZCyG3rYV5vChyS0qIQ8dIv7pZ0Re+wvRN97M4Pgb0dffJPrKn5HRGMKy0Dp3xOjSOfnSmREMKnOC5yXu1QmYA/qlvVf25G/wvtuRWCJpWKePRKt7WLnuShEBP+QoJ2kZiaJ364I5ZGBys0rEv56Eu2UrwvIBEuuM09BKJuhqkI6DPWWKuoevJ9/bao5//JPIS6/iLFsFQmL07I7Rr2/ypSvh7dhB7O//JPLiK8THf4ksKkpuUj2e2jQ5nmS8RjlmBvuE2mldcgGhB++rNCidOXOwZ83BHDpEed5XYSCMT/gKd+VqArf9JvkUzpx5FN1+F96qtSoLRQ1DFoexzhhF6PGH087K3o6dFF79K9yVqxC5uWitWpLz8L3oPXokN62EjMeJvvwa4YceB8/Ff8mFBMc9lXKjA8D+YgLFjz6B3LGzgstBtQiUTTgchpiNCIUIPHgX/ssuTW6ZEd727yi+537in4wHCdZZowk+9jD6SU2Sm1ag8OfXEP/yawQahILkvftPjJO/3zLKmT2Hwmt/jdx3EBmPE7jpVwTvuzvl8s/dto3iX9+CPX0WIhBA79yBnD+/hN6yRXLTCsh9+yi87Oe4m7akvH4FNE25oIQjEIsS+N0tBP7vd2nfH335VSIvvgrhCKJ2bcwRQwne/X9qNZMGd9s2Ci+4VC1T03xOKv67DfZSIiwLa9DASoLL3bgBe+YcrDPHYPTuVaXgAhCmqR6WKnCWLsXbsBF8GTx4xwWJOWQgWpPUDyNAfPyXuOs2IIsjyN17cOYuwF6xKiO7g9y3D2f2XPAk2omNMQYPSCu4AOIzZuEuXaHyqB08lP44oP7FVsZc0bB+JW35cBChACInpJa6hoY5eCB6k/K7sZVxlyzBXbMebBc0gdmnJ3qrw0qPXhG/H1GrltJYW7dQy+80D6w9ZRruxk0Iy0LaNtYZp6E3Sd6MSUJK7HnzcVatK72PGR37DkAkinRdtDat0fv1Sds/WVCAPWkq3rbvVFje5q3EJ0/NWPvy1qxNaLZVP5M/BMdXeCWWylqzk9C7diby6mt4+/aqU+Ew9jdTld9TORvX4eDMm6+2jW0n7Y95PJCxGEanjkojSGOLkdGoUu0LC9UyRtcRtXIx2rfNaADZCxZhz5oLnoPeri3mqSOTm1TCXbceZ+lydX3TVMvOVIdplh0APgtz+CloDRokXzpzAkFlsI+q5ZrRp3fa7xv7dDze7t3KUC8E1tlnprVPpUL4/Wi18pCRCHqPrhhDByU3qYB0HZwZs/F27gZDR6tTC2PwQLCqNouUIKMxpWG6jtJyk+9vVYdpqgpeuq42YXr3whzQP/nSlbCnTMPZsEEtaQ0DYZkYPbsjQulXUzI/n9i/3j7utVpTPzHHGgEIDW/XbuIffITRpjUiECQ+dTrepk14m7ehtW6V/K7KaHqZJEzgLFtG+LEnVHm247w2r5ZIFGNwf/TE7mkq7KnTcNdtQLhuqVOv/7KfYXTtknYAuatWE33uJQiHEXkJQ/0Jamc3Ffb0mbgrViJ8ltLuUh3JRlvPQ4SCWOefnbZ/qRA+nxJedhRj8CCMrqltZ3L/fuw585EFhcpQ36ih0pTSTA6pEAGl/Yl6dTH79UUEUtvbnHkLcFauAk0gHRdjyKC0y0UAb/t25epgO2o8J9/jVPfbcdHq1cPo27vSCqYq7M+/wNuWWPLZDqJRA/xXXY6oUzu5aQWk4xB770PiU6Yf9yI83/8XPVpoAllQSPT1f+Bu2Yb99USc6TOQtq1mzwx2CEVODpgW3oH9ADiLlxK+9yGcWfNUYsLjeIOrxXXRGp6A2bdPtRsV5Yl/8jnegYMQCKB36kDwwXsI3HIT+FPb8dwVKwnffT/uilVICVrz5pgjhyU3qxItLwfrzNH4rrgY3yUXVH9ceiG+Sy5Aq1+3LC23rmN07YzRMfWuYFqEANNCb9IEs3+ftD5p9jdT8LZuS0xoYJ46HNHwCB1CA37w+TE6tMMcOjj5bCXsiZNxN2xUv6vnYp1+Klr9NL5dUiIL87HGnIbvsosq3+Mq7rfRo2tC0CnNXO/WGXNgv+QrV8JZuAh79RqlPQQDmKcOI/eFZzAHDEgt5B2H+DvvERn3AkRjqdv+AGT8VB8zg30JrqtcJQwdLRRC1KmFaHIiuS8+l9Ze5W7YSPyz8Zinj0KrU4fwPfcT+/BThM+vEhHWQGRRMdboUwk99nBZuEo1yGgUe/wXeNEYRpvWaM2aop1QvwoHxHJEo8Q//4LI86/grl1XatT1nXcOOa8+r5YcaZDhRBxgBoPU3bSJomtvwP12C0I3EAEfwYfuwXfppdWPMsdBxqJplyqRPz6Ns3AhOS8+i0ijMRZdez2xjz8vDcXJfet1zCGDj2gCk4cOEX7wERAaoaceS3k/3M2bKb71Duwp0xE+P1rbluS+9hJ6xw7JTStRWpch4T6UCm/PHiKPPkns488Qlg8ZiRC45QaC99yZsn8A7rLlOMtXIGrlobdqhdaoYWojvZR4O3cSffUvxN79ELn/oFqqHgX+uw32Jei6Mj7u3Ye7eQvO6rWYpwxOK7gAtHp1EQE/7spV2FOmEvtkvJr1joXgkknqfLL6ngmJwWkM6IfWvFny2UoIy8I652z8F1+E0bcPWqNGFQWXlGrQx+N4+/YRe/9DCq+9nuK7H8Bds1YtDRwHrWEDdU8zEFwAIhhUDr45OWkPZ/ZcFUOZWMKLE+pjjhxRveAC3F27iE+anPxyJbRGDTBHDk8ruOzFS3HWrCutZWD06KrspSkEgYxGcDdtTP076jrGyd2Ve0QawWBPm46zcrUSKLaNdeoItGapd5FLEH6/up+5uZXub/Ih9x/Anj1XbVbF4+htWqloiTT9A9A7dcR30QVYZ52J3qljZcHleYmJJYa7eg2Rcc9ReMlVRN98S6WrOkqC60hJ/01/SMyEEdLz0Du0xxpzRnKLKhG1ayNq1yb23gfY30xThsSjaaAvJxzwPDVAEjM7nqeCfpMHf/Lf5ZCxOEbnDgkv8eofrFJKPq+att6hg4SffIbCq6+j4KyxhO+6H3vyNGR+fun7ZNxGb9kc89TMloyHg4xEiH/2JV5+QWlfrVOHo9VL7VHvrliBPWV68suVMAb2xxyRvt/2hK/xtm1HmMpGZ51xWmrfLtvGmTUbd/W65DMV0XWMAf0wB6f27ZKxKM6sucjde1UGhlAAc/BA5WR7FJHxGPbU6Xg7d6kxGI9hdO+KMSD9khES/n4pJjBn0WLC9z5IwdiLKPjZFUp7X7NWjfM0y/YfkpolvFADSjQ4geAtN6Qd/KUIgd6qFXLnbuITJ1edQuX74innSBEMIho3wujXB98F5+P/xeX4LrkQY0BfRJ06SrB4ygO7SmFWnlgMo18fjJ7dk898L4SuY0+djj1xCt6mzcpYXbJDKAS4HiIUQD+5J9qJ6V0yDhd7ylS8LVvVZyUyPljnnJnSL0weOkR8/AQ4cCj5VCX0Nm3Q27RJfrkC8tBBnLnzkAUFSuOuUxtzyJCUD5ssLCL2wSd4e/ZWOzGQMNjrrduk1fycWXNwliwH00TGbcxB/dHbtU1udsR4327BnjBRubo4DqJ+PYx+fTIy1GeCdBxin0/AnTMfuWu3sm+ZKVIrHSdqlvByHMjNJXDTLzFHpd/KL4/eqT3msCFqPX608DwQoHfuSOCe28n77H1y//U3Qn98hODv7yT08P3kvvUmoXGPozVqoLa4TROteVP0tq2rLsXmOCrGrW8fRBpje8b4A5j9+5VtnSdtUsh4HK1JE6zT0/tbyXBYGXS/nIA9cVLqY9Jk7G++IfbW23iHDiF0HTQNvXtn9I4dky9dAW/nLuzxX+FFo8mnKiNUeptUxCdNUSFihgmuizXiFLSTUvuDeVu2Yk+biTyYZsxk8PlID3vaDNz1G5TJwnUwRw5HO+mk5JaVcFatxJ40CfvriZXvcdL9dqZPJ/bRJ9jLVyohGVXuNplsJGSK0bUzWv06SlhZVo0TWiXUHOHleaBr+C44D98Vl6c2RleBCOVgjT0Po8/JEI1WLTgOh4TmZI0aSe5fXsJ/1ZXoJ52kfKxKfJ5MU+WV6tEdc/QozBFD8V99JTmvPIv/miuR0VglDUxGIpgn98Do26vC61UhDxxAHjqo7k0KhGVhDh+a2N2qoq2U6G1aKpeBNLiLl1B86x0U/uJ6Cq+7MfVx7Q0UXn0D9tQZCU8VAbqOdc5ZqZdKnoczbwHed7vUUjyVlpoJnoczeQrujl0IQ2mb1uhRSiOuDschPuErZGGh0taOEHfdepwFi5X27bkq11fPHumFXjRK+J6HKLwqs/tdcOUvib7057IAc0ND7941Iw3P27EDmZ9e01XVufqoPGBVjacawrEXXiUG7lRItdwy+vYhcMtN3ztZoNG9G8G7b0fv2hmkRIYjKnOqbScCkh21tZwITq62X1INbqNvLwIP34/WokXKjVmtYSNCD91P7j/fJHjf3RhduuJt2aayWJQfvJ4HhoHRtzd6i/R+P/FvpirH1OLi5FOV0Lt0VjUtk7FttBPqK5tRwn2gWqTEWbQEZ8Uq9RBGYxkc0TLhIyWiQX2VqSLFbO3t20fsywlgKB+jTL26q8NZtgxn5RqVEFBKtA7t0Lt2SW5WAXngoFq2xuLI/CMXXvb0mbjLVyACfmQshjV8GHqr9D6KzspVKmoiHFZjtdL9TToiiR1JIZR7RKtWWJlkBnEcon/7O86iJclnKiME5pDByvziHKEScAw5dsJLJJaBtg2eh4xElSbiOOohLj/beh6iXj2Cd9yKdoQ+OebwYeS88Cd8F5yP0aEdonFDRJ3aiNwcddTKVamJA8pxVYYjqoxahf64EAoSuOXGtDF0pYhE6mXAWb6C+ISvleG4HDIWw+jYHjMTw6rnYU+eQuzjTzPSDEQohDl4QOmGRwklebusDDzqvT17sBcvVe83ExsSmRwikWpIExn5NHnfbsaZPQ90DWnbKkniERCfOBlv82blTOs4WGecntqrX0rs+fNxt2xDui5efn5yi8NCFhbizF2g/PA0DeH3YQwdmNbhEyD+1URkOKzGSvJ9reow1NIcAMfF6NwxI0O9vXQp8Y/HKx+4DDB690LUroVMlajwOHPshJfrIXJzME8ZjHXeWZiD+qE3O6m0hJmMRJFFRSqnuOvi+9lP0HumDzDOBL1zJ0LPPUPuO/8g9PhDBG7/Df6brsd/86/x33Ij/pt+TeC6q7B+eh7GoH4q5sxxVHm0xL++c8/E6N07+dLV43nIQ4dwFi0m8txLOGvWq4FWHtvG6NkdvUd6Q727di3uyjU48xYh9x9IPl0J4fNhnDKkYoFdN5EuuUe3jFwynAULcWbNAQQyFsvoKBWUngc+H9aY0ak150gEe+JkpUVomsoDX/D9hZcsKMCZtxDvUL66Xl4O1imDUxqvZSxG/OPP1EQqpUpTfQTYs+bgLFqsHIajMYx+vdE7p7b5kRB69teTVRyjY1e6t1UdJU6pylBfV20YpfiuJThTZ6jkjOvWZ6TpanXrYnTrgrCScpnVII6Z8JLRGL7zzyHnzy+R8/Lz5L7/b0J/egL/Ddfiu/gCrLNGYw4ZhNGxPaJhA6wzR2fkaX44aE2aYJ0xGv8vriJw068J3Hg9geuvU+l777ydnGefptZ7/yL0xz8or3OpUuOapw4ncOftiFAQb+s23FWrE7ngqxciMv8Q8U8/p+jm27C/+Kryd7FttAYnYPTPbFco/uVE3C1bkQfzcTam8UNCaX5Gj+5o9euVtbXj6t6eNSa5dWU8D2/7DgD0Nq3QmzdLf7RqqZYWCQFmdO2S3lC/dy/xCROVoBGq3J0sTK9ZVoc96RvcdeuVYdlxVF60NEHY3tZt2LPnJaIBJBQUVm9CSIfj4Myeg7vxW4RlIl0Ha9gp6M1TOx4DuBs2gKahNWuK3qJ55fubfLRorirCS6kM9e3aYo4YnnzZSnj7D+DMX4SMRHGWrcTbsTO5SWV0HWPIYBVad6T242NE9YacJA7Lw15KZCRC3pt/xjx7jJL0JR705YnFcNauw122HHPoYLRm6bWDY4U8cIDIk38Cw8B31eUgUe4Hn43H3bYdkZeH0a0LetfOaC1boNWpozQM00TGYrhLl2JPnkJ84hSI2aUFEUqvX1CINWo4waceL0viVg2yqEjlXp8wEfw+/NdcSfD/fpc2uFiGwxTfcTfxjz5Tv0E8jjlsKHlvvZHSbQEAx8ZZtQa5/buUPkClCIG040Se/BPuitVgmoQefQDr0ourz1bhecQ//4Ki624ETUsUsWhJ6LEHM3oIK+E4FN9+N9G/v4Xw+5GOrUwGPx1bvaFcSiLjnify7EtKcMZiGJ3akzf+I0TO4Sfvc1asIHz777HnLUCYFlqjE8h56VmMgQOSm1bC27IFZ8NGRCYBzkIgXRd74iRif/s3UhP4r76S0KMPJbesRPzDTyi+/yG8nbsROTnkvvEK5rD0djJv40byx16M3L0npcvJkVBDPewl3kGlqdiLFhN5ehyx/7yLt0/FHwLg82F064rvskuOq+AClZE1+NjD+G9SQqPouhsovus+7Jlz8L7bibtqDdG33qH49t9TeNEVFF55DUU33ELxLbcTvu0OIo89pTICxCsLLqQEy0Q/uWdawUUiNs5Zt0GV3NJ1NWtmsLQRfj/mKUPUH3EbUac2vlHD0wsuAMPE6NYVc8xozNNOTX+MGolWqxZeUTHS9ZShfsig6gUXIIuLiX82vsz1QAglQL7nstFdvQZnxUp1fz0Po20bjB7dUwoCr6AA+8uvEpl1VR+k7ag0Pt8DZ/ZcnGXLlfCMRDCGDUVvn1lGXK15c6yRIzBPH1X5/iYfo0Zi9O6J+90OZDymqj6dlt6OiW1jz5mLt3U7wudDHjiosrtmoE2JpgmXn/KmiBrEsRFeQoBUZZhkcREUFxN772OKbriF8H0PYk+fiYxl4N9zHHCWLif6/Cs4i5aoB7HEz8UwEIn6fcKykHv3465YrTIILF6Gt/cAmFbVD040it6+LWaaVCqgYjztb6bhbU94iguBu2Yt3s4MVH1Nwzi5B6J2HtKx0Rs3xDzj9ORWRwlJ9J0PkNt3IEwDa9QIRONGyY0q4G3/TmVNQI0RIYSqbv49DfbxyVNUpg2f2uEzx5xeRQGTijjz5uNs2qweRiHU4sNxkYcOX3jJ/ftw5sxDFqpixiIUwBw4AFEvhVf/90Uq9xJ76kzlS9ehfUbZUt2Vq3AXLS3bWLFMnMVLVV79NAjDUGPWqsYF5zhzbIQXgGnirFmL+90uNctpqnBl7N/vUXzzrUSeeBpn5qyM/E5+SMyB/dUDIKpJ91GiMei62pEryV9VXRyllEjXw+iTWZ4ld+1anOUr1WApcbWIxnCWLU9uWiVa06aY/fuq3cdBA9JmZ/2+OKvW4CxYiIxEIRTEOv9cRDCFb1fCE18ezC+7r6Kk6G0kuWlaZFERzrwFSmPSBFr9epijRqT2LwNiH3yi3Dv0xGZKYldcFlWdzDIV9twFynYWDEI0hjlogMp8cQyQBYXE3/0AojG0Rg3VZJFqYySBPXMOzqrVpTZYYRg4i5aktN+WomlYp46sYNesSVTvjJPEAw88IIBBQohR9tQZOHPmqp2IahBSuRz4xpyOd+AA9sRvIB5XfjD5RdjTZ+LMmYu3dSvk56tCqdEocseOare5vT17AOWUeawQlkX8nfdVjNzR+BzPQ+SGVFLFVi2QBw4i8/OrPoqLiP3rbexvpiFEmesFqLhPvVVLtcw6dKjye/PzkQUFyIOH8LZtw930Lb6x56DVro08VEXb73sUFCALC4n++Q3l7oBEb9UC35gzwFUaTKX3FBbibt5M9KXX8HYnQnFKBZgSuEb7diowP/m9VR3FRdhffEn80y+QkQjCk5i9e6jYQ09W7kNBATK/AHfNGqIv/0UZ6BN2PSEl+Hzo7dug1a2LzC9If78KC/H27SX+7gfYU2cgAgGl+Z1+Kmavnuoaye/5vkeB6o8zew7R115Xvl1tW+E7/xxAVN/XwkK8Hd8R++e/cVesVs7VqAnD239AedHXqZ36+xYUQDxOfOIkNelkEPR92MTjmIMHYA4eBDDhwQcfnJPcpDqqUC2q5rAM9qB2cXRB7j/fQPhMCq+9EW/7d+o9Jetnx0FGowifhd6hvapnF40Seuxh9C6d8XbvRu7andgmVmXijW7dKxv+jzIFZ52PPWseIpR+VzAtnocIhdDbtlalv1I4/QnTwFm6XAXclrcdSYnIzVEZAELBqqszU/Zryr37cL/djN6jWyKRYHLDI0CoGdlZtFiFYuk62omN0Fu2VEvsqmZoXUMWF+PMX5hU+TpROarJicpDPAM7DCX3acNGVZ0INda0ls3QmzVV4UHJfUh8nLdvnwrCLp/mR0qEaaK3bllWCDadeUfTVDaKdevx9uxDGAbScTC6dEJvepKqdn60EKo/3vbtuOs2IpGqYEv3bup7VtdXXUMePIS7fgOyoKjCykA6DkaHtip0SapCxlWiCXBdnNVrVKrp0qX20eNIDPYZ9+SwhZcEGQ2T+4/XMYcOJvzoE8T+/Y7y7ylR2VGOdjIaRUYianlpmlhjz8Y39lzlVGpZoBmgCfQ2rTPK9X5ExKLkn/UTnIWL0y5BMiax86fS5iafLIdECZuqdvs8T/n5ZGI4NQyVKqW8H9ZRRqUcSvyOrqu+X6q+CeW8WeXgtx2kfRgPvFR1CyqkZnEcVZMyVR80HWGZiQe2pJ1ysJV2ye8jqjcBlEeoYrcYRtlDHYshbSf1b1yClBUnofKfm4gUKEXXyuyvImGji8XSS1lNSzw/VXyfeFz5NaZFqDFZ/pk9itRc4VVUSO6/3sQaMxpv924KL74Se/qsRCI9XXnf5+WqGavJicoVICeEyMtFP+kk9E4d0Vq3TOSI+mHwtm+j8NJf4KxYfXSzU2Q5vniesq3pGlqtvMQOWlIbTSiZEfkBNpOkVMJcV5tbEmXbxFNZaIVlKou0BOl6ahf7R0jNFF5IiMXx/ewCAnfcinbSSURffk3ZupYux9u3H/3Exvhvvh5z0ECl8meaa97z8PbuVYnZMtSOvK1bcZYsQ0bCmKcMVQn9qsBZuJCiG25TTof+o+s0m+U44XkgBOboUzEH9EerU7tq4SU94tNnEf/Pewkn2owfj8xJaH3myGFYZ51RWh8g/vVk5WoT8BP83S0qgaFI+B8++yLe9p1Va1D/5RyJ8DqGd0OAZRH/+DOKbv4tzuIl+K+7mtDTj+O75EJEKIgx/BT8V1yG3q4tsrAIe/Zs4hO+xpkxE3f1GmXzcirOODIWxVmwgOirf4FqlhqyIB9v69aKYRCmqZahmiD61zdwly4r/5ZS5P6DKtNBsq9Wlv9OPA8pJf5rriT0hwfwX/1zrLHnYZ17DtZ5Scf556nK2F4ik2g4jCwoVAbtQ/nKuF1UpMZHMtW1D4fVMlAI1Sa/AFlcjO+KS/Bd+FPVj/PPw9u3H1lQgBYKqZVI61bobVoj6tXD27UnsQlQoK5fWFTO0F6gYoaT+1IcLjX2l2yylGxcyPz8su/gushIpOI1S95THE5poz3eZPyEHr7mlcD1kPmHMEeNIPSH+9G7dMHbvp2CCy/Hf8Wl+H91DdK2iT49jthHn0DcUZVa8vJUOtxauUq7EkJlAIhFcbfvwNu0GXPEUPTGjSCvljKiFiZ223bvRsbj+K/9BdbIEck9ouja68EyCf3hoUrBs7H3PyL80KMqCdvR2G3MchxRdiWjVw9y/voyWoOyoH9v1y7sSZPLEjcmduFif3sLb+8+tBbNMHr1RG/aFFG7ljJzRKN4u3fjzJmPuzYRkuS6yGgMrXlTjD4nozdrhqiVq7SkwmLcDRtV1tP8AvRmTTFHjURv0hjfZRcjaquxJ8Nhoq/+FWfJEkTt2vhGnw4+SznUTv4GonH01q2AhF9cNKKWvjkhKA5jz5iNM3+BOh+LoTVrgtmvH1qLZojcXCW4iorR/AFlo/P5VH6wWXPQGjXA6NkDrZWKGsHvUzu2RUV4m7dgz5yjJvTkON2jxJFoXsdeeJXgOOidOmAOG4rRtxeRR57E6NqJ4J+eRFgWzrz5RJ59gfhnE9TMZxggy+WKJ2HUFBqYBsK0kOFilW43EFTCq8Toj0A6DoGbfknwwXsrlaqKvfUvIk89R/CRB7DGjK5wLv7RJxTf8xDe7j0IM5GhQdMzM+JmqVl4yvAdeuIP+C69uHQZKIuLKf7dndiTvlE7gyWuG9EoIhjE9/PLMEcOR2/VspJ5QRYW4K7fSPTlPxN7+320Rg2wLhiLdeYZ6K1boTUs5+YjpSrr9/EnRJ59Cd/Yc1WBjKr8s6JxwuPGYY0Zjd6yFcIwcDdsJPzkU4QefzSl860zey7F9z+Ms2wF/gvOx/rZBeht21RwOZLRiHJ61nRwHQqvuhY0Hf8Vl6K1Uf2umBxT4u3dh71wEZGHHlM7u8dgKX0kwitjcXq4fl6VEAJv23c4ixbjLl+B3LMX99stuMtX4O3aidG3N76zxqCddKLSoPbuA09lRRCWBZalUjH7/WrnRdfK/p+wIwjDVB7wfj9C1/G+24nevCl6h4qVW/SmJ+EsXIy7aLHKMZ5bJoRFMIA9Yxbe1m1o9eqocB7H+dEaTH+0SEB6aI0aELjtFrS6ZYkJnZmziDz1HOQntC5XGfO1OrUJ/P7/8F93tQo6z8nBWbCQ6MuvQTCgklH6fGiNGwMSd80a/NdfS/CO36I3a4rICRH7zztExz2P3qwpWuNGCReXDsS/mojRvq2q1JOXp7LOouJ73ZUrcdasxl2+Ct8FY9VKw9Bxly/H278f33nnlvbdnjOX2F/eQNSuXSpYRW4O7vLl6O3aEnzwXowO7RGhkKow9NyLyN27Mbp1SwgfsGfNRh46ROD66zD69karXRvheYQff5rYu+9h9umFCIUQoRBGmzbKS3/12rJd1aPJEfh5/XDqhBCIUBCh64mS9cXIggJiH35C5MlxFP7iV8Te/QDfxReS8+I4ct/+JzmvPIcxZCDGoAFYw4coTSzZF0gkvN11vaKdyudD7t5D+MlxxL+eVP4diDp1CD7we6hbh9j7HyCjZR7eWrNmhJ54hLz3/kXuG6+R88KfCD1yv9Iy7awA++9BWeON4UNViu6SV22b+Kefq3FUzgVA5ISwzjsL/+WXlHque3v2EnnuRVXuK1ETtBQrEXc6cw7Ft/yOot/8luLb7yT2n3dU/G75ZzwRRxn9x7+J/eddCJd589vTZ1B0xz2EH3hUhXYlqmp7Bw4SnzEL6/TTStt6u3cTeeIZYu9/VCEe1N30LVqDEwjednOFXGrxDz8hfN/DOOvWq2en5PXPxmP0Ohm9Q7kYTCHQauch9+9XxVyuvJrCn15C4SU/x567oEw7rUH8cMKrBE1pTCSqzIhgCFlUjDNnHuE/PkP4wcfQmp6EOXwovosuIOf5Z8h59ilCzzxB6OnH0Vu3zNx3ye/HXb+R8F33EXn8CdyNG0tP6a1bE7rnTrzNW4iMe0EVYUhgdO6EOWIYRv9+6F06Y/TtrewbqXyIstQspEqO6DtzdIUURHLXLuxps9REJBI+XnEbrUF9tbQs58/krV9P/PMJ6J07lmgGpbhr1uAdOKBsRn164Tt7DL6x5xF69GFyXnkevXNZsV1nzjzkrj24679Fa9q0grkl9sHH2HPnI/MLME8ZWrqjKHftwtu8VY29BO7qNdiTp6J37oTR++Sy17dvh9w8tLZlqaC9nbuIT56C1qghRu9eytwCyN27cZcsx122TK0oSjAt/NdeTejpJ/Fd8BN8F/0UrcmJxL+ehLd23bHRuo6QH154JSMSO4E5ORCJEnv7PQovuoKia35JweVXEX//I2Qkglccxtt/APyHt1QVlg93y1Yir7xO4c9/SfEdd+N+uxlQ+b5kNEr0+ZcpvPwaim+9nci454i9/S7eDpXbikSWBxkO/yi3qn+UJMwIRudOKr9YyUMnJfbsOXh796pdNNdVSf10Db1dW4wuncsuEQ4TnzYDQMWK5pVFdbjr1iHDYUKPq0IsvssuwTx1JKLBCSoGNRZTnv4J4l9Pxt3+HUbnDiqEKeGE7G7ZgjN/EZpl4RtzGloDVZ1IRqM4S5di9Oxeaq+VRUXEJ32DyMlR2TsSAtnbuw+5/wBGUlFbZ8ECnNlzsUYMU5W1E8RnzFLPw1/+RuGVVxN58mniX3yJu+lbsCy0xo0w+vTGGnMGgQd+r2pC1NCJu2Y9jQkDuT1zNrGPx2N/PoHIn56n8KpfUnTVdURfeAV3U8JwmClCpYohHsddsYro638n9vqbePn5yHAYb/deZH4BzvwFxN5+j+gLrxF+6HGKrr1R1aoD7ElToLj4mHkZZzkGSIkxYmjFgqqJEnnW+WdjnXsm1jljMM8Yhd61E3qLZhXGlbdvP/aMWRjdu2Kdc1bZNaTEnjkLrV59rHPPLt0xjH36OYWXXkX0zX/ilUuv427erGoChMOYo0Yk7GUKe+I3eHv3gd+PefaYUqEm8wuwZ8zEGlOWEUTu3kP8k/HorVpinVa2g+6uXoO7fn2lzK3O8pWQX4g5elQFw7236Vt8F19I8IF7MYcPQ2vVmtjf36LwZ5cT//iTCqsaYRoQjpT6ydU0DkMK/EBomjK6+3yIUAgZjqj0tWvWq5xWmZTKqgpdVy4YQHzSVLxt3+Ft3Yq3Zx/4/CpmUKgYPLl3L/bcecQ++hR56CDu5q2JsI+a9wNmqYKEkqA3UQb28hi9exF66H5CTz+uStjdezeidi3crdsrhMvojRoSeuRBcl55TlXdTtjLoq+/Sexf71QQQgBmD1X8JfTYwxU0OGfKNLwtWxGhINbo0xB5iYSH0iP+xQRkOIzevQtG97LU4Cofv79CrUpn0WK87d+pKuBtVX8AnBUrsecsqJTa2XfBWHI/fx/rnLNLnQqcFStxlizFHNQf/5WX4r/mKnxjzyVwx20E77sLo2+fsmVrNEJk3Au4W7YdnrLwA1Ize0XCEE8iTi/gV1HxhnHkN9KylBCMRHA3bELu319WRiphh8OyEJaFt3YtMpJYApTEw9VA9TlLEkKNn/iXX+GuXKmWhyWHlGq3L1FlXWnkq7FnzSFy9/04i5colxvDxOjRHb1dO9ytW4m99wFFv7yRyGNP4yxdQezjT3AWLoRIBFxPpSIaOhi9Qzulobsu2A721Jl4u3aj9zpZ7Vx7atPJmbcAd/1GhKZhnTpCedq7rtK6ps/EGDRQjTXXVamzP/8CrWEDjCGDSosbezt24CxchLt0OZFnX8RZtQrisUTK8QYYvU+ukFzAnjYde+Ycoi+9Rnz8eLxDB0EIjJ49sc46E1G/Hu6GDUT/8zZFV19P9I1/KGfWGrriyFiVOGI/r5qCbaM1b0ruG6/hrFhF+PcPIPMLVJBvOdsIUmIO6EvOqy9iz55D+K77lIpv6Im1aMa3LsvxQtfR6tUtrRRVJdGYyuIhldlCq1sHQqFEXKtQ2UzCEaWR5xcoW5mhcrlpdepAKFi6OynDYXWdkl1vCd6u3RCJKIfrunXK/AVLbLhSqroDJULGVYVcRE4O+HzqIo6r0kFJqarI+30q5jESQatXB6NrZ0Cqit6ahrt8Jd7+AwTvuA1z+DB12a1bKb7t/7AnTlErkNq1VHhdIKA+x3UT5ddiZd9VyqqTBBxFjsTPK+Mn8EcjvOJx9I7tCD33DHq7NhRd9UviE79RW9TlXS1cF71ta3Lf/w9a/XpEnnoGZ/EypPRwZs5VgzgbQlSz8TyVaSLV7rSmlS0tXU+Fo5XfWZMSECpsSC9XdszzlClBlrMHlWjl5bTz0uwbrouM22UuCyUZLkQiFbbjKkElhFoJeB6yxC2oJINFSVvXVcIrXIz/55cTeuox1S/bRkai2NOmq53Ws85ULkOHDhJ+5I9E33oHgVDj1nHKXV9Tn5343qJkBfIDTNBHIryOcA32X4hp4m7ZSvzd95EFhQRuuA7/zy9H79ZZaV/lBrq7Yyf2nDnIQ4fwX3cNOX99hdDjj6C1aaUGYXYJWbNJCCYRCFR/lLeJ6Yn2fr/6t+T/fp/Kr1beZKFpKi14pbb+CtdHS+R/T9RzLPvccinDTTNhGlEO1qWmi5K2Ja5FQsULi0AAEQwgcvNwliwl/sWXAIhAAK1+PayzxmCdMRrpONjTplF0w63E/v2u0lT0xHUS1d5V/60K3xuz3CqkBpNxD380mheJmVEI9A5tCT36EEavk7HnzaP41jtxN2xUgyWB8PkgJ4h1xmkEfnsLWr16RF56hcgT4yomtcuS5TghLBPRpDF6q1YqY4ZhIPPzcddtwNuxUy0HPVkjbVdZzetwEYkMkYuXEX3hZdxly9FOqK+Mm0lLDFlcjNy5m9hb71B0/c1E3/gbsrAoK7Sy1AykRIajeOs3YU/8hth7HxH7z3vEx3+Fu3a9GqskolB+ZPzvPoG6jvD7iU+cQsGFlxO+72Hk/oOV4zUTKjyuizNrLuEHHyX6yl+zWleWmoEQagOhxLBePpGBbvxgtqvjwf/20ycSdfuKirCnzMDbt6/63ZUSm4PjZmMcs9RMRKJoS8lY/XHKrFK+p/BKkbT/vw2RUKkzmZ3KD44sWbIcBSr4TmbwEJaR8VMohJBAMagUHJWyO/y3k4nwypIly9HFdRE5KpW7EKI4+XQqMhZeAC5skVLaZvduiBPqIb9vqE6WLFn+55HRKKJhA4zu3ZBSxqWUW5LbpOKw1A3P85oDrwjPHR156k9EXnhNeeKaxuFeKkuWLP+zSLAdRO08Ar+5nsBttyLhs2g0ekMwGEwU40zPYUsc2/bO0HT+qkmvcfzVvxKd8LVKjKYckbNkyZKlehJyQuTlEhhzOua1VyPhO+AXmqZ9ldw8FYctbqSUmpTyQuBOIUR3kLDp27IKKVmyZMlSHTLhLNuqBSDwpFyiCfEo8F7Crp4x/w/Ui9D7ZR3SFwAAAABJRU5ErkJggg==";

// server/routes.ts
await init_storage();
await init_db();
init_auth();
import { eq as eq5, and as and3, gte as gte3, lte as lte3, lt, not, ne, sql as sql4, desc as desc2, inArray, or as or2 } from "drizzle-orm";

// server/middleware.ts
init_auth();
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Sess\xE3o expirada. Por favor, fa\xE7a login novamente." });
  }
  const token = authHeader.substring(7);
  try {
    const payload = verifyToken(token);
    req.user = payload;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Sess\xE3o inv\xE1lida. Por favor, fa\xE7a login novamente." });
  }
}
function roleMiddleware(allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: "Sess\xE3o expirada. Por favor, fa\xE7a login novamente." });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: "Voc\xEA n\xE3o tem permiss\xE3o para acessar este recurso." });
    }
    next();
  };
}
function agendaScopeMiddleware(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: "Sess\xE3o expirada. Por favor, fa\xE7a login novamente." });
  }
  if (req.user.role === "assistente") {
    req.query.userId = req.user.userId;
  }
  next();
}
function reportsScopeMiddleware(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: "Sess\xE3o expirada. Por favor, fa\xE7a login novamente." });
  }
  if (req.user.role === "assistente") {
    req.query.userId = req.user.userId;
  }
  next();
}

// server/routes.ts
init_schema();

// server/seed.ts
await init_db();
init_schema();
init_auth();
import { eq as eq2 } from "drizzle-orm";
var REQUIRED_ACTIVITY_TYPES = [
  // Efetivo (Verde #22c55e) - 5 tipos
  {
    name: "Termografia",
    category: "efetivo",
    color: "#22c55e",
    icon: "Thermometer",
    description: "Termografia",
    displayOrder: 1
  },
  {
    name: "Visitas t\xE9cnicas (Preventiva ou teste)",
    category: "efetivo",
    color: "#22c55e",
    icon: "ClipboardCheck",
    description: "Visitas t\xE9cnicas preventivas, inspe\xE7\xF5es e testes em campo",
    displayOrder: 2
  },
  {
    name: "Treinamento t\xE9cnico (Ministrante)",
    category: "efetivo",
    color: "#22c55e",
    icon: "Presentation",
    description: "Treinamento t\xE9cnico realizado",
    displayOrder: 3
  },
  {
    name: "Especifica\xE7\xF5es t\xE9cnicas",
    category: "efetivo",
    color: "#22c55e",
    icon: "FileText",
    description: "Elabora\xE7\xE3o de especifica\xE7\xF5es t\xE9cnicas e documenta\xE7\xE3o de projetos",
    displayOrder: 4
  },
  {
    name: "Visita t\xE9cnica (corretiva ou RCs)",
    category: "efetivo",
    color: "#22c55e",
    icon: "Wrench",
    description: "Visita t\xE9cnica corretiva ou resolu\xE7\xE3o de casos",
    displayOrder: 5
  },
  // Adicional (Amarelo #eab308) - 4 tipos
  {
    name: "Suporte t\xE9cnico \xE0 dist\xE2ncia sem deslocamento",
    category: "adicional",
    color: "#eab308",
    icon: "Headphones",
    description: "Suporte t\xE9cnico remoto por telefone, email ou videoconfer\xEAncia",
    displayOrder: 6
  },
  {
    name: "Documenta\xE7\xE3o (Sistema da qualidade)",
    category: "adicional",
    color: "#eab308",
    icon: "FileEdit",
    description: "Elabora\xE7\xE3o de RATs, RADs, checklists, organiza\xE7\xE3o de agenda e carta t\xE9cnica",
    displayOrder: 7
  },
  {
    name: "Treinamentos (Aluno)",
    category: "adicional",
    color: "#eab308",
    icon: "GraduationCap",
    description: "Participa\xE7\xE3o em treinamentos internos/externos como aluno",
    displayOrder: 8
  },
  {
    name: "Tempo de trajeto ao cliente (planejado, inevit\xE1vel ou necess\xE1rio)",
    category: "adicional",
    color: "#eab308",
    icon: "Car",
    description: "Tempo de deslocamento inevit\xE1vel e planejado",
    displayOrder: 9
  },
  // Perda (Vermelho #ef4444) - 2 tipos
  {
    name: "Tempo de deslocamento ate o cliente (Excessivo, Mal planejado, ou evit\xE1vel)",
    category: "perda",
    color: "#ef4444",
    icon: "AlertTriangle",
    description: "Tempo de trajeto at\xE9 o cliente - inevit\xE1vel, planejado ou necess\xE1rio (calculado automaticamente)",
    displayOrder: 10,
    isAutomatic: true
  },
  {
    name: "Aguardar Cliente",
    category: "perda",
    color: "#ef4444",
    icon: "Clock",
    description: "Tempo de espera por cliente, materiais, libera\xE7\xF5es ou integra\xE7\xE3o",
    displayOrder: 11
  }
];
async function seedActivityTypes() {
  try {
    console.log("\u{1F504} Sincronizando tipos de atividade...");
    const requiredNames = REQUIRED_ACTIVITY_TYPES.map((t) => t.name);
    const existingTypes = await db.select().from(activityTypes);
    const existingNames = existingTypes.map((t) => t.name);
    for (const requiredType of REQUIRED_ACTIVITY_TYPES) {
      const exists = existingTypes.find((t) => t.name === requiredType.name);
      if (!exists) {
        await db.insert(activityTypes).values(requiredType);
        console.log(`  \u2705 Criado: ${requiredType.name}`);
      } else {
        await db.update(activityTypes).set({
          category: requiredType.category,
          color: requiredType.color,
          icon: requiredType.icon,
          description: requiredType.description,
          displayOrder: requiredType.displayOrder,
          isAutomatic: requiredType.isAutomatic || false
        }).where(eq2(activityTypes.name, requiredType.name));
      }
    }
    const extraTypes = existingTypes.filter((t) => !requiredNames.includes(t.name));
    if (extraTypes.length > 0) {
      console.log(`  \u26A0\uFE0F  Encontrados ${extraTypes.length} tipos extras n\xE3o configurados:`);
      for (const extra of extraTypes) {
        console.log(`     - "${extra.name}" (${extra.category})`);
      }
      console.log(`  \u2139\uFE0F  Para remover tipos extras, delete-os manualmente ou via SQL`);
    }
    console.log(`\u2705 Tipos de atividade sincronizados (${REQUIRED_ACTIVITY_TYPES.length} tipos obrigat\xF3rios)`);
  } catch (error) {
    console.error("\u274C Error seeding activity types:", error);
    throw error;
  }
}
async function seedDefaultAdmin() {
  try {
    const [existingAdmin] = await db.select().from(users).where(eq2(users.email, "admin@astec.com"));
    if (!existingAdmin) {
      const hashedPassword = await hashPassword("admin123");
      const [adminUser] = await db.insert(users).values({
        email: "admin@astec.com",
        password: hashedPassword,
        name: "Administrador",
        role: "admin"
      }).returning();
      await db.insert(technicians).values({
        userId: adminUser.id,
        name: "Administrador",
        email: "admin@astec.com",
        phone: "(11) 99999-9999",
        team: "Administra\xE7\xE3o",
        baseCity: "S\xE3o Paulo",
        color: "#3b82f6"
      });
      console.log("\u2705 Default admin user seeded successfully (admin@astec.com)");
    } else {
      console.log("\u2139\uFE0F  Default admin already exists, skipping seed");
    }
  } catch (error) {
    console.error("\u274C Error seeding default admin:", error);
    throw error;
  }
}

// server/routes.ts
init_geo();

// server/ws.ts
await init_storage();
init_auth();
import { Server as SocketIOServer } from "socket.io";
import { z as z2 } from "zod";
var socketLocationSchema = z2.object({
  technicianId: z2.string().min(1, "technicianId is required"),
  latitude: z2.coerce.number().refine((val) => !Number.isNaN(val), { message: "latitude must be a valid number" }),
  longitude: z2.coerce.number().refine((val) => !Number.isNaN(val), { message: "longitude must be a valid number" }),
  accuracy: z2.number().nullable().optional(),
  battery: z2.number().nullable().optional(),
  gpsStatus: z2.enum(["ativo", "inativo"]).default("ativo"),
  connectionStatus: z2.enum(["online", "offline"]).default("online"),
  deviceModel: z2.string().nullable().optional()
});
var io = null;
function setupWebSocket(server) {
  io = new SocketIOServer(server, {
    path: "/socket.io",
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    },
    pingInterval: 1e4,
    pingTimeout: 5e3,
    transports: ["websocket", "polling"]
  });
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token || socket.handshake.query.token;
      if (!token) {
        console.log("[Socket.IO] Connection rejected: No token provided");
        return next(new Error("Authentication required"));
      }
      const decoded = verifyToken(token);
      if (!decoded) {
        console.log("[Socket.IO] Connection rejected: Invalid token");
        return next(new Error("Invalid or expired token"));
      }
      socket.userId = decoded.userId;
      socket.role = decoded.role;
      console.log(`[Socket.IO] Authenticated: ${decoded.userId} (${decoded.role})`);
      next();
    } catch (error) {
      console.error("[Socket.IO] Auth error:", error);
      next(new Error("Authentication failed"));
    }
  });
  io.on("connection", (socket) => {
    console.log(`[Socket.IO] Client connected: ${socket.userId} (${socket.role}). Total: ${io?.engine.clientsCount}`);
    if (socket.role === "admin") {
      socket.join("admins");
      console.log(`[Socket.IO] Admin ${socket.userId} joined admins room`);
    } else if (socket.role === "assistente") {
      socket.join("technicians");
      console.log(`[Socket.IO] Technician ${socket.userId} joined technicians room`);
    }
    socket.emit("connected", {
      message: "Socket.IO connection established",
      userId: socket.userId,
      role: socket.role
    });
    socket.on("location_update", async (data) => {
      try {
        console.log(`[Socket.IO] Location update from ${socket.userId}:`, data?.technicianId);
        const parseResult = socketLocationSchema.safeParse(data);
        if (!parseResult.success) {
          console.error("[Socket.IO] Validation error:", parseResult.error.errors);
          socket.emit("error", { message: `Validation failed: ${parseResult.error.errors[0]?.message}` });
          return;
        }
        const validatedData = parseResult.data;
        if (socket.role === "assistente") {
          const technician = await storage.getTechnician(validatedData.technicianId);
          if (!technician || technician.userId !== socket.userId) {
            socket.emit("error", { message: "Unauthorized: You can only update your own location" });
            return;
          }
        }
        const location = await storage.createTechnicianLocation(validatedData);
        socket.technicianId = validatedData.technicianId;
        const normalizedLocation = {
          ...location,
          latitude: parseFloat(String(location.latitude)),
          longitude: parseFloat(String(location.longitude))
        };
        io?.to("admins").emit("location_update", normalizedLocation);
        console.log(`[Socket.IO] Location broadcasted for technician ${validatedData.technicianId}`);
      } catch (error) {
        console.error("[Socket.IO] Error processing location:", error);
        socket.emit("error", {
          message: error instanceof Error ? error.message : "Unknown error"
        });
      }
    });
    socket.on("disconnect", (reason) => {
      console.log(`[Socket.IO] Client disconnected: ${socket.userId}. Reason: ${reason}. Total: ${io?.engine.clientsCount}`);
    });
    socket.on("error", (error) => {
      console.error(`[Socket.IO] Error for ${socket.userId}:`, error);
    });
  });
  console.log("[Socket.IO] Server initialized on /socket.io");
  return io;
}
function broadcastLocationUpdate(location) {
  if (io) {
    const normalizedLocation = {
      ...location,
      latitude: parseFloat(String(location.latitude)),
      longitude: parseFloat(String(location.longitude))
    };
    io.to("admins").emit("location_update", normalizedLocation);
  }
}
function broadcastActivityUpdate(activity, action) {
  if (io) {
    console.log(`[Socket.IO] Broadcasting activity ${action}:`, activity.id);
    io.emit("activity_update", { activity, action });
  }
}

// server/routes.ts
init_geocoding();
init_routing();
var reverseGeoCache = /* @__PURE__ */ new Map();
var upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
  // 10MB limit
});
var SERVER_BUILD_ID = Date.now().toString();
var _ratsCache = /* @__PURE__ */ new Map();
var _ratsRefreshing = /* @__PURE__ */ new Set();
var RATS_CACHE_TTL = 60 * 60 * 1e3;
var _techniciansCache = { data: null, ts: 0 };
var TECHNICIANS_CACHE_TTL = 60 * 60 * 1e3;
var _activitiesCache = /* @__PURE__ */ new Map();
var _activitiesRefreshing = /* @__PURE__ */ new Set();
var ACTIVITIES_CACHE_TTL = 60 * 60 * 1e3;
var _userTechCache = /* @__PURE__ */ new Map();
function getRatsMinimalSelect() {
  return {
    id: rats.id,
    reportNumber: rats.reportNumber,
    reportNumberManual: rats.reportNumberManual,
    clientName: rats.clientName,
    status: rats.status,
    sentAt: rats.sentAt,
    createdAt: rats.createdAt
  };
}
function getRatsLightSelect() {
  return getRatsMinimalSelect();
}
function invalidateRatsCache(technicianId) {
  _ratsCache.delete("admin");
  if (technicianId) {
    _ratsCache.delete(`tech:${technicianId}`);
  } else {
    for (const k of _ratsCache.keys()) {
      if (k.startsWith("tech:")) _ratsCache.delete(k);
    }
  }
  console.log(`[RATs cache] full-invalidated (technicianId=${technicianId ?? "all"})`);
}
function patchRatInCache(ratId, fields) {
  for (const entry of _ratsCache.values()) {
    const idx = entry.data.findIndex((r) => r.id === ratId);
    if (idx !== -1) {
      entry.data[idx] = { ...entry.data[idx], ...fields };
    }
  }
}
function addRatToCache(lightRat) {
  const adminEntry = _ratsCache.get("admin");
  if (adminEntry) adminEntry.data.unshift(lightRat);
  const techKey = `tech:${lightRat.technicianId}`;
  const techEntry = _ratsCache.get(techKey);
  if (techEntry) techEntry.data.unshift(lightRat);
}
function removeRatFromCache(ratId) {
  for (const entry of _ratsCache.values()) {
    const idx = entry.data.findIndex((r) => r.id === ratId);
    if (idx !== -1) entry.data.splice(idx, 1);
  }
}
async function _bgRefreshRatsCache(key, queryFn) {
  if (_ratsRefreshing.has(key)) return;
  _ratsRefreshing.add(key);
  try {
    const data = await queryFn();
    _ratsCache.set(key, { data, ts: Date.now() });
    console.log(`[RATs cache] refreshed key="${key}" (${data.length} items)`);
  } catch (err) {
    console.error(`[RATs cache] background refresh failed key="${key}":`, err.message);
  } finally {
    _ratsRefreshing.delete(key);
  }
}
async function _bgRefreshTechniciansCache() {
  try {
    const data = await storage.getAllTechnicians();
    _techniciansCache.data = data;
    _techniciansCache.ts = Date.now();
    console.log(`[Technicians cache] refreshed (${data.length} items)`);
  } catch (err) {
    console.error("[Technicians cache] background refresh failed:", err.message);
  }
}
function invalidateTechniciansCache() {
  _techniciansCache.data = null;
  _techniciansCache.ts = 0;
  console.log("[Technicians cache] invalidated");
}
async function _bgRefreshActivitiesCache(cacheKey, queryFn) {
  if (_activitiesRefreshing.has(cacheKey)) return;
  _activitiesRefreshing.add(cacheKey);
  try {
    const data = await queryFn();
    _activitiesCache.set(cacheKey, { data, ts: Date.now() });
    console.log(`[Activities cache] refreshed key="${cacheKey}" (${data.length} items)`);
  } catch (err) {
    console.error("[Activities cache] background refresh failed:", err.message);
  } finally {
    _activitiesRefreshing.delete(cacheKey);
  }
}
function invalidateActivitiesCache() {
  _activitiesCache.clear();
  console.log("[Activities cache] cleared");
}
async function registerRoutes(app2) {
  db.execute(sql4`CREATE INDEX IF NOT EXISTS idx_rats_created_at ON rats(created_at DESC)`).then(() => console.log("[DB] idx_rats_created_at ready")).catch((e) => console.warn("[DB] index creation skipped:", e.message));
  db.execute(sql4`CREATE INDEX IF NOT EXISTS idx_rats_technician_created ON rats(technician_id, created_at DESC)`).then(() => console.log("[DB] idx_rats_technician_created ready")).catch((e) => console.warn("[DB] index creation skipped:", e.message));
  app2.get("/health", (_req, res) => {
    res.status(200).json({ status: "healthy", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.get("/api/warmup", async (_req, res) => {
    try {
      await db.execute(sql4`SELECT 1`);
      res.json({ status: "warm", ts: Date.now() });
    } catch (err) {
      console.warn("[warmup] DB ping failed:", err.message);
      res.status(500).json({ status: "cold", error: err.message });
    }
  });
  app2.get("/api/version", (_req, res) => {
    res.json({ buildId: SERVER_BUILD_ID });
  });
  try {
    await seedDefaultAdmin();
  } catch (error) {
    console.error("\u26A0\uFE0F  Database seeding in routes failed:", error.message);
  }
  app2.post("/api/auth/register", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { email, password, role, name } = insertUserSchema.parse(req.body);
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ error: "Este email j\xE1 est\xE1 cadastrado no sistema." });
      }
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        role: role || "assistente",
        name
      });
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json({ user: userWithoutPassword });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Email ou senha incorretos. Verifique e tente novamente." });
      }
      const isValidPassword = await comparePassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Email ou senha incorretos. Verifique e tente novamente." });
      }
      const token = generateToken(user);
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      res.status(401).json({ error: "N\xE3o foi poss\xEDvel fazer login. Verifique suas credenciais." });
    }
  });
  app2.post("/api/auth/datasul-login", async (req, res) => {
    try {
      const { username, password, host } = req.body || {};
      if (!username || !password) {
        return res.status(400).json({ error: "Informe usu\xE1rio e senha do Datasul." });
      }
      const authHeader = `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`;
      let erpRes;
      try {
        erpRes = await datasulFetch(host, "1,1", authHeader);
      } catch (err) {
        if (err?.name === "AbortError") {
          return res.status(504).json({ error: "Tempo de conex\xE3o esgotado ao acessar o Datasul." });
        }
        return res.status(502).json({ error: "N\xE3o foi poss\xEDvel conectar ao Datasul. Verifique a rede/host." });
      }
      if (erpRes.status === 401 || erpRes.status === 403) {
        return res.status(401).json({ error: "Usu\xE1rio ou senha do Datasul inv\xE1lidos." });
      }
      if (!erpRes.ok) {
        return res.status(502).json({ error: `Falha ao conectar no Datasul (HTTP ${erpRes.status}).` });
      }
      const user = await storage.getUserByDatasulUsername(String(username).trim());
      if (!user) {
        return res.status(403).json({
          error: "Login no Datasul validado, mas nenhum usu\xE1rio do ASTEC est\xE1 associado a este perfil Datasul. Contate o administrador."
        });
      }
      const token = generateToken(user);
      const { password: _, ...userWithoutPassword } = user;
      res.json({
        user: userWithoutPassword,
        token,
        datasulToken: authHeader,
        // token Basic p/ buscas Datasul na sessão (ex.: clientes no agendamento)
        datasulHost: resolveDatasulHost(host)
      });
    } catch (error) {
      res.status(401).json({ error: "N\xE3o foi poss\xEDvel fazer login via Datasul." });
    }
  });
  app2.get("/api/auth/me", authMiddleware, async (req, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ error: "Usu\xE1rio n\xE3o encontrado." });
      }
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/users", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      const usersWithoutPassword = allUsers.map(({ password: _, ...user }) => user);
      res.json(usersWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/users", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { email, password, role, name } = insertUserSchema.parse(req.body);
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ error: "Este email j\xE1 est\xE1 cadastrado no sistema." });
      }
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        email,
        password: hashedPassword,
        role: role || "assistente",
        name
      });
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/users/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      let updateData = updateUserSchema.parse(req.body);
      if (req.body.password && typeof req.body.password === "string" && req.body.password.trim().length > 0) {
        const isBcryptHash = req.body.password.startsWith("$2");
        if (!isBcryptHash) {
          const hashedPassword = await hashPassword(req.body.password);
          updateData = { ...updateData, password: hashedPassword };
        }
      } else if (!req.body.password || req.body.password.trim().length === 0) {
        delete updateData.password;
      }
      const user = await storage.updateUser(req.params.id, updateData);
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.patch("/api/users/:id/is-active", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { isActive } = req.body;
      if (typeof isActive !== "boolean") {
        return res.status(400).json({ error: "isActive deve ser um booleano" });
      }
      const user = await storage.updateUser(req.params.id, { isActive });
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/users/:id/toggle-active", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { isActive } = req.body;
      if (typeof isActive !== "boolean") {
        return res.status(400).json({ error: "isActive deve ser um booleano" });
      }
      const user = await storage.updateUser(req.params.id, { isActive });
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/users/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/admin/cleanup-test-data", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { sinceDate } = req.body;
      if (!sinceDate) {
        return res.status(400).json({ error: "sinceDate \xE9 obrigat\xF3rio (YYYY-MM-DD ou ISO string)" });
      }
      const cutoffDate = new Date(sinceDate);
      console.log(`\u{1F534} CLEANUP: Deletando dados de teste desde ${cutoffDate.toISOString()}`);
      const blocksDeleted = await db.delete(sql4`agenda_blocks`).where(
        gte3(sql4`created_at`, cutoffDate)
      );
      const activitiesToDelete = await db.select({ id: activities.id }).from(activities).where(gte3(activities.createdAt, cutoffDate));
      for (const activity of activitiesToDelete) {
        await storage.deleteActivity(activity.id);
      }
      await db.delete(rats).where(gte3(rats.createdAt, cutoffDate));
      invalidateRatsCache();
      await db.delete(approvals).where(
        inArray(
          approvals.activityId,
          db.select({ id: activities.id }).from(activities).where(lt(activities.createdAt, cutoffDate))
        )
      );
      console.log(`\u2705 Limpeza conclu\xEDda:`);
      console.log(`   - ${activitiesToDelete.length} atividades deletadas`);
      console.log(`   - Bloqueios de agenda deletados`);
      console.log(`   - Approvals e registros relacionados deletados`);
      res.json({
        message: "Limpeza de dados de teste conclu\xEDda com sucesso",
        activitiesDeleted: activitiesToDelete.length,
        blocksDeleted: true
      });
    } catch (error) {
      console.error("\u274C Erro na limpeza:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/users/:id/avatar", authMiddleware, upload.single("avatar"), async (req, res) => {
    try {
      const { id } = req.params;
      if (req.user.role !== "admin" && req.user.userId !== id) {
        return res.status(403).json({ error: "Voc\xEA s\xF3 pode atualizar seu pr\xF3prio avatar" });
      }
      if (!req.file) {
        return res.status(400).json({ error: "Nenhuma imagem enviada" });
      }
      const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
      if (!allowedTypes.includes(req.file.mimetype)) {
        return res.status(400).json({ error: "Tipo de arquivo n\xE3o suportado. Use JPEG, PNG, GIF ou WebP." });
      }
      const base64 = req.file.buffer.toString("base64");
      const avatarUrl = `data:${req.file.mimetype};base64,${base64}`;
      const user = await storage.updateUser(id, { avatarUrl });
      const technician = await storage.getTechnicianByUserId(id);
      if (technician) {
        await storage.updateTechnician(technician.id, { avatarUrl });
      }
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Upload avatar error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/users/:id/avatar", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      if (req.user.role !== "admin" && req.user.userId !== id) {
        return res.status(403).json({ error: "Voc\xEA s\xF3 pode atualizar seu pr\xF3prio avatar" });
      }
      const user = await storage.updateUser(id, { avatarUrl: null });
      const technician = await storage.getTechnicianByUserId(id);
      if (technician) {
        await storage.updateTechnician(technician.id, { avatarUrl: null });
      }
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Delete avatar error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/users-with-technician", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = createUserAndTechnicianSchema.parse(req.body);
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email j\xE1 est\xE1 em uso" });
      }
      const bcrypt2 = await import("bcrypt");
      const hashedPassword = await bcrypt2.hash(data.password, 10);
      const userData = {
        email: data.email,
        password: hashedPassword,
        role: data.role,
        name: data.name,
        datasulUsername: data.datasulUsername || null
      };
      const technicianData = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        team: data.team,
        baseCity: data.baseCity,
        color: data.color,
        avatarUrl: data.avatarUrl,
        vehicleInfo: data.vehicleInfo,
        licenseNumber: data.licenseNumber,
        workHoursPerDay: data.workHoursPerDay,
        baseAddress: data.baseAddress,
        baseNumero: data.baseNumero,
        baseBairro: data.baseBairro,
        baseState: data.baseState,
        baseLatitude: data.baseLatitude,
        baseLongitude: data.baseLongitude
      };
      const result = await storage.createUserAndTechnician({ user: userData, technician: technicianData });
      res.status(201).json(result);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/technicians", authMiddleware, async (req, res) => {
    try {
      if (_techniciansCache.data) {
        res.json(_techniciansCache.data);
        const age = Date.now() - _techniciansCache.ts;
        if (age > TECHNICIANS_CACHE_TTL) {
          _bgRefreshTechniciansCache().catch(() => {
          });
        }
        return;
      }
      try {
        const technicians2 = await storage.getAllTechnicians();
        _techniciansCache.data = technicians2;
        _techniciansCache.ts = Date.now();
        console.log(`[Technicians cache] populated (${technicians2.length} items)`);
        res.json(technicians2);
      } catch (dbErr) {
        console.error(`[Technicians] DB query failed:`, dbErr.message);
        return res.status(503).json({
          error: "Servidor aquecendo, tente novamente em alguns segundos",
          retryAfter: 5
        });
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/technicians/status", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { reverseGeocodeDetailed: reverseGeocodeDetailed2 } = await Promise.resolve().then(() => (init_geocoding(), geocoding_exports));
      const allTechnicians = await storage.getAllTechnicians();
      const fieldTechnicians = await Promise.all(
        allTechnicians.map(async (technician) => {
          const user = await storage.getUser(technician.userId);
          return { technician, user };
        })
      );
      const assistenteTechnicians = fieldTechnicians.filter(({ user }) => user?.role === "assistente" && user?.isActive !== false).map(({ technician }) => technician);
      const today = /* @__PURE__ */ new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const allActivities = await storage.getActivitiesByDateRange(today, tomorrow);
      const techniciansWithStatus = [];
      for (const technician of assistenteTechnicians) {
        const lastLocation = await storage.getLastTechnicianLocation(technician.id);
        const technicianActivities = allActivities.filter(
          (a) => a.technicianId === technician.id
        );
        let currentActivityStatus = null;
        const activeActivity = technicianActivities.find((a) => a.status === "emExecucao");
        if (activeActivity) {
          currentActivityStatus = "emExecucao";
        } else {
          const enRouteActivity = technicianActivities.find((a) => a.status === "aCaminho");
          if (enRouteActivity) {
            currentActivityStatus = "aCaminho";
          }
        }
        const LOCATION_TIMEOUT_MS = 5 * 60 * 1e3;
        const isLocationStale = lastLocation && lastLocation.updatedAt ? Date.now() - new Date(lastLocation.updatedAt).getTime() > LOCATION_TIMEOUT_MS : true;
        const effectiveGpsStatus = lastLocation && !isLocationStale ? lastLocation.gpsStatus : "inativo";
        const effectiveConnectionStatus = lastLocation && !isLocationStale ? lastLocation.connectionStatus : "offline";
        let address = lastLocation?.address || null;
        let city = null;
        if (lastLocation && lastLocation.latitude && lastLocation.longitude && !address) {
          try {
            const lat = parseFloat(lastLocation.latitude);
            const lon = parseFloat(lastLocation.longitude);
            if (!isNaN(lat) && !isNaN(lon)) {
              const geocodeResult = await reverseGeocodeDetailed2(lat, lon);
              if (geocodeResult.found) {
                address = geocodeResult.address;
                city = geocodeResult.city;
              }
            }
          } catch (error) {
            console.error(`[Geocoding] Error for technician ${technician.id}:`, error);
          }
        }
        techniciansWithStatus.push({
          technicianId: technician.id,
          name: technician.name,
          email: technician.email,
          team: technician.team,
          color: technician.color,
          baseCity: technician.baseCity,
          baseAddress: technician.baseAddress,
          status: effectiveConnectionStatus,
          gpsStatus: effectiveGpsStatus,
          currentActivityStatus,
          lastLocation: lastLocation ? {
            latitude: lastLocation.latitude,
            longitude: lastLocation.longitude,
            accuracy: lastLocation.accuracy,
            address,
            city,
            updatedAt: lastLocation.updatedAt
          } : null,
          battery: lastLocation?.battery,
          device: lastLocation?.deviceModel,
          androidVersion: lastLocation?.androidVersion,
          appVersion: lastLocation?.appVersion
        });
      }
      res.json(techniciansWithStatus);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/technicians/nearby", authMiddleware, async (req, res) => {
    try {
      const { lat, lng } = req.query;
      if (!lat || !lng) {
        return res.status(400).json({ error: "Localiza\xE7\xE3o (latitude e longitude) \xE9 obrigat\xF3ria." });
      }
      const searchLat = parseFloat(lat);
      const searchLng = parseFloat(lng);
      if (isNaN(searchLat) || isNaN(searchLng)) {
        return res.status(400).json({ error: "Coordenadas inv\xE1lidas." });
      }
      const allTechnicians = await storage.getAllTechnicians();
      const { calculateDistance: calculateDistance2 } = await Promise.resolve().then(() => (init_geo(), geo_exports));
      const { calculateRoute: calculateRoute2 } = await Promise.resolve().then(() => (init_routing(), routing_exports));
      const fieldTechnicians = await Promise.all(
        allTechnicians.map(async (technician) => {
          const user = await storage.getUser(technician.userId);
          return { technician, user };
        })
      );
      const assistenteTechnicians = fieldTechnicians.filter(({ user }) => user?.role === "assistente").map(({ technician }) => technician);
      const techniciansNearby = await Promise.all(
        assistenteTechnicians.map(async (technician) => {
          const lastLocation = await storage.getLastTechnicianLocation(technician.id);
          const LOCATION_TIMEOUT_MS = 24 * 60 * 60 * 1e3;
          const isLocationStale = lastLocation && lastLocation.updatedAt ? Date.now() - new Date(lastLocation.updatedAt).getTime() > LOCATION_TIMEOUT_MS : true;
          if (!lastLocation || isLocationStale) {
            return null;
          }
          const techLat = parseFloat(lastLocation.latitude);
          const techLng = parseFloat(lastLocation.longitude);
          let distanceKm = calculateDistance2(techLat, techLng, searchLat, searchLng);
          let estimatedTimeMin = Math.round(distanceKm * 2);
          try {
            const route = await calculateRoute2([
              { latitude: techLat, longitude: techLng },
              { latitude: searchLat, longitude: searchLng }
            ]);
            if (route.success) {
              distanceKm = route.distanceKm;
              estimatedTimeMin = route.durationMinutes;
            }
          } catch {
          }
          const today = /* @__PURE__ */ new Date();
          today.setHours(0, 0, 0, 0);
          const tomorrow = new Date(today);
          tomorrow.setDate(tomorrow.getDate() + 1);
          const allActivities = await storage.getActivitiesByDateRange(
            today,
            tomorrow
          );
          const activities2 = allActivities.filter((a) => a.technicianId === technician.id);
          const busyHours = activities2.filter((a) => a.status !== "cancelado").map((a) => ({
            start: a.startTime,
            end: a.endTime
          }));
          const hasAvailability = busyHours.length === 0 || busyHours.length < 6;
          let availabilityText = "";
          if (busyHours.length === 0) {
            availabilityText = "Livre o dia todo";
          } else if (busyHours.length < 3) {
            availabilityText = "Parcialmente livre";
          } else {
            availabilityText = "Agenda ocupada";
          }
          return {
            id: technician.id,
            name: technician.name,
            email: technician.email,
            team: technician.team,
            color: technician.color,
            distanceKm: Math.round(distanceKm * 10) / 10,
            // Round to 1 decimal
            estimatedTimeMin,
            currentLocation: {
              latitude: lastLocation.latitude,
              longitude: lastLocation.longitude,
              address: lastLocation.address
            },
            availability: {
              hasAvailability,
              description: availabilityText,
              busySlots: busyHours.length
            },
            lastUpdate: lastLocation.updatedAt
          };
        })
      );
      const validTechnicians = techniciansNearby.filter((t) => t !== null).sort((a, b) => a.distanceKm - b.distanceKm);
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.json(validTechnicians);
    } catch (error) {
      console.error("Error finding nearby technicians:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/map/activities", authMiddleware, async (req, res) => {
    try {
      const { technicianIds, startDate, endDate } = req.query;
      let techIds = [];
      if (technicianIds) {
        if (Array.isArray(technicianIds)) {
          techIds = technicianIds;
        } else {
          techIds = technicianIds.split(",").filter(Boolean);
        }
      }
      const start = startDate ? new Date(startDate) : /* @__PURE__ */ new Date();
      start.setHours(0, 0, 0, 0);
      const end = endDate ? new Date(endDate) : /* @__PURE__ */ new Date();
      end.setHours(23, 59, 59, 999);
      const allActivities = await storage.getActivitiesByDateRange(start, end);
      const filteredActivities = techIds.length > 0 ? allActivities.filter((a) => techIds.includes(a.technicianId)) : allActivities;
      const enrichedActivities = filteredActivities.map((activity) => {
        return {
          id: activity.id,
          title: activity.title,
          clientName: activity.client?.name || activity.clientName || "Cliente Desconhecido",
          address: activity.address || "",
          latitude: parseFloat(activity.latitude || "0"),
          longitude: parseFloat(activity.longitude || "0"),
          scheduledDate: activity.scheduledDate,
          scheduledTime: activity.startTime,
          endTime: activity.endTime,
          status: activity.status,
          activityTypeName: activity.activityType?.name || "Atividade",
          // Local da visita: prioriza cidade/UF da própria atividade; cai para o
          // cadastro do cliente apenas quando a atividade não tiver.
          clientCity: activity.city || activity.client?.city || null,
          clientState: activity.state || activity.client?.state || null,
          technicianId: activity.technicianId,
          technicianName: activity.technician?.name || "T\xE9cnico",
          technicianColor: activity.technician?.color || "#3b82f6"
        };
      });
      if (req.query.resolveCity === "1") {
        for (const act of enrichedActivities) {
          if (act.clientCity && act.clientState || !act.latitude || !act.longitude) continue;
          if (Math.abs(act.latitude) < 0.5 && Math.abs(act.longitude) < 0.5) continue;
          const key = `${act.latitude.toFixed(4)},${act.longitude.toFixed(4)}`;
          let resolved = reverseGeoCache.get(key);
          if (!resolved) {
            try {
              const geo = await reverseGeocodeDetailed(act.latitude, act.longitude);
              resolved = { city: geo.city, state: geo.state };
              reverseGeoCache.set(key, resolved);
            } catch {
              resolved = { city: null, state: null };
            }
          }
          act.clientCity = act.clientCity || resolved.city;
          act.clientState = act.clientState || resolved.state;
        }
      }
      res.json(enrichedActivities);
    } catch (error) {
      console.error("Error fetching map activities:", error);
      res.status(500).json({ error: error.message });
    }
  });
  const DATASUL_DEFAULT_HOST = process.env.DATASUL_HOST || "erp.renner.com.br";
  const DATASUL_ALLOWED_HOSTS = [
    "erp.renner.com.br",
    "erp-homol.renner.com.br",
    "erp-desenv.renner.com.br"
  ];
  function resolveDatasulHost(host) {
    const h = (host || DATASUL_DEFAULT_HOST).trim().toLowerCase();
    return DATASUL_ALLOWED_HOSTS.includes(h) ? h : DATASUL_DEFAULT_HOST;
  }
  function datasulClientesUrl(host, params) {
    return `https://${resolveDatasulHost(host)}/api/renner/rest/rcoa/ped/v1/rhpd4000api/clientes-lista/${params}`;
  }
  async function datasulFetch(host, params, authHeader) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3e4);
    try {
      return await fetch(datasulClientesUrl(host, params), {
        headers: { Authorization: authHeader, Accept: "application/json" },
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeout);
    }
  }
  function getDatasulAuthHeader(req) {
    const incoming = req.headers["x-datasul-auth"] || req.headers["authorization-datasul"];
    if (typeof incoming === "string" && incoming.toLowerCase().startsWith("basic ")) {
      return incoming;
    }
    const { username, password } = req.body || {};
    if (username && password) {
      return `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`;
    }
    return null;
  }
  app2.post("/api/datasul/login", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { username, password, host, grupo } = req.body || {};
      if (!username || !password) {
        return res.status(400).json({ error: "Informe usu\xE1rio e senha do Datasul." });
      }
      const authHeader = `Basic ${Buffer.from(`${username}:${password}`).toString("base64")}`;
      const resolvedHost = resolveDatasulHost(host);
      const grupoTrim = (grupo || "").trim();
      const params = `1,50,,${grupoTrim ? encodeURIComponent(grupoTrim) : ""},1`;
      let erpRes;
      try {
        erpRes = await datasulFetch(host, params, authHeader);
      } catch (err) {
        if (err?.name === "AbortError") {
          return res.status(504).json({ error: "Tempo de conex\xE3o esgotado ao acessar o Datasul." });
        }
        console.error("[Datasul] erro de rede no login:", err?.message);
        return res.status(502).json({ error: "N\xE3o foi poss\xEDvel conectar ao Datasul. Verifique a rede/host." });
      }
      if (erpRes.status === 401 || erpRes.status === 403) {
        return res.status(401).json({ error: "Usu\xE1rio ou senha do Datasul inv\xE1lidos." });
      }
      if (!erpRes.ok) {
        return res.status(502).json({ error: `Falha ao conectar no Datasul (HTTP ${erpRes.status}).` });
      }
      const data = await erpRes.json().catch(() => null);
      const meta = Array.isArray(data?.items) ? data.items.find((i) => i?._meta === "SIM") : null;
      return res.json({
        ok: true,
        host: resolvedHost,
        token: authHeader,
        // o cliente guarda em memória para as próximas chamadas
        grupo: grupoTrim || null,
        total: meta?.total ? parseInt(meta.total, 10) : null
      });
    } catch (error) {
      console.error("[Datasul] login error:", error?.message);
      return res.status(500).json({ error: "Erro inesperado ao validar credenciais do Datasul." });
    }
  });
  app2.get("/api/datasul/clientes", authMiddleware, async (req, res) => {
    try {
      const authHeader = getDatasulAuthHeader(req);
      if (!authHeader) {
        return res.status(401).json({ error: "Sess\xE3o do Datasul n\xE3o encontrada. Conecte-se novamente." });
      }
      const pagina = parseInt(req.query.pagina || "1", 10) || 1;
      const tamanho = Math.min(parseInt(req.query.tamanho || "50", 10) || 50, 200);
      const termo = (req.query.busca || "").trim();
      let grupoReq = (req.query.grupo || "").trim();
      const host = req.query.host;
      if (termo.length > 0 && !grupoReq) {
        const params71 = [
          String(pagina),
          String(tamanho),
          encodeURIComponent(termo),
          encodeURIComponent("71"),
          "1"
        ].join(",");
        const params88 = [
          String(pagina),
          String(tamanho),
          encodeURIComponent(termo),
          encodeURIComponent("88"),
          "1"
        ].join(",");
        let erpRes71;
        let erpRes88;
        try {
          [erpRes71, erpRes88] = await Promise.all([
            datasulFetch(host, params71, authHeader),
            datasulFetch(host, params88, authHeader)
          ]);
        } catch (err) {
          if (err?.name === "AbortError") {
            return res.status(504).json({ error: "Tempo de conex\xE3o esgotado ao acessar o Datasul." });
          }
          return res.status(502).json({ error: "N\xE3o foi poss\xEDvel conectar ao Datasul." });
        }
        if (!erpRes71.ok) {
          return res.status(502).json({ error: `Falha ao consultar clientes grupo 71 (HTTP ${erpRes71.status}).` });
        }
        const data71 = await erpRes71.json().catch(() => null);
        const items71 = Array.isArray(data71?.items) ? data71.items : [];
        const clientes71 = items71.filter((i) => i?._meta !== "SIM");
        const meta71 = items71.find((i) => i?._meta === "SIM");
        if (!erpRes88.ok) {
          console.warn(`[Datasul] Aviso: grupo 88 retornou HTTP ${erpRes88.status}, usando apenas grupo 71`);
          return res.json({
            meta: meta71 ? {
              total: meta71.total ? parseInt(meta71.total, 10) : null,
              pagina: meta71.pagina ? parseInt(meta71.pagina, 10) : pagina,
              tamPag: meta71["tam-pag"] ? parseInt(meta71["tam-pag"], 10) : tamanho,
              paginas: meta71.paginas ? parseInt(meta71.paginas, 10) : null,
              grupo: "71"
            } : { total: null, pagina, tamPag: tamanho, paginas: null, grupo: "71" },
            clientes: clientes71
          });
        }
        const data88 = await erpRes88.json().catch(() => null);
        const items88 = Array.isArray(data88?.items) ? data88.items : [];
        const clientes88 = items88.filter((i) => i?._meta !== "SIM");
        const meta88 = items88.find((i) => i?._meta === "SIM");
        const allClientes = [...clientes71, ...clientes88];
        const totalCombined = (meta71?.total ? parseInt(meta71.total, 10) : 0) + (meta88?.total ? parseInt(meta88.total, 10) : 0);
        return res.json({
          meta: {
            total: totalCombined,
            pagina,
            tamPag: tamanho,
            paginas: Math.ceil(totalCombined / tamanho),
            grupo: "71,88"
            // Indica que buscou em ambos
          },
          clientes: allClientes
        });
      }
      const params = [
        String(pagina),
        String(tamanho),
        encodeURIComponent(termo),
        encodeURIComponent(grupoReq || "71"),
        // Padrão: grupo 71
        "1"
      ].join(",");
      let erpRes;
      try {
        erpRes = await datasulFetch(host, params, authHeader);
      } catch (err) {
        if (err?.name === "AbortError") {
          return res.status(504).json({ error: "Tempo de conex\xE3o esgotado ao acessar o Datasul." });
        }
        return res.status(502).json({ error: "N\xE3o foi poss\xEDvel conectar ao Datasul." });
      }
      if (erpRes.status === 401 || erpRes.status === 403) {
        return res.status(401).json({ error: "Sess\xE3o do Datasul expirada. Conecte-se novamente." });
      }
      if (!erpRes.ok) {
        return res.status(502).json({ error: `Falha ao consultar clientes (HTTP ${erpRes.status}).` });
      }
      const data = await erpRes.json().catch(() => null);
      const items = Array.isArray(data?.items) ? data.items : [];
      const meta = items.find((i) => i?._meta === "SIM") || null;
      const clientes = items.filter((i) => i?._meta !== "SIM");
      return res.json({
        meta: meta ? {
          total: meta.total ? parseInt(meta.total, 10) : null,
          pagina: meta.pagina ? parseInt(meta.pagina, 10) : pagina,
          tamPag: meta["tam-pag"] ? parseInt(meta["tam-pag"], 10) : tamanho,
          paginas: meta.paginas ? parseInt(meta.paginas, 10) : null,
          grupo: meta["cod-gr-cli"] ?? grupoReq ?? "71"
        } : { total: null, pagina, tamPag: tamanho, paginas: null, grupo: grupoReq || "71" },
        clientes
      });
    } catch (error) {
      console.error("[Datasul] clientes error:", error?.message);
      return res.status(500).json({ error: "Erro inesperado ao consultar clientes do Datasul." });
    }
  });
  app2.post("/api/datasul/import", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const authHeader = getDatasulAuthHeader(req);
      if (!authHeader) {
        return res.status(401).json({ error: "Sess\xE3o do Datasul n\xE3o encontrada. Conecte-se novamente." });
      }
      const { host, grupo } = req.body || {};
      const grupoTrim = (grupo || "").trim();
      const PAGE = 200;
      const existing = await storage.getAllClients();
      const byInternal = /* @__PURE__ */ new Map();
      const byCnpj = /* @__PURE__ */ new Map();
      const onlyDigits = (s) => (s || "").replace(/\D/g, "");
      for (const c of existing) {
        if (c.internalCode) byInternal.set(c.internalCode.trim(), c);
        const dig = onlyDigits(c.cnpj);
        if (dig) byCnpj.set(dig, c);
      }
      let created = 0;
      let updated = 0;
      let processed = 0;
      let pagina = 1;
      const MAX_PAGINAS = 2e3;
      while (pagina <= MAX_PAGINAS) {
        const params = [
          String(pagina),
          String(PAGE),
          "",
          grupoTrim ? encodeURIComponent(grupoTrim) : "",
          "1"
        ].join(",");
        const erpRes = await datasulFetch(host, params, authHeader);
        if (erpRes.status === 401 || erpRes.status === 403) {
          return res.status(401).json({ error: "Sess\xE3o do Datasul expirada. Conecte-se novamente." });
        }
        if (!erpRes.ok) {
          return res.status(502).json({ error: `Falha ao consultar clientes (HTTP ${erpRes.status}).` });
        }
        const data = await erpRes.json().catch(() => null);
        const items = Array.isArray(data?.items) ? data.items : [];
        const lote = items.filter((i) => i?._meta !== "SIM");
        if (lote.length === 0) break;
        for (const c of lote) {
          processed++;
          const internalCode = String(c["cod-emitente"] || "").trim();
          const companyName = String(c["nome-emit"] || c["nome-abrev"] || "").trim();
          if (!companyName) continue;
          const cnpjDigits = onlyDigits(c["cgc"]);
          const payload = {
            companyName,
            cnpj: c["cgc"] || null,
            internalCode: internalCode || null,
            city: c["cidade"] || null,
            state: c["estado"] || null,
            contactPhone: c["telefone"] || null,
            contactEmail: c["e-mail"] || null,
            country: "Brasil",
            active: true
          };
          const match = internalCode && byInternal.get(internalCode) || cnpjDigits && byCnpj.get(cnpjDigits) || null;
          if (match) {
            await storage.updateClient(match.id, payload);
            updated++;
          } else {
            const novo = await storage.createClient(payload);
            created++;
            if (internalCode) byInternal.set(internalCode, novo);
            if (cnpjDigits) byCnpj.set(cnpjDigits, novo);
          }
        }
        if (lote.length < PAGE) break;
        pagina++;
      }
      console.log(`[Datasul] import conclu\xEDdo: processados=${processed} criados=${created} atualizados=${updated}`);
      return res.json({ ok: true, processed, created, updated });
    } catch (error) {
      console.error("[Datasul] import error:", error?.message);
      return res.status(500).json({ error: "Erro ao importar clientes do Datasul." });
    }
  });
  app2.post("/api/datasul/import-clientes", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { clientes } = req.body || {};
      if (!Array.isArray(clientes) || clientes.length === 0) {
        return res.status(400).json({ error: "Nenhum cliente informado para importar." });
      }
      const existing = await storage.getAllClients();
      const byInternal = /* @__PURE__ */ new Map();
      const byCnpj = /* @__PURE__ */ new Map();
      const onlyDigits = (s) => (s || "").replace(/\D/g, "");
      for (const c of existing) {
        if (c.internalCode) byInternal.set(c.internalCode.trim(), c);
        const dig = onlyDigits(c.cnpj);
        if (dig) byCnpj.set(dig, c);
      }
      let created = 0;
      let updated = 0;
      let processed = 0;
      for (const c of clientes) {
        processed++;
        const internalCode = String(c["cod-emitente"] || "").trim();
        const companyName = String(c["nome-emit"] || c["nome-abrev"] || "").trim();
        if (!companyName) continue;
        const cnpjDigits = onlyDigits(c["cgc"]);
        const payload = {
          companyName,
          cnpj: c["cgc"] || null,
          internalCode: internalCode || null,
          city: c["cidade"] || null,
          state: c["estado"] || null,
          contactPhone: c["telefone"] || null,
          contactEmail: c["e-mail"] || null,
          country: "Brasil",
          active: true
        };
        const match = internalCode && byInternal.get(internalCode) || cnpjDigits && byCnpj.get(cnpjDigits) || null;
        if (match) {
          await storage.updateClient(match.id, payload);
          updated++;
        } else {
          const novo = await storage.createClient(payload);
          created++;
          if (internalCode) byInternal.set(internalCode, novo);
          if (cnpjDigits) byCnpj.set(cnpjDigits, novo);
        }
      }
      return res.json({ ok: true, processed, created, updated });
    } catch (error) {
      console.error("[Datasul] import-clientes error:", error?.message);
      return res.status(500).json({ error: "Erro ao importar clientes selecionados." });
    }
  });
  app2.post("/api/technicians/nearby/search", authMiddleware, async (req, res) => {
    try {
      const {
        destinationLat,
        destinationLng,
        destinationCep,
        technicianIds,
        locationSource,
        // "gps" | "base" | "activity"
        baseCity,
        dateRange
      } = req.body;
      let searchLat = destinationLat;
      let searchLng = destinationLng;
      if (destinationCep && (!searchLat || !searchLng)) {
        const geocoded = await geocodeAddress(`${destinationCep}, Brasil`);
        if (geocoded.found) {
          searchLat = geocoded.latitude;
          searchLng = geocoded.longitude;
        } else {
          return res.status(400).json({ error: "CEP n\xE3o encontrado" });
        }
      }
      if (!searchLat || !searchLng) {
        return res.status(400).json({ error: "Coordenadas de destino s\xE3o obrigat\xF3rias" });
      }
      const { calculateDistance: calculateDistance2 } = await Promise.resolve().then(() => (init_geo(), geo_exports));
      const { calculateRoute: calculateRoute2 } = await Promise.resolve().then(() => (init_routing(), routing_exports));
      const allTechnicians = await storage.getAllTechnicians();
      let filteredTechnicians = technicianIds && technicianIds.length > 0 ? allTechnicians.filter((t) => technicianIds.includes(t.id)) : allTechnicians;
      if (baseCity) {
        filteredTechnicians = filteredTechnicians.filter(
          (t) => t.baseCity?.toLowerCase().includes(baseCity.toLowerCase())
        );
      }
      let allActivitiesInPeriod = [];
      let activitiesByTechnician = /* @__PURE__ */ new Map();
      if (locationSource === "activity" && dateRange) {
        const startParts = dateRange.start.split("-").map(Number);
        const endParts = dateRange.end.split("-").map(Number);
        const startLocal = new Date(startParts[0], startParts[1] - 1, startParts[2], 0, 0, 0, 0);
        const endLocal = new Date(endParts[0], endParts[1] - 1, endParts[2], 23, 59, 59, 999);
        const tzOffset = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
        const startUtc = new Date(startLocal.getTime() + tzOffset);
        const endUtc = new Date(endLocal.getTime() + tzOffset);
        console.log(`[NearbySearch] Date range (LOCAL): ${startLocal.toLocaleString()} to ${endLocal.toLocaleString()}`);
        console.log(`[NearbySearch] Date range (UTC adjusted): ${startUtc.toISOString()} to ${endUtc.toISOString()}`);
        allActivitiesInPeriod = await storage.getActivitiesByDateRange(startUtc, endUtc);
        console.log(`[NearbySearch] Found activities: ${allActivitiesInPeriod.length}`);
        allActivitiesInPeriod.forEach((a) => {
          console.log(`  - Activity: ${a.id}, Tech: ${a.technicianId}, Client: ${a.clientName}, Date: ${a.scheduledDate}`);
        });
        for (const activity of allActivitiesInPeriod) {
          if (!activitiesByTechnician.has(activity.technicianId)) {
            activitiesByTechnician.set(activity.technicianId, []);
          }
          activitiesByTechnician.get(activity.technicianId).push(activity);
        }
      }
      const fieldTechnicians = await Promise.all(
        filteredTechnicians.map(async (technician) => {
          const user = await storage.getUser(technician.userId);
          return { technician, user };
        })
      );
      let assistenteTechnicians;
      if (locationSource === "activity") {
        const techWithActivities = new Set(activitiesByTechnician.keys());
        assistenteTechnicians = fieldTechnicians.filter(({ technician, user }) => {
          return techWithActivities.has(technician.id) || user?.role === "assistente";
        }).map(({ technician }) => technician);
      } else {
        assistenteTechnicians = fieldTechnicians.filter(({ user }) => user?.role === "assistente").map(({ technician }) => technician);
      }
      console.log(`[NearbySearch] Total technicians: ${filteredTechnicians.length}, Filtered: ${assistenteTechnicians.length}`);
      console.log(`[NearbySearch] Filtered technician IDs: ${assistenteTechnicians.map((t) => t.id).join(", ")}`);
      if (locationSource === "activity" && allActivitiesInPeriod.length > 0) {
        const activityTechIds = new Set(allActivitiesInPeriod.filter((a) => a.technicianId).map((a) => a.technicianId));
        const shownTechs = assistenteTechnicians.filter((t) => activityTechIds.has(t.id));
        const notShown = Array.from(activityTechIds).filter((id) => !assistenteTechnicians.find((t) => t.id === id));
        console.log(`[NearbySearch] Technicians with activities: ${Array.from(activityTechIds).join(", ")}`);
        console.log(`[NearbySearch] Technicians being shown: ${shownTechs.map((t) => t.id).join(", ")}`);
        if (notShown.length > 0) {
          console.log(`[NearbySearch] WARNING: Activities for non-existent/non-listed techs: ${notShown.join(", ")}`);
        }
      }
      const allActivityTypes = await storage.getAllActivityTypes();
      const activityTypesMap = new Map(allActivityTypes.map((t) => [t.id, t]));
      const enrichedActivities = allActivitiesInPeriod.map((activity) => ({
        ...activity,
        activityTypeName: activity.activityTypeId ? activityTypesMap.get(activity.activityTypeId)?.name : null
      }));
      activitiesByTechnician.clear();
      for (const activity of enrichedActivities) {
        if (!activitiesByTechnician.has(activity.technicianId)) {
          activitiesByTechnician.set(activity.technicianId, []);
        }
        activitiesByTechnician.get(activity.technicianId).push(activity);
      }
      console.log(`[NearbySearch] Activities by technician: ${Array.from(activitiesByTechnician.entries()).map(([tid, acts]) => `${tid}: ${acts.length}`).join(", ")}`);
      const techniciansWithDistance = await Promise.all(
        assistenteTechnicians.map(async (technician) => {
          let techLat = null;
          let techLng = null;
          let locationDescription = "";
          let allActivitiesWithDistance = [];
          let closestActivity = null;
          if (locationSource === "base") {
            const baseLat = technician.baseLatitude ? parseFloat(technician.baseLatitude) : null;
            const baseLng = technician.baseLongitude ? parseFloat(technician.baseLongitude) : null;
            if (baseLat && baseLng && !isNaN(baseLat) && !isNaN(baseLng)) {
              techLat = baseLat;
              techLng = baseLng;
              locationDescription = `Base: ${technician.baseCity || technician.baseAddress || "Configurada"}`;
            }
          } else if (locationSource === "activity") {
            const techActivities = activitiesByTechnician.get(technician.id) || [];
            if (techActivities.length > 0) {
              console.log(`[NearbySearch] Tech ${technician.name} (${technician.id}) has activities in map!`);
            }
            const validActivities = techActivities.filter(
              (a) => a.latitude && a.longitude && a.status !== "cancelado"
            );
            console.log(`[NearbySearch] Technician ${technician.name} (${technician.id}): ${techActivities.length} total, ${validActivities.length} valid activities`);
            if (validActivities.length === 0) {
              return null;
            }
            const activitiesWithRouteInfo = await Promise.all(
              validActivities.map(async (activity) => {
                const actLat = parseFloat(activity.latitude);
                const actLng = parseFloat(activity.longitude);
                if (isNaN(actLat) || isNaN(actLng)) {
                  return null;
                }
                let distanceKm2 = calculateDistance2(actLat, actLng, searchLat, searchLng);
                let estimatedTimeMin2 = Math.round(distanceKm2 * 2);
                try {
                  const route = await calculateRoute2([
                    { latitude: actLat, longitude: actLng },
                    { latitude: searchLat, longitude: searchLng }
                  ]);
                  if (route.success) {
                    distanceKm2 = route.distanceKm;
                    estimatedTimeMin2 = route.durationMinutes;
                  }
                } catch {
                }
                const activityDate = new Date(activity.scheduledDate);
                const formattedDate = `${String(activityDate.getDate()).padStart(2, "0")}/${String(activityDate.getMonth() + 1).padStart(2, "0")}/${activityDate.getFullYear()}`;
                const formattedTime = activity.startTime ? activity.startTime.slice(0, 5) : "";
                return {
                  id: activity.id,
                  scheduledDate: activity.scheduledDate,
                  formattedDate,
                  startTime: formattedTime,
                  endTime: activity.endTime ? activity.endTime.slice(0, 5) : "",
                  clientName: activity.clientName || activity.description || "Atividade",
                  clientId: activity.clientId,
                  address: activity.address || "",
                  city: activity.city || "",
                  activityType: activity.activityTypeName || activity.description || "",
                  status: activity.status,
                  latitude: actLat,
                  longitude: actLng,
                  distanceKm: Math.round(distanceKm2 * 10) / 10,
                  estimatedTimeMin: estimatedTimeMin2
                };
              })
            );
            allActivitiesWithDistance = activitiesWithRouteInfo.filter((a) => a !== null).sort((a, b) => a.distanceKm - b.distanceKm);
            console.log(`[NearbySearch] ${technician.name}: Returning ${allActivitiesWithDistance.length} activities after distance calc`);
            if (allActivitiesWithDistance.length === 0) {
              return null;
            }
            closestActivity = allActivitiesWithDistance[0];
            techLat = closestActivity.latitude;
            techLng = closestActivity.longitude;
            locationDescription = `Atividade mais pr\xF3xima: ${closestActivity.clientName} (${closestActivity.formattedDate} \xE0s ${closestActivity.startTime})`;
          } else {
            const lastLocation = await storage.getLastTechnicianLocation(technician.id);
            const LOCATION_TIMEOUT_MS = 24 * 60 * 60 * 1e3;
            if (lastLocation) {
              const isLocationStale = Date.now() - new Date(lastLocation.updatedAt).getTime() > LOCATION_TIMEOUT_MS;
              if (!isLocationStale) {
                techLat = parseFloat(lastLocation.latitude);
                techLng = parseFloat(lastLocation.longitude);
                locationDescription = lastLocation.address || "Localiza\xE7\xE3o GPS";
              }
            }
          }
          if (!techLat || !techLng || isNaN(techLat) || isNaN(techLng)) {
            return null;
          }
          let distanceKm = closestActivity?.distanceKm || calculateDistance2(techLat, techLng, searchLat, searchLng);
          let estimatedTimeMin = closestActivity?.estimatedTimeMin || Math.round(distanceKm * 2);
          if (!closestActivity) {
            try {
              const route = await calculateRoute2([
                { latitude: techLat, longitude: techLng },
                { latitude: searchLat, longitude: searchLng }
              ]);
              if (route.success) {
                distanceKm = route.distanceKm;
                estimatedTimeMin = route.durationMinutes;
              }
            } catch {
            }
          }
          return {
            id: technician.id,
            name: technician.name,
            email: technician.email,
            team: technician.team,
            color: technician.color,
            baseCity: technician.baseCity,
            distanceKm: Math.round(distanceKm * 10) / 10,
            estimatedTimeMin,
            location: {
              latitude: techLat,
              longitude: techLng,
              description: locationDescription
            },
            locationSource,
            // New: Include all activities with distance info when searching by activity
            closestActivity: closestActivity || null,
            allActivities: allActivitiesWithDistance.length > 0 ? allActivitiesWithDistance : void 0,
            totalActivitiesInPeriod: allActivitiesWithDistance.length
          };
        })
      );
      const validTechnicians = techniciansWithDistance.filter((t) => t !== null).sort((a, b) => a.distanceKm - b.distanceKm);
      console.log(`[NearbySearch] FINAL RESULT: ${validTechnicians.length} technicians found`);
      validTechnicians.forEach((tech, idx) => {
        console.log(`  [${idx}] ${tech.name}: ${tech.allActivities?.length || 0} activities, ${tech.totalActivitiesInPeriod} total`);
      });
      res.json({
        destination: { lat: searchLat, lng: searchLng },
        technicians: validTechnicians
      });
    } catch (error) {
      console.error("Error in nearby technicians search:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/technicians/bases", authMiddleware, async (req, res) => {
    try {
      const allTechnicians = await storage.getAllTechnicians();
      const baseCitiesSet = /* @__PURE__ */ new Set();
      allTechnicians.forEach((t) => {
        if (t.baseCity) baseCitiesSet.add(t.baseCity);
      });
      const baseCities = Array.from(baseCitiesSet).sort();
      res.json(baseCities);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/technicians/:id", authMiddleware, async (req, res) => {
    try {
      const technician = await storage.getTechnician(req.params.id);
      if (!technician) {
        return res.status(404).json({ error: "T\xE9cnico n\xE3o encontrado." });
      }
      res.json(technician);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/technicians", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertTechnicianSchema.parse(req.body);
      const technician = await storage.createTechnician(data);
      invalidateTechniciansCache();
      res.status(201).json(technician);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/technicians/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateUserAndTechnicianSchema.parse(req.body);
      const result = await storage.updateUserAndTechnician(req.params.id, data);
      invalidateTechniciansCache();
      res.json(result.technician);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/technicians/:id/datasul-profile", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const raw = req.body?.datasulUsername;
      const datasulUsername = raw === void 0 || raw === null || raw === "" ? null : String(raw).trim();
      const user = await storage.updateTechnicianDatasulProfile(req.params.id, datasulUsername);
      invalidateTechniciansCache();
      res.json({ datasulUsername: user.datasulUsername });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/technicians/:id/update", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateUserAndTechnicianSchema.parse(req.body);
      const result = await storage.updateUserAndTechnician(req.params.id, data);
      invalidateTechniciansCache();
      res.json(result.technician);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/technicians/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const activitiesCount = await storage.countActivitiesByTechnicianId(req.params.id);
      if (activitiesCount > 0) {
        console.log(`Deleting technician ${req.params.id} with ${activitiesCount} activities (cascade delete)`);
      }
      await storage.deleteTechnician(req.params.id);
      invalidateTechniciansCache();
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting technician:", error);
      if (error.code === "23503" && error.table === "time_entries") {
        return res.status(400).json({
          error: "N\xE3o \xE9 poss\xEDvel excluir este t\xE9cnico porque existem registros de horas vinculados \xE0s suas atividades. Para excluir, primeiro voc\xEA precisa remover os registros de horas associados."
        });
      }
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/sites/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateClientSiteSchema.parse(req.body);
      const site = await storage.updateClientSite(req.params.id, data);
      res.json(site);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/sites/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteClientSite(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activity-types", authMiddleware, async (req, res) => {
    try {
      const types = await storage.getAllActivityTypes();
      res.json(types);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activity-types/tree", authMiddleware, async (req, res) => {
    try {
      const types = await storage.getAllActivityTypes();
      const mainCategories = types.filter((t) => !t.parentId);
      const subcategories = types.filter((t) => t.parentId);
      const tree = mainCategories.map((main) => ({
        ...main,
        children: subcategories.filter((sub) => sub.parentId === main.id)
      }));
      res.json(tree);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activity-types", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertActivityTypeSchema.parse(req.body);
      const type = await storage.createActivityType(data);
      res.status(201).json(type);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/activity-types/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateActivityTypeSchema.parse(req.body);
      const type = await storage.updateActivityType(req.params.id, data);
      res.json(type);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.patch("/api/activity-types/:id/requires-travel", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { requiresTravel } = req.body;
      if (typeof requiresTravel !== "boolean") {
        return res.status(400).json({ error: "requiresTravel deve ser um booleano" });
      }
      const type = await storage.updateActivityType(req.params.id, { requiresTravel });
      res.json(type);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activity-types/:id/toggle-requires-travel", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { requiresTravel } = req.body;
      if (typeof requiresTravel !== "boolean") {
        return res.status(400).json({ error: "requiresTravel deve ser um booleano" });
      }
      const type = await storage.updateActivityType(req.params.id, { requiresTravel });
      res.json(type);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/activity-types/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteActivityType(req.params.id);
      res.status(204).send();
    } catch (error) {
      if (error.message?.includes("foreign key constraint") || error.code === "23503") {
        return res.status(400).json({
          error: "N\xE3o \xE9 poss\xEDvel excluir este tipo de atividade porque existem atividades vinculadas a ele. Remova ou altere as atividades primeiro."
        });
      }
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/segments", authMiddleware, async (req, res) => {
    try {
      const segments2 = await storage.getAllSegments();
      res.json(segments2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/segments", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertSegmentSchema.parse(req.body);
      const segment = await storage.createSegment(data);
      res.status(201).json(segment);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/segments/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateSegmentSchema.parse(req.body);
      const segment = await storage.updateSegment(req.params.id, data);
      res.json(segment);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/segments/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteSegment(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/regions", authMiddleware, async (req, res) => {
    try {
      const regions2 = await storage.getAllRegions();
      res.json(regions2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/regions", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertRegionSchema.parse(req.body);
      const region = await storage.createRegion(data);
      res.status(201).json(region);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/regions/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateRegionSchema.parse(req.body);
      const region = await storage.updateRegion(req.params.id, data);
      res.json(region);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/regions/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteRegion(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities", authMiddleware, agendaScopeMiddleware, async (req, res) => {
    try {
      const { startDate, endDate, technicianId, userId } = req.query;
      console.log(`[Activities] Request user role: ${req.user?.role}, userId from query: ${userId}, technicianId: ${technicianId}`);
      let normalizedStartDate = startDate;
      let normalizedEndDate = endDate;
      if (startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const daysDiff = (end.getTime() - start.getTime()) / (1e3 * 60 * 60 * 24);
        if (daysDiff >= 85 && daysDiff <= 95) {
          normalizedStartDate = void 0;
          normalizedEndDate = void 0;
          console.log(`[Activities cache] Normalizing ${daysDiff.toFixed(0)}-day request to 90-day cache key`);
        }
      }
      const cacheKey = normalizedStartDate && normalizedEndDate ? `${userId || technicianId || "default"}:${normalizedStartDate}:${normalizedEndDate}` : `${userId || technicianId || "default"}:all:all`;
      let activities2 = [];
      const cached = _activitiesCache.get(cacheKey);
      if (cached) {
        console.log(`[Activities cache] SERVING CACHED: key="${cacheKey}" (${cached.data.length} items)`);
        res.json(cached.data);
        const age = Date.now() - cached.ts;
        if (age > ACTIVITIES_CACHE_TTL) {
          const queryFn = async () => {
            if (userId) {
              const technicians2 = await storage.getAllTechnicians();
              const technician = technicians2.find((t) => t.userId === userId);
              console.log(`[Activities cache] BG: Found technician for userId ${userId}: ${technician ? technician.id : "NOT FOUND"}`);
              return technician ? await storage.getActivitiesByTechnicianId(technician.id) : [];
            } else if (normalizedStartDate && normalizedEndDate) {
              return await storage.getActivitiesByDateRange(
                new Date(normalizedStartDate),
                new Date(normalizedEndDate)
              );
            } else if (startDate && endDate && (!normalizedStartDate && !normalizedEndDate)) {
              return await storage.getActivitiesByDateRange(
                new Date(startDate),
                new Date(endDate)
              );
            } else if (technicianId) {
              return await storage.getActivitiesByTechnicianId(technicianId);
            } else {
              const now = /* @__PURE__ */ new Date();
              const ninetyDaysAgo = new Date(now);
              ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
              ninetyDaysAgo.setHours(0, 0, 0, 0);
              now.setHours(23, 59, 59, 999);
              return await storage.getActivitiesByDateRange(ninetyDaysAgo, now);
            }
          };
          _bgRefreshActivitiesCache(cacheKey, queryFn).catch(() => {
          });
        }
        return;
      }
      if (userId) {
        const technicians2 = await storage.getAllTechnicians();
        const technician = technicians2.find((t) => t.userId === userId);
        console.log(`[Activities] Finding technician for userId ${userId}. Found: ${technician ? technician.id : "NOT FOUND"}`);
        if (technician) {
          activities2 = await storage.getActivitiesByTechnicianId(technician.id);
        } else {
          activities2 = [];
        }
      } else if (normalizedStartDate && normalizedEndDate) {
        activities2 = await storage.getActivitiesByDateRange(
          new Date(normalizedStartDate),
          new Date(normalizedEndDate)
        );
      } else if (startDate && endDate) {
        activities2 = await storage.getActivitiesByDateRange(
          new Date(startDate),
          new Date(endDate)
        );
      } else if (technicianId) {
        activities2 = await storage.getActivitiesByTechnicianId(technicianId);
      } else {
        const now = /* @__PURE__ */ new Date();
        const ninetyDaysAgo = new Date(now);
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
        ninetyDaysAgo.setHours(0, 0, 0, 0);
        now.setHours(23, 59, 59, 999);
        activities2 = await storage.getActivitiesByDateRange(ninetyDaysAgo, now);
      }
      _activitiesCache.set(cacheKey, { data: activities2, ts: Date.now() });
      console.log(`[Activities cache] key="${cacheKey}" (${activities2.length} items, fetched fresh)`);
      res.json(activities2);
    } catch (error) {
      console.error("[Activities] Error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities/:id", authMiddleware, async (req, res) => {
    try {
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      res.json(activity);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities", authMiddleware, async (req, res) => {
    try {
      const data = insertActivitySchema.parse(req.body);
      const getDateString = (date) => {
        if (!date) return "";
        if (date instanceof Date) {
          return date.toISOString().split("T")[0];
        }
        const dateStr = String(date);
        return dateStr.split("T")[0].split(" ")[0];
      };
      if (data.startTime && data.endTime && data.endTime <= data.startTime) {
        return res.status(400).json({
          error: `Hor\xE1rio inv\xE1lido: o hor\xE1rio de t\xE9rmino (${data.endTime}) deve ser posterior ao hor\xE1rio de in\xEDcio (${data.startTime})`
        });
      }
      const ignoreBlock = req.body?.ignoreBlock === true;
      if (data.technicianId && data.scheduledDate) {
        const bStart = new Date(data.scheduledDate);
        bStart.setHours(0, 0, 0, 0);
        const bEnd = data.endDate ? new Date(data.endDate) : new Date(data.scheduledDate);
        bEnd.setHours(23, 59, 59, 999);
        const overlapBlocks = await storage.getAgendaBlocksByDateRange(bStart, bEnd);
        const techBlocks = overlapBlocks.filter((b) => b.technicianId === data.technicianId);
        const toMin = (t) => {
          if (!t) return null;
          const m = t.match(/^(\d{1,2}):(\d{2})/);
          return m ? parseInt(m[1], 10) * 60 + parseInt(m[2], 10) : null;
        };
        const feriasHit = techBlocks.find((b) => b.blockType === "ferias");
        if (feriasHit) {
          return res.status(409).json({
            code: "AGENDA_BLOCK_FERIAS",
            error: "O t\xE9cnico est\xE1 de f\xE9rias neste per\xEDodo. N\xE3o \xE9 poss\xEDvel agendar."
          });
        }
        if (!ignoreBlock) {
          const compHit = techBlocks.find((b) => {
            if (b.blockType !== "compromisso") return false;
            const bs = toMin(b.startTime);
            const be = toMin(b.endTime);
            const as = toMin(data.startTime);
            const ae = toMin(data.endTime || data.startTime);
            if (bs === null || be === null || as === null || ae === null) return true;
            return as < be && ae > bs;
          });
          if (compHit) {
            return res.status(409).json({
              code: "AGENDA_BLOCK",
              blockType: "compromisso",
              error: "O t\xE9cnico tem um compromisso pessoal neste hor\xE1rio."
            });
          }
        }
      }
      if (data.technicianId && data.scheduledDate && data.startTime) {
        {
          const scheduledDate = new Date(data.scheduledDate);
          const newScheduledDateStr = getDateString(data.scheduledDate);
          const newEndDateStr = data.endDate ? getDateString(data.endDate) : newScheduledDateStr;
          const rangeStart = new Date(scheduledDate);
          rangeStart.setHours(0, 0, 0, 0);
          const rangeEnd = data.endDate ? new Date(data.endDate) : new Date(scheduledDate);
          rangeEnd.setHours(23, 59, 59, 999);
          const existingActivities = await storage.getActivitiesByDateRange(rangeStart, rangeEnd);
          const technicianActivities = existingActivities.filter(
            (a) => a.technicianId === data.technicianId && a.status !== "cancelado"
          );
          const newStart = data.startTime;
          const newEnd = data.endTime || data.startTime;
          const getDaysInRange = (start, end) => {
            const days = [];
            const d = /* @__PURE__ */ new Date(start + "T00:00:00");
            const last = /* @__PURE__ */ new Date(end + "T00:00:00");
            while (d <= last) {
              days.push(d.toISOString().split("T")[0]);
              d.setDate(d.getDate() + 1);
            }
            return days;
          };
          const newDays = getDaysInRange(newScheduledDateStr, newEndDateStr);
          for (const existing of technicianActivities) {
            const existingStart = existing.startTime;
            const existingEnd = existing.endTime || existing.startTime;
            const existingDateStr = getDateString(existing.scheduledDate);
            const existingEndDateStr = existing.endDate ? getDateString(existing.endDate) : existingDateStr;
            const existingDays = getDaysInRange(existingDateStr, existingEndDateStr);
            const overlappingDays = newDays.filter((d) => existingDays.includes(d));
            if (overlappingDays.length === 0) continue;
            const hasTimeOverlap = newStart < existingEnd && newEnd > existingStart || newStart === existingStart;
            if (hasTimeOverlap) {
              const conflictDay = overlappingDays[0];
              const [cy, cm, cd] = conflictDay.split("-");
              const formattedDate = `${cd}/${cm}/${cy}`;
              return res.status(409).json({
                error: `Conflito de hor\xE1rio: j\xE1 existe uma atividade agendada para este t\xE9cnico em ${formattedDate} das ${existingStart} \xE0s ${existingEnd} (${existing.clientName || existing.description || "Atividade existente"})`
              });
            }
          }
        }
      }
      if (!data.latitude && !data.longitude && data.address) {
        const fullAddress = [
          data.address,
          data.numero,
          data.bairro,
          data.city,
          data.state,
          data.country || "Brasil"
        ].filter(Boolean).join(", ");
        try {
          const geocoded = await geocodeAddress(fullAddress);
          if (geocoded.found) {
            data.latitude = geocoded.latitude.toString();
            data.longitude = geocoded.longitude.toString();
            console.log(`\u{1F4CD} Auto-geocoded activity address: ${fullAddress} -> (${geocoded.latitude}, ${geocoded.longitude})`);
          }
        } catch (geoError) {
          console.error("Failed to geocode activity address:", geoError);
        }
      }
      const activity = await storage.createActivity(data);
      invalidateActivitiesCache();
      await storage.createAuditLog({
        userId: req.user.userId,
        action: "CREATE",
        entityType: "activity",
        entityId: activity.id,
        changes: JSON.stringify(data)
      });
      const { sendActivityCreatedNotification: sendActivityCreatedNotification2 } = await init_notifications().then(() => notifications_exports);
      sendActivityCreatedNotification2(activity.id, req.user.userId).catch((err) => {
        console.error("Failed to send activity creation notification:", err);
      });
      broadcastActivityUpdate(activity, "created");
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/activities/:id", authMiddleware, async (req, res) => {
    try {
      console.log("[PUT /api/activities/:id] Request body:", JSON.stringify(req.body, null, 2));
      const data = updateActivitySchema.parse(req.body);
      console.log("[PUT /api/activities/:id] Parsed data:", JSON.stringify(data, null, 2));
      const activityId = req.params.id;
      const getDateString = (date) => {
        if (!date) return "";
        if (date instanceof Date) {
          return date.toISOString().split("T")[0];
        }
        const dateStr = String(date);
        return dateStr.split("T")[0].split(" ")[0];
      };
      const currentActivity = await storage.getActivity(activityId);
      if (currentActivity) {
        const technicianId = data.technicianId || currentActivity.technicianId;
        const scheduledDateInput = data.scheduledDate || currentActivity.scheduledDate;
        const startTime = data.startTime || currentActivity.startTime;
        const endTime = data.endTime || currentActivity.endTime;
        const endDateInput = data.endDate !== void 0 ? data.endDate : currentActivity.endDate;
        if (startTime && endTime && endTime <= startTime) {
          return res.status(400).json({
            error: `Hor\xE1rio inv\xE1lido: o hor\xE1rio de t\xE9rmino (${endTime}) deve ser posterior ao hor\xE1rio de in\xEDcio (${startTime})`
          });
        }
        const ignoreBlockPut = req.body?.ignoreBlock === true;
        if (technicianId && scheduledDateInput) {
          const bStart = new Date(scheduledDateInput);
          bStart.setHours(0, 0, 0, 0);
          const bEnd = endDateInput ? new Date(endDateInput) : new Date(scheduledDateInput);
          bEnd.setHours(23, 59, 59, 999);
          const overlapBlocks = await storage.getAgendaBlocksByDateRange(bStart, bEnd);
          const techBlocks = overlapBlocks.filter((b) => b.technicianId === technicianId);
          const toMin = (t) => {
            if (!t) return null;
            const m = t.match(/^(\d{1,2}):(\d{2})/);
            return m ? parseInt(m[1], 10) * 60 + parseInt(m[2], 10) : null;
          };
          const feriasHit = techBlocks.find((b) => b.blockType === "ferias");
          if (feriasHit) {
            return res.status(409).json({
              code: "AGENDA_BLOCK_FERIAS",
              error: "O t\xE9cnico est\xE1 de f\xE9rias neste per\xEDodo. N\xE3o \xE9 poss\xEDvel agendar."
            });
          }
          if (!ignoreBlockPut) {
            const compHit = techBlocks.find((b) => {
              if (b.blockType !== "compromisso") return false;
              const bs = toMin(b.startTime);
              const be = toMin(b.endTime);
              const as = toMin(startTime);
              const ae = toMin(endTime || startTime);
              if (bs === null || be === null || as === null || ae === null) return true;
              return as < be && ae > bs;
            });
            if (compHit) {
              return res.status(409).json({
                code: "AGENDA_BLOCK",
                blockType: "compromisso",
                error: "O t\xE9cnico tem um compromisso pessoal neste hor\xE1rio."
              });
            }
          }
        }
        if (technicianId && scheduledDateInput && startTime) {
          const activityTypeId = data.activityTypeId || currentActivity.activityTypeId;
          let skipConflictCheck = false;
          if (activityTypeId) {
            const activityType = await storage.getActivityType(activityTypeId);
            if (activityType && activityType.category === "adicional") {
              skipConflictCheck = true;
            }
          }
          if (!skipConflictCheck) {
            const scheduledDate = new Date(scheduledDateInput);
            const newScheduledDateStr = getDateString(scheduledDateInput);
            const newEndDateStr = endDateInput ? getDateString(endDateInput) : newScheduledDateStr;
            const rangeStart = new Date(scheduledDate);
            rangeStart.setHours(0, 0, 0, 0);
            const rangeEnd = endDateInput ? new Date(endDateInput) : new Date(scheduledDate);
            rangeEnd.setHours(23, 59, 59, 999);
            const existingActivities = await storage.getActivitiesByDateRange(rangeStart, rangeEnd);
            const technicianActivities = existingActivities.filter(
              (a) => a.technicianId === technicianId && a.status !== "cancelado" && a.id !== activityId
            );
            const newStart = startTime;
            const newEnd = endTime || startTime;
            const getDaysInRange = (start, end) => {
              const days = [];
              const d = /* @__PURE__ */ new Date(start + "T00:00:00");
              const last = /* @__PURE__ */ new Date(end + "T00:00:00");
              while (d <= last) {
                days.push(d.toISOString().split("T")[0]);
                d.setDate(d.getDate() + 1);
              }
              return days;
            };
            const newDays = getDaysInRange(newScheduledDateStr, newEndDateStr);
            for (const existing of technicianActivities) {
              const existingStart = existing.startTime;
              const existingEnd = existing.endTime || existing.startTime;
              const existingDateStr = getDateString(existing.scheduledDate);
              const existingEndDateStr = existing.endDate ? getDateString(existing.endDate) : existingDateStr;
              const existingDays = getDaysInRange(existingDateStr, existingEndDateStr);
              const overlappingDays = newDays.filter((d) => existingDays.includes(d));
              if (overlappingDays.length === 0) continue;
              const hasTimeOverlap = newStart < existingEnd && newEnd > existingStart || newStart === existingStart;
              if (hasTimeOverlap) {
                const conflictDay = overlappingDays[0];
                const [cy, cm, cd] = conflictDay.split("-");
                const formattedDate = `${cd}/${cm}/${cy}`;
                return res.status(409).json({
                  error: `Conflito de hor\xE1rio: j\xE1 existe uma atividade agendada para este t\xE9cnico em ${formattedDate} das ${existingStart} \xE0s ${existingEnd} (${existing.clientName || existing.description || "Atividade existente"})`
                });
              }
            }
          }
        }
      }
      if (!data.latitude && !data.longitude && data.address) {
        const fullAddress = [
          data.address,
          data.numero,
          data.bairro,
          data.city,
          data.state,
          data.country || "Brasil"
        ].filter(Boolean).join(", ");
        try {
          const geocoded = await geocodeAddress(fullAddress);
          if (geocoded.found) {
            data.latitude = geocoded.latitude.toString();
            data.longitude = geocoded.longitude.toString();
            console.log(`\u{1F4CD} Auto-geocoded updated activity address: ${fullAddress} -> (${geocoded.latitude}, ${geocoded.longitude})`);
          }
        } catch (geoError) {
          console.error("Failed to geocode activity address:", geoError);
        }
      }
      if (data.status === "aCaminho") {
        const existingActivity = await storage.getActivity(req.params.id);
        if (existingActivity && !existingActivity.navigationStartTime) {
          data.navigationStartTime = /* @__PURE__ */ new Date();
          console.log(`\u{1F697} NAVIGATION START - Activity ${req.params.id}, Time: ${(/* @__PURE__ */ new Date()).toISOString()}`);
        }
      }
      const activity = await storage.updateActivity(req.params.id, data);
      invalidateActivitiesCache();
      await storage.createAuditLog({
        userId: req.user.userId,
        action: "UPDATE",
        entityType: "activity",
        entityId: activity.id,
        changes: JSON.stringify(data)
      });
      broadcastActivityUpdate(activity, "updated");
      res.json(activity);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/activities/:id", authMiddleware, async (req, res) => {
    try {
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Atividade n\xE3o encontrada" });
      }
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(403).json({ error: "Usu\xE1rio n\xE3o autorizado" });
      }
      const isAdmin = user.role === "admin";
      const userTechnician = await storage.getTechnicianByUserId(user.id);
      const isOwner = activity.technicianId && userTechnician?.id === activity.technicianId;
      console.log(`[DELETE /api/activities] User: ${user.id}, Role: ${user.role}, isAdmin: ${isAdmin}, UserTechnicianId: ${userTechnician?.id}, ActivityTechnicianId: ${activity.technicianId}, isOwner: ${isOwner}`);
      if (!isAdmin && !isOwner) {
        return res.status(403).json({ error: "Voc\xEA n\xE3o tem permiss\xE3o para excluir esta atividade" });
      }
      if (activity.status === "concluido" || activity.status === "cancelado") {
        return res.status(400).json({
          error: `N\xE3o \xE9 poss\xEDvel excluir atividades com status "${activity.status}". Apenas atividades planejadas, a caminho ou em execu\xE7\xE3o podem ser exclu\xEDdas.`
        });
      }
      const actId = req.params.id;
      await db.update(timeEntries2).set({ agendaActivityId: null }).where(eq5(timeEntries2.agendaActivityId, actId));
      await db.update(travelSegments).set({ agendaActivityId: null }).where(eq5(travelSegments.agendaActivityId, actId));
      await db.delete(approvals).where(eq5(approvals.activityId, actId));
      await db.delete(activityAttachments).where(eq5(activityAttachments.activityId, actId));
      await storage.deleteActivity(actId);
      invalidateActivitiesCache();
      await storage.createAuditLog({
        userId: req.user.userId,
        action: "DELETE",
        entityType: "activity",
        entityId: req.params.id,
        changes: null
      });
      broadcastActivityUpdate(activity, "deleted");
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/delete", authMiddleware, async (req, res) => {
    try {
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Atividade n\xE3o encontrada" });
      }
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(403).json({ error: "Usu\xE1rio n\xE3o autorizado" });
      }
      const isAdmin = user.role === "admin";
      const userTechnician = await storage.getTechnicianByUserId(user.id);
      const isOwner = activity.technicianId && userTechnician?.id === activity.technicianId;
      console.log(`[POST /api/activities/:id/delete] User: ${user.id}, Role: ${user.role}, isAdmin: ${isAdmin}, UserTechnicianId: ${userTechnician?.id}, ActivityTechnicianId: ${activity.technicianId}, isOwner: ${isOwner}`);
      if (!isAdmin && !isOwner) {
        return res.status(403).json({ error: "Voc\xEA n\xE3o tem permiss\xE3o para excluir esta atividade" });
      }
      if (activity.status === "concluido" || activity.status === "cancelado") {
        return res.status(400).json({
          error: `N\xE3o \xE9 poss\xEDvel excluir atividades com status "${activity.status}". Apenas atividades planejadas, a caminho ou em execu\xE7\xE3o podem ser exclu\xEDdas.`
        });
      }
      const actId = req.params.id;
      await db.update(timeEntries2).set({ agendaActivityId: null }).where(eq5(timeEntries2.agendaActivityId, actId));
      await db.update(travelSegments).set({ agendaActivityId: null }).where(eq5(travelSegments.agendaActivityId, actId));
      await db.delete(approvals).where(eq5(approvals.activityId, actId));
      await db.delete(activityAttachments).where(eq5(activityAttachments.activityId, actId));
      await storage.deleteActivity(actId);
      invalidateActivitiesCache();
      await storage.createAuditLog({
        userId: req.user.userId,
        action: "DELETE",
        entityType: "activity",
        entityId: req.params.id,
        changes: null
      });
      broadcastActivityUpdate(activity, "deleted");
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/approvals", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { status } = req.query;
      if (status === "pendente") {
        const approvals2 = await storage.getPendingApprovals();
        res.json(approvals2);
      } else {
        const approvals2 = await storage.getPendingApprovals();
        res.json(approvals2);
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/approvals", authMiddleware, async (req, res) => {
    try {
      const data = insertApprovalSchema.parse({
        ...req.body,
        submittedBy: req.user.userId
      });
      const approval = await storage.createApproval(data);
      res.status(201).json(approval);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/approvals/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateApprovalSchema.parse(req.body);
      const approval = await storage.updateApproval(req.params.id, {
        ...data,
        reviewedBy: req.user.userId,
        reviewedAt: /* @__PURE__ */ new Date()
      });
      res.json(approval);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/day-markers", authMiddleware, async (req, res) => {
    try {
      const { startDate, endDate, technicianId } = req.query;
      let markers = [];
      if (startDate && endDate) {
        markers = await storage.getDayMarkersByDateRange(
          new Date(startDate),
          new Date(endDate)
        );
      } else if (technicianId) {
        markers = await storage.getDayMarkersByTechnicianId(technicianId);
      }
      res.json(markers);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/day-markers", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertDayMarkerSchema.parse(req.body);
      const marker = await storage.createDayMarker(data);
      res.status(201).json(marker);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/day-markers/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteDayMarker(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/agenda-blocks", authMiddleware, async (req, res) => {
    try {
      const { startDate, endDate, technicianId } = req.query;
      let blocks = [];
      if (startDate && endDate) {
        const dateOnly = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s);
        const startStr = startDate;
        const endStr = endDate;
        const start = dateOnly(startStr) ? /* @__PURE__ */ new Date(`${startStr}T00:00:00`) : (() => {
          const d = new Date(startStr);
          d.setHours(0, 0, 0, 0);
          return d;
        })();
        const end = dateOnly(endStr) ? /* @__PURE__ */ new Date(`${endStr}T23:59:59.999`) : (() => {
          const d = new Date(endStr);
          d.setHours(23, 59, 59, 999);
          return d;
        })();
        blocks = await storage.getAgendaBlocksByDateRange(start, end);
        if (req.user.role === "assistente") {
          const tech = await storage.getTechnicianByUserId(req.user.userId);
          if (tech) {
            blocks = blocks.filter((b) => b.technicianId === tech.id);
          } else {
            blocks = [];
          }
        }
      } else if (technicianId) {
        blocks = await storage.getAgendaBlocksByTechnicianId(technicianId);
      }
      res.json(blocks);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/agenda-blocks", authMiddleware, async (req, res) => {
    try {
      const data = insertAgendaBlockSchema.parse(req.body);
      if (req.user.role === "assistente") {
        const tech = await storage.getTechnicianByUserId(req.user.userId);
        if (!tech) {
          return res.status(400).json({ error: "T\xE9cnico n\xE3o encontrado para este usu\xE1rio." });
        }
        data.technicianId = tech.id;
      } else if (!data.technicianId) {
        return res.status(400).json({ error: "Selecione o t\xE9cnico." });
      }
      data.createdBy = req.user.userId;
      const block = await storage.createAgendaBlock(data);
      res.status(201).json(block);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/agenda-blocks/:id", authMiddleware, async (req, res) => {
    try {
      const block = await storage.getAgendaBlock(req.params.id);
      if (!block) {
        return res.status(404).json({ error: "Bloqueio n\xE3o encontrado." });
      }
      if (req.user.role === "assistente") {
        const tech = await storage.getTechnicianByUserId(req.user.userId);
        if (!tech || block.technicianId !== tech.id) {
          return res.status(403).json({ error: "N\xE3o autorizado a excluir este bloqueio." });
        }
      }
      await storage.deleteAgendaBlock(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/analytics/kpis", authMiddleware, async (req, res) => {
    try {
      const { startDate, endDate, technicianId } = req.query;
      const activities2 = await storage.getActivitiesByDateRange(
        new Date(startDate || new Date((/* @__PURE__ */ new Date()).getFullYear(), (/* @__PURE__ */ new Date()).getMonth(), 1)),
        new Date(endDate || /* @__PURE__ */ new Date())
      );
      res.json({
        totalHours: 0,
        efetivoPct: 0,
        adicionalPct: 0,
        perdaPct: 0,
        activitiesCount: activities2.length
      });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/technicians/:id/last-location", authMiddleware, async (req, res) => {
    try {
      const location = await storage.getLastTechnicianLocation(req.params.id);
      if (!location) {
        return res.status(404).json({ error: "No location found for this technician" });
      }
      res.json(location);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/technicians/:id/location", authMiddleware, async (req, res) => {
    try {
      const data = insertTechnicianLocationSchema.parse({
        ...req.body,
        technicianId: req.params.id
      });
      const location = await storage.createTechnicianLocation(data);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.patch("/api/technicians/:id/gps-status", authMiddleware, async (req, res) => {
    try {
      const { gpsStatus, connectionStatus } = req.body;
      if (!gpsStatus || !connectionStatus) {
        return res.status(400).json({ error: "gpsStatus and connectionStatus are required" });
      }
      const technician = await storage.getTechnician(req.params.id);
      if (!technician) {
        return res.status(404).json({ error: "T\xE9cnico n\xE3o encontrado." });
      }
      if (req.user.role !== "admin" && req.user.userId !== technician.userId) {
        return res.status(403).json({ error: "Unauthorized: you can only update your own GPS status" });
      }
      const lastLocation = await storage.getLastTechnicianLocation(req.params.id);
      if (!lastLocation) {
        return res.status(404).json({ error: "No previous location found for this technician" });
      }
      const data = insertTechnicianLocationSchema.parse({
        technicianId: req.params.id,
        latitude: lastLocation.latitude,
        longitude: lastLocation.longitude,
        accuracy: lastLocation.accuracy || 0,
        battery: lastLocation.battery || 0,
        gpsStatus,
        connectionStatus,
        deviceModel: lastLocation.deviceModel || ""
      });
      const location = await storage.createTechnicianLocation(data);
      broadcastLocationUpdate({
        technicianId: req.params.id,
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
        battery: location.battery,
        gpsStatus: location.gpsStatus,
        connectionStatus: location.connectionStatus,
        deviceModel: location.deviceModel
      });
      res.json(location);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/map/clients", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const { region, segment, search } = req.query;
      const clients2 = await storage.getClientsForMap({
        region,
        segment,
        search
      });
      res.json(clients2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/map/filters/options", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const allClients = await storage.getClientsForMap({});
      const regions2 = Array.from(new Set(allClients.map((c) => c.region).filter(Boolean))).sort();
      const segments2 = Array.from(new Set(allClients.map((c) => c.segment).filter(Boolean))).sort();
      res.json({ regions: regions2, segments: segments2 });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/cep/:cep", async (req, res) => {
    try {
      const cleanCep = req.params.cep.replace(/\D/g, "");
      if (cleanCep.length !== 8) {
        return res.status(400).json({ error: "CEP deve ter 8 d\xEDgitos" });
      }
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Erro ao buscar CEP:", error);
      res.status(500).json({ error: "Erro ao buscar CEP" });
    }
  });
  app2.get("/api/clients", authMiddleware, async (req, res) => {
    try {
      const { page, limit, search, region, segment, active } = req.query;
      console.log(`[/api/clients] User role: ${req.user?.role}, userId: ${req.user?.userId}, limit: ${limit}`);
      const parsedPage = page ? parseInt(page) : 1;
      const parsedLimit = limit ? parseInt(limit) : 50;
      if (isNaN(parsedPage) || parsedPage < 1) {
        return res.status(400).json({ error: "Invalid page number" });
      }
      if (isNaN(parsedLimit) || parsedLimit < 1 || parsedLimit > 1e4) {
        return res.status(400).json({ error: "Limit must be between 1 and 10000" });
      }
      const result = await storage.listClients({
        page: parsedPage,
        limit: parsedLimit,
        search,
        region,
        segment,
        active: active !== void 0 ? active === "true" : void 0
      });
      console.log(`[/api/clients] Returning ${result.clients.length} clients`);
      res.json(result);
    } catch (error) {
      console.error("[/api/clients] Error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/clients/geocode-status", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const allClients = await storage.getAllClients();
      const withCoords = allClients.filter(
        (c) => c.latitude && c.longitude && c.latitude !== "" && c.longitude !== ""
      );
      const withoutCoords = allClients.filter(
        (c) => !c.latitude || !c.longitude || c.latitude === "" || c.longitude === ""
      );
      res.json({
        total: allClients.length,
        withCoordinates: withCoords.length,
        withoutCoordinates: withoutCoords.length
      });
    } catch (error) {
      console.error("Geocode status error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/clients/geocode-batch", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const BATCH_SIZE = 100;
      const allClients = await storage.getAllClients();
      const clientsWithoutCoords = allClients.filter(
        (c) => !c.latitude || !c.longitude || c.latitude === "" || c.longitude === ""
      );
      const totalWithoutCoords = clientsWithoutCoords.length;
      const totalWithCoords = allClients.length - totalWithoutCoords;
      if (clientsWithoutCoords.length === 0) {
        return res.json({
          message: "Todos os clientes j\xE1 possuem coordenadas",
          processed: 0,
          success: 0,
          failed: 0,
          remaining: 0,
          totalClients: allClients.length,
          totalWithCoordinates: totalWithCoords,
          isComplete: true
        });
      }
      const batchToProcess = clientsWithoutCoords.slice(0, BATCH_SIZE);
      let successCount = 0;
      let failedCount = 0;
      let mapboxCount = 0;
      let nominatimCount = 0;
      const results = [];
      console.log(`[Geocode Batch] Processing ${batchToProcess.length} of ${totalWithoutCoords} clients (using Mapbox primary)`);
      for (const client2 of batchToProcess) {
        try {
          const addressParts = [
            client2.address,
            client2.numero,
            client2.bairro,
            client2.city,
            client2.state,
            "Brasil"
          ].filter(Boolean);
          if (addressParts.length < 2) {
            results.push({
              clientId: client2.id,
              companyName: client2.companyName,
              success: false,
              error: "Endere\xE7o insuficiente"
            });
            failedCount++;
            continue;
          }
          const geocodeResult = await geocodeAddress(
            client2.address || "",
            client2.numero || "",
            client2.bairro || "",
            client2.city || "",
            client2.state || "",
            "Brasil"
          );
          if (geocodeResult.found && geocodeResult.latitude && geocodeResult.longitude) {
            await storage.updateClient(client2.id, {
              latitude: geocodeResult.latitude.toString(),
              longitude: geocodeResult.longitude.toString()
            });
            results.push({
              clientId: client2.id,
              companyName: client2.companyName,
              success: true,
              source: geocodeResult.source
            });
            successCount++;
            if (geocodeResult.source === "mapbox") mapboxCount++;
            if (geocodeResult.source === "nominatim") nominatimCount++;
            console.log(`[Geocode Batch] \u2713 ${client2.companyName} (${geocodeResult.source})`);
          } else {
            results.push({
              clientId: client2.id,
              companyName: client2.companyName,
              success: false,
              error: "Coordenadas n\xE3o encontradas"
            });
            failedCount++;
            console.log(`[Geocode Batch] \u2717 ${client2.companyName} - n\xE3o encontrado`);
          }
          await new Promise((resolve) => setTimeout(resolve, 100));
        } catch (error) {
          results.push({
            clientId: client2.id,
            companyName: client2.companyName,
            success: false,
            error: error.message
          });
          failedCount++;
          console.log(`[Geocode Batch] \u2717 ${client2.companyName} - erro: ${error.message}`);
        }
      }
      const remaining = totalWithoutCoords - batchToProcess.length;
      const newTotalWithCoords = totalWithCoords + successCount;
      console.log(`[Geocode Batch] Completed: ${successCount} success (Mapbox: ${mapboxCount}, Nominatim: ${nominatimCount}), ${failedCount} failed, ${remaining} remaining`);
      res.json({
        message: remaining > 0 ? `Lote processado (Mapbox: ${mapboxCount}, Nominatim: ${nominatimCount}). Clique novamente para continuar.` : `Geocodifica\xE7\xE3o conclu\xEDda!`,
        processed: batchToProcess.length,
        success: successCount,
        failed: failedCount,
        remaining,
        totalClients: allClients.length,
        totalWithCoordinates: newTotalWithCoords,
        isComplete: remaining === 0,
        mapboxCount,
        nominatimCount,
        results
      });
    } catch (error) {
      console.error("Batch geocoding error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/clients/:id", authMiddleware, async (req, res) => {
    try {
      const client2 = await storage.getClient(req.params.id);
      if (!client2) {
        return res.status(404).json({ error: "Cliente n\xE3o encontrado" });
      }
      res.json(client2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/clients", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertClientSchema.parse(req.body);
      if ((data.address || data.city) && (!data.latitude || !data.longitude)) {
        try {
          const geocodeResult = await geocodeAddress(
            data.address || "",
            data.numero || "",
            data.bairro || "",
            data.city || "",
            data.state || "",
            data.country || "Brasil"
          );
          if (geocodeResult.found && geocodeResult.latitude && geocodeResult.longitude) {
            data.latitude = geocodeResult.latitude.toString();
            data.longitude = geocodeResult.longitude.toString();
            console.log(`[Auto-Geocode] Cliente geocodificado: ${data.companyName}`);
          }
        } catch (geoError) {
          console.log(`[Auto-Geocode] Falha ao geocodificar: ${data.companyName}`, geoError);
        }
      }
      const client2 = await storage.createClient(data);
      res.status(201).json(client2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/clients/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateClientSchema.parse(req.body);
      const addressChanged = data.address !== void 0 || data.numero !== void 0 || data.bairro !== void 0 || data.city !== void 0 || data.state !== void 0;
      const noCoordinates = !data.latitude || !data.longitude;
      if (addressChanged && noCoordinates) {
        const currentClient = await storage.getClient(req.params.id);
        if (currentClient) {
          const address = data.address ?? currentClient.address;
          const city = data.city ?? currentClient.city;
          if (address || city) {
            try {
              const geocodeResult = await geocodeAddress(
                address || "",
                (data.numero ?? currentClient.numero) || "",
                (data.bairro ?? currentClient.bairro) || "",
                city || "",
                (data.state ?? currentClient.state) || "",
                (data.country ?? currentClient.country) || "Brasil"
              );
              if (geocodeResult.found && geocodeResult.latitude && geocodeResult.longitude) {
                data.latitude = geocodeResult.latitude.toString();
                data.longitude = geocodeResult.longitude.toString();
                console.log(`[Auto-Geocode] Cliente atualizado geocodificado: ${currentClient.companyName}`);
              }
            } catch (geoError) {
              console.log(`[Auto-Geocode] Falha ao geocodificar atualiza\xE7\xE3o`, geoError);
            }
          }
        }
      }
      const client2 = await storage.updateClient(req.params.id, data);
      res.json(client2);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/clients/:id/regeocode", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const client2 = await storage.getClient(req.params.id);
      if (!client2) {
        return res.status(404).json({ error: "Cliente n\xE3o encontrado" });
      }
      if (client2.address || client2.city) {
        const geocodeResult = await geocodeAddress(
          client2.address || "",
          client2.numero || "",
          client2.bairro || "",
          client2.city || "",
          client2.state || "",
          client2.country || "Brasil"
        );
        if (geocodeResult.found) {
          const updatedClient = await storage.updateClient(req.params.id, {
            latitude: geocodeResult.latitude.toString(),
            longitude: geocodeResult.longitude.toString()
          });
          res.json({
            success: true,
            message: "Localiza\xE7\xE3o atualizada com sucesso",
            client: updatedClient,
            geocode: geocodeResult
          });
        } else {
          res.status(400).json({
            success: false,
            message: "N\xE3o foi poss\xEDvel encontrar coordenadas para este endere\xE7o"
          });
        }
      } else {
        res.status(400).json({
          success: false,
          message: "Cliente n\xE3o possui endere\xE7o cadastrado"
        });
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/clients/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteClient(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/clients/:id/sites", authMiddleware, async (req, res) => {
    try {
      const sites = await storage.getClientSitesByClientId(req.params.id);
      res.json(sites);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/clients/:id/sites", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = insertClientSiteSchema.parse({
        ...req.body,
        clientId: req.params.id
      });
      const site = await storage.createClientSite(data);
      res.status(201).json(site);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/sites/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const data = updateClientSiteSchema.parse(req.body);
      const site = await storage.updateClientSite(req.params.id, data);
      res.json(site);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/sites/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      await storage.deleteClientSite(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/clients/import", authMiddleware, roleMiddleware(["admin"]), upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const jsonData = JSON.parse(req.body.data || "[]");
      const getField = (row, ...keys) => {
        for (const key of keys) {
          if (row[key] !== void 0 && row[key] !== null && row[key] !== "") return row[key];
          if (row[key.toUpperCase()] !== void 0 && row[key.toUpperCase()] !== null && row[key.toUpperCase()] !== "") return row[key.toUpperCase()];
          if (row[key.toLowerCase()] !== void 0 && row[key.toLowerCase()] !== null && row[key.toLowerCase()] !== "") return row[key.toLowerCase()];
        }
        return "";
      };
      const toString = (val) => {
        if (val === void 0 || val === null || val === "") return "";
        return String(val);
      };
      const mapExcelRow = (row) => {
        return {
          companyName: toString(getField(row, "Nome da Empresa", "Cliente", "Raz\xE3o Social", "Empresa", "Nome", "NOME", "companyName")),
          cnpj: toString(getField(row, "CNPJ", "CPF/CNPJ", "cnpj")),
          internalCode: toString(getField(row, "CODIGO", "Codigo", "C\xF3digo", "Cod", "COD", "C\xE0DIGO", "internalCode")),
          region: toString(getField(row, "Regi\xE3o", "Regiao", "REGI\xC3O", "REGIAO", "region")),
          segment: toString(getField(row, "Neg\xF3cio", "Negocio", "Segmento", "SEGMENTO", "segment")),
          contactName: toString(getField(row, "Nome do Contato", "Contato", "CONTATO", "Respons\xE1vel", "Responsavel", "contactName")),
          contactPhone: toString(getField(row, "Telefone do Contato", "Telefone", "TELEFONE", "Fone", "Tel", "contactPhone")),
          contactEmail: toString(getField(row, "Email do Contato", "Email", "EMAIL", "E-mail", "contactEmail")),
          zipCode: toString(getField(row, "CEP", "Cep", "cep", "C\xF3digo Postal", "zipCode")),
          address: toString(getField(row, "Endere\xE7o", "Endereco", "Logradouro", "Rua", "RUA", "address")),
          numero: toString(getField(row, "N\xFAmero", "Numero", "n\xFAmero", "numero", "NUMERO", "N\xBA", "N\xB0")),
          bairro: toString(getField(row, "Bairro", "BAIRRO")),
          city: toString(getField(row, "Cidade", "CIDADE", "Municipio", "Munic\xEDpio", "city")),
          state: toString(getField(row, "Estado", "ESTADO", "UF", "state")),
          country: toString(getField(row, "Pa\xEDs", "Pais", "PAIS", "PA\xCDS", "PA\xD6S", "country")) || "Brasil",
          active: true
        };
      };
      const existingClients = await storage.getAllClients();
      const existingByCnpj = /* @__PURE__ */ new Map();
      const existingByCode = /* @__PURE__ */ new Map();
      existingClients.forEach((c) => {
        if (c.cnpj) existingByCnpj.set(c.cnpj.replace(/\D/g, ""), c.id);
        if (c.internalCode) existingByCode.set(c.internalCode, c.id);
      });
      const importedClients = [];
      const updatedClients = [];
      const invalidRows = [];
      const skippedRows = [];
      for (let i = 0; i < jsonData.length; i++) {
        try {
          const mappedData = mapExcelRow(jsonData[i]);
          const validatedData = insertClientSchema.parse(mappedData);
          const cnpjClean = validatedData.cnpj ? validatedData.cnpj.replace(/\D/g, "") : "";
          const existingIdByCnpj = cnpjClean ? existingByCnpj.get(cnpjClean) : void 0;
          const existingIdByCode = validatedData.internalCode ? existingByCode.get(validatedData.internalCode) : void 0;
          const existingId = existingIdByCnpj || existingIdByCode;
          if (existingId) {
            const client2 = await storage.updateClient(existingId, validatedData);
            updatedClients.push(client2);
          } else {
            const client2 = await storage.createClient(validatedData);
            importedClients.push(client2);
            if (cnpjClean) existingByCnpj.set(cnpjClean, client2.id);
            if (validatedData.internalCode) existingByCode.set(validatedData.internalCode, client2.id);
          }
        } catch (error) {
          const errors = error.errors?.map((e) => `${e.path.join(".")}: ${e.message}`) || [error.message];
          invalidRows.push({
            row: i + 2,
            // Excel row number (1 = header, 2 = first data row)
            errors
          });
        }
      }
      res.json({
        imported: importedClients.length,
        updated: updatedClients.length,
        total: jsonData.length,
        invalidRows,
        skippedRows
      });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/geo/parse-maps-url", authMiddleware, async (req, res) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== "string") {
        return res.status(400).json({ error: "URL is required" });
      }
      const parsed = parseGoogleMapsUrl(url);
      if (!parsed.latitude || !parsed.longitude) {
        return res.status(400).json({ error: "Could not extract coordinates from URL" });
      }
      if (!isValidCoordinates(parsed.latitude, parsed.longitude)) {
        return res.status(400).json({ error: "Coordenadas inv\xE1lidas." });
      }
      res.json(parsed);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  if (process.env.NODE_ENV === "development") {
    app2.post("/api/test/update-gps", async (req, res) => {
      try {
        const allTechs = await db.select().from(technicians);
        if (allTechs.length === 0) {
          return res.status(404).json({ error: "Nenhum t\xE9cnico encontrado" });
        }
        const tech = allTechs[0];
        const baseLat = -23.5505;
        const baseLng = -46.6333;
        const randomLat = baseLat + (Math.random() - 0.5) * 0.01;
        const randomLng = baseLng + (Math.random() - 0.5) * 0.01;
        const location = await storage.createTechnicianLocation({
          technicianId: tech.id,
          latitude: randomLat.toString(),
          longitude: randomLng.toString(),
          accuracy: Math.floor(Math.random() * 20) + 5,
          battery: Math.floor(Math.random() * 30) + 70,
          gpsStatus: "ativo",
          connectionStatus: "online",
          deviceModel: "Samsung Galaxy S21 (Teste)",
          androidVersion: "13",
          appVersion: "1.0.0",
          address: `Teste - S\xE3o Paulo, SP (${randomLat.toFixed(4)}, ${randomLng.toFixed(4)})`
        });
        broadcastLocationUpdate(location);
        console.log(`[Test GPS] Localiza\xE7\xE3o broadcast via WebSocket para ${tech.name}`);
        res.json({
          success: true,
          message: "Localiza\xE7\xE3o GPS simulada atualizada",
          location
        });
      } catch (error) {
        console.error("Erro ao simular GPS:", error);
        res.status(500).json({ error: error.message });
      }
    });
  }
  app2.post("/api/geocode", authMiddleware, async (req, res) => {
    try {
      const { address, numero, bairro, city, state, country } = req.body;
      if (!address && !city) {
        return res.status(400).json({ error: "Address or city is required" });
      }
      const result = await geocodeAddress(address, numero, bairro, city, state, country);
      res.json(result);
    } catch (error) {
      console.error("Geocoding error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/geocode/reverse", authMiddleware, async (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      if (!latitude || !longitude) {
        return res.status(400).json({ error: "Localiza\xE7\xE3o (latitude e longitude) \xE9 obrigat\xF3ria." });
      }
      const result = await reverseGeocode2(
        parseFloat(latitude),
        parseFloat(longitude)
      );
      res.json(result);
    } catch (error) {
      console.error("Reverse geocoding error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/routes/calculate", authMiddleware, async (req, res) => {
    try {
      const { waypoints, profile = "car" } = req.body;
      if (!waypoints || !Array.isArray(waypoints) || waypoints.length < 2) {
        return res.status(400).json({
          error: "At least 2 waypoints are required"
        });
      }
      const validWaypoints = waypoints.map((wp, index) => {
        if (!wp.latitude || !wp.longitude) {
          throw new Error(`Waypoint ${index} missing coordinates`);
        }
        return {
          latitude: parseFloat(wp.latitude),
          longitude: parseFloat(wp.longitude),
          name: wp.name
        };
      });
      const result = await calculateRoute(validWaypoints, profile);
      if (!result.success) {
        return res.status(400).json({
          error: "Failed to calculate route"
        });
      }
      res.json(result);
    } catch (error) {
      console.error("Route calculation error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/routes/optimize", authMiddleware, async (req, res) => {
    try {
      const { origin, waypoints, profile = "car" } = req.body;
      let allWaypoints;
      if (origin) {
        if (!origin.latitude || !origin.longitude) {
          return res.status(400).json({
            error: "Origin must have latitude and longitude"
          });
        }
        if (!waypoints || !Array.isArray(waypoints) || waypoints.length < 1) {
          return res.status(400).json({
            error: "At least 1 destination waypoint is required when using origin"
          });
        }
        const originWaypoint = {
          latitude: parseFloat(origin.latitude),
          longitude: parseFloat(origin.longitude),
          name: origin.name || "Origem"
        };
        const destinationWaypoints = waypoints.map((wp, index) => {
          if (!wp.latitude || !wp.longitude) {
            throw new Error(`Waypoint ${index} missing coordinates`);
          }
          return {
            latitude: parseFloat(wp.latitude),
            longitude: parseFloat(wp.longitude),
            name: wp.name
          };
        });
        allWaypoints = [originWaypoint, ...destinationWaypoints];
      } else {
        if (!waypoints || !Array.isArray(waypoints) || waypoints.length < 2) {
          return res.status(400).json({
            error: "At least 2 waypoints are required"
          });
        }
        allWaypoints = waypoints.map((wp, index) => {
          if (!wp.latitude || !wp.longitude) {
            throw new Error(`Waypoint ${index} missing coordinates`);
          }
          return {
            latitude: parseFloat(wp.latitude),
            longitude: parseFloat(wp.longitude),
            name: wp.name
          };
        });
      }
      const result = await calculateOptimizedRoute(allWaypoints, profile, origin ? { fixedStart: true } : {});
      if (!result.success) {
        return res.status(400).json({
          error: "Failed to optimize route"
        });
      }
      const response = {
        waypoints: result.waypoints.map((wp, idx) => ({
          waypoint_index: result.waypointOrder[idx],
          trips_index: 0,
          location: wp.location
        })),
        trips: [{
          legs: result.legs,
          distance: result.distance,
          duration: result.duration,
          geometry: result.geometry
        }]
      };
      res.json(response);
    } catch (error) {
      console.error("Route optimization error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/routes/navigation-links", authMiddleware, async (req, res) => {
    try {
      const { origin, destination, waypoints } = req.body;
      if (!origin || !destination) {
        return res.status(400).json({
          error: "Origin and destination are required"
        });
      }
      if (!origin.latitude || !origin.longitude || !destination.latitude || !destination.longitude) {
        return res.status(400).json({
          error: "Invalid coordinates"
        });
      }
      const links = generateNavigationLinks(
        {
          latitude: parseFloat(origin.latitude),
          longitude: parseFloat(origin.longitude)
        },
        {
          latitude: parseFloat(destination.latitude),
          longitude: parseFloat(destination.longitude)
        },
        waypoints
      );
      res.json(links);
    } catch (error) {
      console.error("Navigation links error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/time-activities", authMiddleware, async (req, res) => {
    try {
      const activities2 = await db.select().from(activityTypes).orderBy(activityTypes.displayOrder);
      res.json(activities2);
    } catch (error) {
      console.error("Get time activities error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/time-entries", authMiddleware, async (req, res) => {
    try {
      const { technicianId, startDate, endDate } = req.query;
      const conditions = [];
      if (req.user.role === "assistente") {
        const tech = await db.select().from(technicians).where(eq5(technicians.userId, req.user.userId)).limit(1);
        if (tech[0]) {
          conditions.push(eq5(timeEntries2.technicianId, tech[0].id));
        } else {
          return res.json([]);
        }
      } else if (technicianId) {
        conditions.push(eq5(timeEntries2.technicianId, technicianId));
      }
      if (startDate) {
        conditions.push(gte3(timeEntries2.workDate, new Date(startDate)));
      }
      if (endDate) {
        conditions.push(lte3(timeEntries2.workDate, new Date(endDate)));
      }
      const query = db.select({
        id: timeEntries2.id,
        technicianId: timeEntries2.technicianId,
        activityTypeId: timeEntries2.activityTypeId,
        workDate: timeEntries2.workDate,
        minutes: timeEntries2.minutes,
        source: timeEntries2.source,
        notes: timeEntries2.notes,
        activityName: activityTypes.name,
        category: activityTypes.category,
        color: activityTypes.color
      }).from(timeEntries2).innerJoin(activityTypes, eq5(timeEntries2.activityTypeId, activityTypes.id)).$dynamic();
      if (conditions.length > 0) {
        query.where(and3(...conditions));
      }
      const entries = await query.orderBy(timeEntries2.workDate);
      res.json(entries);
    } catch (error) {
      console.error("Get time entries error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/time-entries", authMiddleware, async (req, res) => {
    try {
      let data = insertTimeEntrySchema.parse(req.body);
      if (req.user.role === "assistente") {
        const tech = await db.select().from(technicians).where(eq5(technicians.userId, req.user.userId)).limit(1);
        if (!tech[0]) {
          return res.status(403).json({ error: "Technician profile not found" });
        }
        data = { ...data, technicianId: tech[0].id };
      }
      const dayTotal = await db.select({
        total: sql4`COALESCE(SUM(${timeEntries2.minutes}), 0)`
      }).from(timeEntries2).where(
        and3(
          eq5(timeEntries2.technicianId, data.technicianId),
          eq5(timeEntries2.workDate, data.workDate)
        )
      );
      if ((dayTotal[0]?.total || 0) + data.minutes > 1440) {
        return res.status(400).json({
          error: "Daily total cannot exceed 1440 minutes (24 hours)"
        });
      }
      const [entry] = await db.insert(timeEntries2).values(data).returning();
      res.status(201).json(entry);
    } catch (error) {
      console.error("Create time entry error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.patch("/api/time-entries/:id", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      let updates = insertTimeEntrySchema.partial().parse(req.body);
      const [existing] = await db.select().from(timeEntries2).where(eq5(timeEntries2.id, id)).limit(1);
      if (!existing) {
        return res.status(404).json({ error: "Time entry not found" });
      }
      if (req.user.role === "assistente") {
        const tech = await db.select().from(technicians).where(eq5(technicians.userId, req.user.userId)).limit(1);
        if (!tech[0] || existing.technicianId !== tech[0].id) {
          return res.status(403).json({ error: "Access denied" });
        }
        const { technicianId, ...safeUpdates } = updates;
        updates = safeUpdates;
      }
      if (updates.minutes !== void 0 || updates.workDate !== void 0) {
        const targetDate = updates.workDate || existing.workDate;
        const targetTechId = updates.technicianId || existing.technicianId;
        const newMinutes = updates.minutes ?? existing.minutes;
        const dayTotal = await db.select({
          total: sql4`COALESCE(SUM(${timeEntries2.minutes}), 0)`
        }).from(timeEntries2).where(
          and3(
            eq5(timeEntries2.technicianId, targetTechId),
            eq5(timeEntries2.workDate, targetDate),
            not(eq5(timeEntries2.id, id))
          )
        );
        if ((dayTotal[0]?.total || 0) + newMinutes > 1440) {
          return res.status(400).json({
            error: "Daily total cannot exceed 1440 minutes (24 hours)"
          });
        }
      }
      const [updated] = await db.update(timeEntries2).set(updates).where(eq5(timeEntries2.id, id)).returning();
      res.json(updated);
    } catch (error) {
      console.error("Update time entry error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/time-entries/:id", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      const [existing] = await db.select().from(timeEntries2).where(eq5(timeEntries2.id, id)).limit(1);
      if (!existing) {
        return res.status(404).json({ error: "Time entry not found" });
      }
      if (req.user.role === "assistente") {
        const tech = await db.select().from(technicians).where(eq5(technicians.userId, req.user.userId)).limit(1);
        if (!tech[0] || existing.technicianId !== tech[0].id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      await db.delete(timeEntries2).where(eq5(timeEntries2.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Delete time entry error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/reports/time-breakdown", authMiddleware, reportsScopeMiddleware, async (req, res) => {
    try {
      const { technicianId, month, year, userId, startDate: startDateStr, endDate: endDateStr } = req.query;
      let startDate;
      let endDate;
      let monthNum;
      let yearNum;
      if (startDateStr && endDateStr) {
        startDate = new Date(startDateStr);
        endDate = new Date(endDateStr);
        startDate.setUTCHours(0, 0, 0, 0);
        endDate.setUTCHours(23, 59, 59, 999);
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
          return res.status(400).json({ error: "Invalid date format" });
        }
        if (startDate > endDate) {
          return res.status(400).json({ error: "Start date must be before end date" });
        }
        monthNum = startDate.getMonth() + 1;
        yearNum = startDate.getFullYear();
      } else if (month && year) {
        monthNum = parseInt(month);
        yearNum = parseInt(year);
        if (monthNum < 1 || monthNum > 12) {
          return res.status(400).json({ error: "Invalid month (1-12)" });
        }
        startDate = new Date(yearNum, monthNum - 1, 1);
        endDate = new Date(yearNum, monthNum, 0, 23, 59, 59, 999);
      } else {
        return res.status(400).json({
          error: "Either startDate/endDate or month/year are required"
        });
      }
      const conditions = [
        gte3(timeEntries2.workDate, startDate),
        lte3(timeEntries2.workDate, endDate)
      ];
      if (userId) {
        const [technician] = await db.select().from(technicians).where(eq5(technicians.userId, userId)).limit(1);
        if (technician) {
          conditions.push(eq5(timeEntries2.technicianId, technician.id));
        } else {
          return res.json({
            period: {
              month: monthNum,
              year: yearNum,
              startDate,
              endDate
            },
            totals: { efetivo: 0, adicional: 0, perda: 0 },
            percentages: { efetivo: 0, adicional: 0, perda: 0 },
            totalMinutes: 0,
            breakdown: [],
            entries: []
          });
        }
      } else if (technicianId && technicianId !== "all") {
        conditions.push(eq5(timeEntries2.technicianId, technicianId));
      }
      const entries = await db.select({
        id: timeEntries2.id,
        technicianId: timeEntries2.technicianId,
        technicianName: technicians.name,
        activityTypeId: timeEntries2.activityTypeId,
        activityName: activityTypes.name,
        category: timeEntries2.category,
        color: activityTypes.color,
        icon: activityTypes.icon,
        isAutomatic: activityTypes.isAutomatic,
        workDate: timeEntries2.workDate,
        minutes: timeEntries2.minutes,
        source: timeEntries2.source,
        notes: timeEntries2.notes
      }).from(timeEntries2).innerJoin(activityTypes, eq5(timeEntries2.activityTypeId, activityTypes.id)).innerJoin(technicians, eq5(timeEntries2.technicianId, technicians.id)).where(and3(...conditions));
      const totals = {
        efetivo: 0,
        adicional: 0,
        perda: 0
      };
      const breakdown = {};
      for (const entry of entries) {
        totals[entry.category] += entry.minutes;
        const breakdownKey = `${entry.activityTypeId}_${entry.category}`;
        if (!breakdown[breakdownKey]) {
          breakdown[breakdownKey] = {
            name: entry.activityName,
            category: entry.category,
            color: entry.color,
            icon: entry.icon ?? null,
            minutes: 0,
            entries: 0,
            isAutomatic: entry.isAutomatic,
            justifications: []
          };
        }
        breakdown[breakdownKey].minutes += entry.minutes;
        breakdown[breakdownKey].entries += 1;
        if (entry.notes && entry.notes.includes("Justificativa:")) {
          const justificationMatch = entry.notes.match(/Justificativa:\s*(.+?)$/);
          if (justificationMatch) {
            breakdown[breakdownKey].justifications.push({
              date: entry.workDate.toISOString().split("T")[0],
              minutes: entry.minutes,
              text: justificationMatch[1].trim()
            });
          }
        }
      }
      const totalMinutes = totals.efetivo + totals.adicional + totals.perda;
      const percentages = {
        efetivo: totalMinutes > 0 ? totals.efetivo / totalMinutes * 100 : 0,
        adicional: totalMinutes > 0 ? totals.adicional / totalMinutes * 100 : 0,
        perda: totalMinutes > 0 ? totals.perda / totalMinutes * 100 : 0
      };
      const breakdownByTechnician = {};
      const technicianSummaryMap = {};
      for (const entry of entries) {
        const techBreakdownKey = `${entry.technicianId}_${entry.activityTypeId}_${entry.category}`;
        if (!breakdownByTechnician[techBreakdownKey]) {
          breakdownByTechnician[techBreakdownKey] = {
            technicianId: entry.technicianId,
            technicianName: entry.technicianName,
            activityName: entry.activityName,
            category: entry.category,
            color: entry.color,
            icon: entry.icon ?? null,
            minutes: 0,
            entries: 0,
            isAutomatic: entry.isAutomatic
          };
        }
        breakdownByTechnician[techBreakdownKey].minutes += entry.minutes;
        breakdownByTechnician[techBreakdownKey].entries += 1;
        if (!technicianSummaryMap[entry.technicianId]) {
          technicianSummaryMap[entry.technicianId] = {
            technicianId: entry.technicianId,
            technicianName: entry.technicianName,
            efetivo: 0,
            adicional: 0,
            perda: 0,
            total: 0
          };
        }
        technicianSummaryMap[entry.technicianId][entry.category] += entry.minutes;
        technicianSummaryMap[entry.technicianId].total += entry.minutes;
      }
      const technicianSummary = Object.values(technicianSummaryMap).sort(
        (a, b) => a.technicianName.localeCompare(b.technicianName)
      );
      const sortedBreakdownByTechnician = Object.values(breakdownByTechnician).sort((a, b) => {
        const nameCompare = a.technicianName.localeCompare(b.technicianName);
        if (nameCompare !== 0) return nameCompare;
        const categoryOrder = { efetivo: 0, adicional: 1, perda: 2 };
        const catCompare = (categoryOrder[a.category] || 0) - (categoryOrder[b.category] || 0);
        if (catCompare !== 0) return catCompare;
        return a.activityName.localeCompare(b.activityName);
      });
      res.json({
        period: {
          month: monthNum,
          year: yearNum,
          startDate,
          endDate
        },
        totals,
        percentages,
        totalMinutes,
        breakdown: Object.values(breakdown),
        breakdownByTechnician: sortedBreakdownByTechnician,
        technicianSummary,
        entries
      });
    } catch (error) {
      console.error("Time breakdown report error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/reports/location-breakdown", authMiddleware, reportsScopeMiddleware, async (req, res) => {
    try {
      const { technicianId, userId, startDate: startDateStr, endDate: endDateStr } = req.query;
      if (!startDateStr || !endDateStr) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      const startDate = new Date(startDateStr);
      const endDate = new Date(endDateStr);
      startDate.setUTCHours(0, 0, 0, 0);
      endDate.setUTCHours(23, 59, 59, 999);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ error: "Invalid date format" });
      }
      const conditions = [
        gte3(timeEntries2.workDate, startDate),
        lte3(timeEntries2.workDate, endDate)
      ];
      if (userId) {
        const [technician] = await db.select().from(technicians).where(eq5(technicians.userId, userId)).limit(1);
        if (technician) {
          conditions.push(eq5(timeEntries2.technicianId, technician.id));
        } else {
          return res.json({
            period: { startDate, endDate },
            categories: [],
            byLocation: [],
            byCategorization: [],
            grandTotalMinutes: 0,
            technicianSummary: []
          });
        }
      } else if (technicianId && technicianId !== "all") {
        conditions.push(eq5(timeEntries2.technicianId, technicianId));
      }
      const entries = await db.select({
        technicianId: timeEntries2.technicianId,
        technicianName: technicians.name,
        category: timeEntries2.category,
        location: timeEntries2.location,
        activityTypeId: timeEntries2.activityTypeId,
        minutes: timeEntries2.minutes
      }).from(timeEntries2).innerJoin(technicians, eq5(timeEntries2.technicianId, technicians.id)).where(and3(...conditions));
      const allTypes = await db.select().from(activityTypes);
      const typeMap = new Map(allTypes.map((t) => [t.id, t]));
      const categorizationLabels = {
        administrativo: "Administrativo",
        visita_tecnica: "Visita T\xE9cnica",
        deslocamento: "Deslocamento",
        qualificacao: "Qualifica\xE7\xE3o",
        ociosidade: "Ociosidade"
      };
      const NO_CATEGORIZATION = "N\xE3o informado";
      const resolveCategorization = (activityTypeId) => {
        const t = typeMap.get(activityTypeId);
        if (!t) return NO_CATEGORIZATION;
        const parent = t.parentId ? typeMap.get(t.parentId) : null;
        const value = parent ? parent.categorization : t.categorization;
        if (!value) return NO_CATEGORIZATION;
        return categorizationLabels[value] || value;
      };
      const NO_LOCATION = "N\xE3o informado";
      const categoryOrder = ["efetivo", "adicional", "perda"];
      const resolveLocation = (activityTypeId, recordedLocation) => {
        const t = typeMap.get(activityTypeId);
        if (t) {
          const source = t.parentId ? typeMap.get(t.parentId) ?? t : t;
          const locs = Array.isArray(source.locations) ? source.locations.filter((l) => l && l.trim()) : [];
          if (locs.length === 1) return locs[0].trim();
        }
        if (recordedLocation && recordedLocation.trim()) return recordedLocation.trim();
        return NO_LOCATION;
      };
      const catMap = {};
      const byLocationMap = {};
      const byCategorizationMap = {};
      const techMap = {};
      let grandTotalMinutes = 0;
      for (const e of entries) {
        const cat = e.category;
        const loc = resolveLocation(e.activityTypeId, e.location);
        if (!catMap[cat]) catMap[cat] = { total: 0, locations: {} };
        catMap[cat].total += e.minutes;
        catMap[cat].locations[loc] = (catMap[cat].locations[loc] || 0) + e.minutes;
        byLocationMap[loc] = (byLocationMap[loc] || 0) + e.minutes;
        const categ = resolveCategorization(e.activityTypeId);
        byCategorizationMap[categ] = (byCategorizationMap[categ] || 0) + e.minutes;
        grandTotalMinutes += e.minutes;
        if (!techMap[e.technicianId]) {
          techMap[e.technicianId] = { technicianId: e.technicianId, technicianName: e.technicianName, total: 0 };
        }
        techMap[e.technicianId].total += e.minutes;
      }
      const categories = categoryOrder.filter((cat) => catMap[cat]).map((cat) => ({
        category: cat,
        totalMinutes: catMap[cat].total,
        locations: Object.entries(catMap[cat].locations).map(([location, minutes]) => ({ location, minutes })).sort((a, b) => b.minutes - a.minutes)
      }));
      const byLocation = Object.entries(byLocationMap).map(([location, minutes]) => ({
        location,
        minutes,
        percentage: grandTotalMinutes > 0 ? minutes / grandTotalMinutes * 100 : 0
      })).sort((a, b) => b.minutes - a.minutes);
      const byCategorization = Object.entries(byCategorizationMap).map(([categorization, minutes]) => ({
        categorization,
        minutes,
        percentage: grandTotalMinutes > 0 ? minutes / grandTotalMinutes * 100 : 0
      })).sort((a, b) => b.minutes - a.minutes);
      const technicianSummary = Object.values(techMap).sort(
        (a, b) => a.technicianName.localeCompare(b.technicianName)
      );
      res.json({
        period: { startDate, endDate },
        categories,
        byLocation,
        byCategorization,
        grandTotalMinutes,
        technicianSummary
      });
    } catch (error) {
      console.error("Location breakdown report error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.get("/api/reports/reschedule-stats", authMiddleware, reportsScopeMiddleware, async (req, res) => {
    try {
      const { startDate: startDateStr, endDate: endDateStr, technicianId, userId } = req.query;
      if (!startDateStr || !endDateStr) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      const startDate = new Date(startDateStr);
      const endDate = new Date(endDateStr);
      startDate.setUTCHours(0, 0, 0, 0);
      endDate.setUTCHours(23, 59, 59, 999);
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ error: "Invalid date format" });
      }
      let technicianFilter = void 0;
      if (userId) {
        const [technician] = await db.select().from(technicians).where(eq5(technicians.userId, userId)).limit(1);
        if (technician) {
          technicianFilter = eq5(activities.technicianId, technician.id);
        } else {
          return res.json({
            totalReschedules: 0,
            activitiesRescheduled: 0,
            activitiesWithMultipleReschedules: 0,
            reasonBreakdown: [],
            reschedules: []
          });
        }
      } else if (technicianId && technicianId !== "all") {
        technicianFilter = eq5(activities.technicianId, technicianId);
      }
      const reschedules = await db.select({
        id: activityReschedules2.id,
        activityId: activityReschedules2.activityId,
        previousDate: activityReschedules2.previousDate,
        newDate: activityReschedules2.newDate,
        reason: activityReschedules2.reason,
        rescheduledAt: activityReschedules2.createdAt,
        rescheduleNumber: activityReschedules2.rescheduleNumber,
        rescheduledBy: activityReschedules2.rescheduledBy,
        rescheduledByName: users.name,
        activityTitle: activities.title,
        clientName: activities.clientName,
        technicianId: activities.technicianId,
        technicianName: technicians.name
      }).from(activityReschedules2).leftJoin(activities, eq5(activityReschedules2.activityId, activities.id)).leftJoin(users, eq5(activityReschedules2.rescheduledBy, users.id)).leftJoin(technicians, eq5(activities.technicianId, technicians.id)).where(
        and3(
          // A reschedule belongs to the period if the activity's previous OR new
          // scheduled date falls within it (NOT the moment the action was logged).
          // This way a reschedule moving 19→20 won't show up in a 01–18 report.
          or2(
            and3(
              gte3(activityReschedules2.previousDate, startDate),
              lte3(activityReschedules2.previousDate, endDate)
            ),
            and3(
              gte3(activityReschedules2.newDate, startDate),
              lte3(activityReschedules2.newDate, endDate)
            )
          ),
          technicianFilter
        )
      ).orderBy(desc2(activityReschedules2.createdAt));
      const uniqueActivityIds = Array.from(new Set(reschedules.map((r) => r.activityId)));
      const totalReschedules = reschedules.length;
      const activitiesRescheduled = uniqueActivityIds.length;
      const reasonStats = {};
      for (const r of reschedules) {
        const reason = r.reason?.trim() || "Sem motivo informado";
        reasonStats[reason] = (reasonStats[reason] || 0) + 1;
      }
      const multipleRescheduleCounts = reschedules.reduce((acc, r) => {
        acc[r.activityId] = (acc[r.activityId] || 0) + 1;
        return acc;
      }, {});
      const activitiesWithMultipleReschedules = Object.values(multipleRescheduleCounts).filter((c) => c > 1).length;
      res.json({
        totalReschedules,
        activitiesRescheduled,
        activitiesWithMultipleReschedules,
        reasonBreakdown: Object.entries(reasonStats).map(([reason, count]) => ({ reason, count })),
        reschedules: reschedules.map((r) => ({
          id: r.id,
          activityId: r.activityId,
          activityTitle: r.activityTitle,
          clientName: r.clientName,
          technicianName: r.technicianName,
          previousDate: r.previousDate,
          newDate: r.newDate,
          reason: r.reason,
          rescheduledAt: r.rescheduledAt,
          rescheduleNumber: r.rescheduleNumber,
          rescheduledByName: r.rescheduledByName
        }))
      });
    } catch (error) {
      console.error("Reschedule stats report error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/notifications/subscribe", authMiddleware, async (req, res) => {
    try {
      const subscriptionData = insertUserPushSubscriptionSchema.extend({
        playerId: insertUserPushSubscriptionSchema.shape.playerId
      }).parse({
        ...req.body,
        userId: req.user.userId
      });
      await storage.upsertPushSubscription({
        userId: subscriptionData.userId,
        playerId: subscriptionData.playerId,
        deviceType: "web"
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Push subscription error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/notifications", authMiddleware, async (req, res) => {
    try {
      const notifications2 = await storage.getUserNotifications(req.user.userId);
      res.json(notifications2);
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.patch("/api/notifications/:id/read", authMiddleware, async (req, res) => {
    try {
      const notificationId = req.params.id;
      await storage.markNotificationAsRead(notificationId, req.user.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark notification read error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.patch("/api/notifications/read-all", authMiddleware, async (req, res) => {
    try {
      await storage.markAllNotificationsAsRead(req.user.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Mark all notifications read error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/notifications/send", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const notificationData = insertNotificationSchema.omit({ isRead: true, sentToPush: true }).parse(req.body);
      const { sendPushNotification: sendPushNotification2 } = await init_onesignal().then(() => onesignal_exports);
      let parsedData = void 0;
      if (notificationData.data) {
        try {
          parsedData = typeof notificationData.data === "string" ? JSON.parse(notificationData.data) : notificationData.data;
        } catch {
          parsedData = notificationData.data;
        }
      }
      await sendPushNotification2({
        userId: notificationData.userId,
        title: notificationData.title,
        message: notificationData.message,
        type: notificationData.type,
        data: parsedData,
        url: req.body.url
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Send notification error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/checkin", authMiddleware, async (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      const now = /* @__PURE__ */ new Date();
      console.log(`\u{1F535} CHECK-IN - Activity ID: ${req.params.id}, Time: ${now.toISOString()}`);
      const activity = await storage.updateActivity(req.params.id, {
        status: "emExecucao",
        checkInTime: now,
        checkInLatitude: latitude?.toString(),
        checkInLongitude: longitude?.toString()
      });
      console.log(`\u2705 CHECK-IN atualizado:`, {
        id: activity.id,
        status: activity.status,
        checkInTime: activity.checkInTime
      });
      res.json(activity);
    } catch (error) {
      console.error(`\u274C Erro no CHECK-IN:`, error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/checkout", authMiddleware, async (req, res) => {
    try {
      const {
        latitude,
        longitude,
        workCompleted,
        travelJustification,
        actualTravelMinutes,
        adjustedCheckInTime,
        adjustedCheckOutTime,
        travelTimes,
        // Array of { transportType: string, minutes: number }
        executionMinutes,
        // User-confirmed execution time in minutes
        lostMinutes
        // User-confirmed lost time in minutes (when workCompleted=false)
      } = req.body;
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const validTransportTypes = ["carro", "moto", "a_pe", "transporte_publico", "aviao"];
      if (travelTimes && Array.isArray(travelTimes)) {
        for (const tt of travelTimes) {
          if (!tt.transportType || !validTransportTypes.includes(tt.transportType)) {
            return res.status(400).json({
              error: `Tipo de transporte inv\xE1lido: ${tt.transportType}. Valores permitidos: ${validTransportTypes.join(", ")}`
            });
          }
          if (typeof tt.minutes !== "number" || tt.minutes < 0) {
            return res.status(400).json({
              error: "Minutos de deslocamento deve ser um n\xFAmero n\xE3o-negativo"
            });
          }
        }
      }
      let finalWorkCompleted = null;
      let finalTravelClassification = null;
      let finalTravelJustification = null;
      if (workCompleted !== void 0 && workCompleted !== null) {
        if (typeof workCompleted !== "boolean") {
          return res.status(400).json({
            error: "workCompleted deve ser um valor booleano (true ou false)"
          });
        }
        finalWorkCompleted = workCompleted;
        if (workCompleted === true) {
          finalTravelClassification = "adicional";
          if (travelJustification) {
            return res.status(400).json({
              error: "Justificativa n\xE3o deve ser fornecida quando o trabalho foi realizado"
            });
          }
        } else {
          finalTravelClassification = "perda";
          if (!travelJustification || travelJustification.trim().length === 0) {
            return res.status(400).json({
              error: "Justificativa \xE9 obrigat\xF3ria quando o trabalho n\xE3o foi realizado"
            });
          }
          finalTravelJustification = travelJustification.trim();
        }
      }
      let finalCheckInTime;
      let finalCheckOutTime;
      let timeWasAdjusted = false;
      const originalCheckInTime = activity.checkInTime;
      const originalCheckOutTime = /* @__PURE__ */ new Date();
      if (adjustedCheckInTime && adjustedCheckOutTime) {
        const adjustedIn = new Date(adjustedCheckInTime);
        const adjustedOut = new Date(adjustedCheckOutTime);
        if (isNaN(adjustedIn.getTime()) || isNaN(adjustedOut.getTime())) {
          return res.status(400).json({
            error: "Hor\xE1rios ajustados s\xE3o inv\xE1lidos"
          });
        }
        if (adjustedOut < adjustedIn) {
          return res.status(400).json({
            error: "Hor\xE1rio de t\xE9rmino n\xE3o pode ser anterior ao hor\xE1rio de in\xEDcio"
          });
        }
        if (adjustedOut > /* @__PURE__ */ new Date()) {
          return res.status(400).json({
            error: "Hor\xE1rio de t\xE9rmino n\xE3o pode ser no futuro"
          });
        }
        finalCheckInTime = adjustedIn;
        finalCheckOutTime = adjustedOut;
        timeWasAdjusted = true;
        console.log(`\u{1F4DD} CHECKOUT - Hor\xE1rios AJUSTADOS pelo t\xE9cnico:`, {
          originalCheckIn: originalCheckInTime,
          adjustedCheckIn: finalCheckInTime.toISOString(),
          originalCheckOut: originalCheckOutTime.toISOString(),
          adjustedCheckOut: finalCheckOutTime.toISOString()
        });
      } else {
        finalCheckInTime = activity.checkInTime ? new Date(activity.checkInTime) : /* @__PURE__ */ new Date();
        finalCheckOutTime = /* @__PURE__ */ new Date();
      }
      console.log(`\u{1F7E1} CHECKOUT - Activity antes do checkout:`, {
        id: activity.id,
        status: activity.status,
        checkInTime: activity.checkInTime,
        checkOutTime: activity.checkOutTime,
        workCompleted: finalWorkCompleted,
        travelClassification: finalTravelClassification,
        timeWasAdjusted
      });
      let durationMinutes = null;
      if (finalWorkCompleted === true) {
        const parsedExecution = typeof executionMinutes === "number" ? executionMinutes : typeof executionMinutes === "string" ? parseInt(executionMinutes, 10) : NaN;
        if (!isNaN(parsedExecution) && parsedExecution >= 0) {
          durationMinutes = parsedExecution;
          console.log(`\u{1F7E1} CHECKOUT - Usando tempo de execu\xE7\xE3o fornecido pelo usu\xE1rio: ${durationMinutes}min`);
        } else {
          durationMinutes = Math.round((finalCheckOutTime.getTime() - finalCheckInTime.getTime()) / 6e4);
          console.log(`\u{1F7E1} CHECKOUT - Tempo de execu\xE7\xE3o calculado: ${durationMinutes}min`);
        }
        if (durationMinutes < 0) {
          durationMinutes = 0;
          console.warn(`\u26A0\uFE0F CHECKOUT - Dura\xE7\xE3o negativa calculada! Usando 0.`);
        }
      } else {
        const parsedLost = typeof lostMinutes === "number" ? lostMinutes : typeof lostMinutes === "string" ? parseInt(lostMinutes, 10) : NaN;
        if (!isNaN(parsedLost) && parsedLost >= 0) {
          durationMinutes = parsedLost;
          console.log(`\u{1F7E1} CHECKOUT - Trabalho n\xE3o realizado, usando lostMinutes como dura\xE7\xE3o: ${parsedLost}min`);
        } else {
          durationMinutes = Math.round((finalCheckOutTime.getTime() - finalCheckInTime.getTime()) / 6e4);
          console.log(`\u{1F7E1} CHECKOUT - Trabalho n\xE3o realizado, usando tempo calculado: ${durationMinutes}min`);
        }
      }
      console.log(`\u{1F7E1} CHECKOUT - Updating with checkOutTime: ${finalCheckOutTime.toISOString()}, Duration: ${durationMinutes}min`);
      const updateData = {
        status: "concluido",
        checkInTime: finalCheckInTime,
        checkOutTime: finalCheckOutTime,
        checkOutLatitude: latitude?.toString(),
        checkOutLongitude: longitude?.toString(),
        actualDurationMinutes: durationMinutes,
        workCompleted: finalWorkCompleted,
        travelClassification: finalTravelClassification,
        travelJustification: finalTravelJustification
      };
      if (actualTravelMinutes !== void 0 && actualTravelMinutes !== null) {
        updateData.actualTravelMinutes = actualTravelMinutes;
      }
      const updatedActivity = await storage.updateActivity(req.params.id, updateData);
      if (travelTimes && Array.isArray(travelTimes) && travelTimes.length > 0) {
        try {
          await db.delete(activityTravelTimes).where(eq5(activityTravelTimes.activityId, req.params.id));
          for (const tt of travelTimes) {
            if (tt.transportType && tt.minutes > 0) {
              await db.insert(activityTravelTimes).values({
                activityId: req.params.id,
                transportType: tt.transportType,
                minutes: tt.minutes
              });
            }
          }
          const totalManualTravelMinutes = travelTimes.reduce((sum, tt) => sum + (tt.minutes || 0), 0);
          if (totalManualTravelMinutes > 0) {
            await storage.updateActivity(req.params.id, {
              actualTravelMinutes: totalManualTravelMinutes
            });
          }
          console.log(`\u2705 Saved ${travelTimes.length} travel time entries for activity ${req.params.id}`);
        } catch (travelError) {
          console.error("\u26A0\uFE0F Error saving travel times:", travelError);
        }
      }
      if (timeWasAdjusted && req.user) {
        try {
          const auditChanges = JSON.stringify({
            action: "time_adjustment",
            original: {
              checkInTime: originalCheckInTime,
              checkOutTime: originalCheckOutTime.toISOString()
            },
            adjusted: {
              checkInTime: finalCheckInTime.toISOString(),
              checkOutTime: finalCheckOutTime.toISOString()
            },
            adjustedBy: req.user.userId,
            adjustedAt: (/* @__PURE__ */ new Date()).toISOString()
          });
          await db.insert(auditLogs).values({
            userId: req.user.userId,
            action: "activity_time_adjusted",
            entityType: "activity",
            entityId: activity.id,
            changes: auditChanges
          });
          console.log(`\u{1F4DD} Audit log criado para ajuste de hor\xE1rio da atividade ${activity.id}`);
        } catch (auditError) {
          console.error("\u26A0\uFE0F Erro ao criar audit log:", auditError);
        }
      }
      console.log(`\u2705 CHECKOUT atualizado:`, {
        id: updatedActivity.id,
        status: updatedActivity.status,
        checkInTime: updatedActivity.checkInTime,
        checkOutTime: updatedActivity.checkOutTime,
        actualDurationMinutes: updatedActivity.actualDurationMinutes,
        workCompleted: finalWorkCompleted,
        travelClassification: finalTravelClassification
      });
      const activityType = await storage.getActivityType(activity.activityTypeId);
      const typesRequiringRat = [
        "Visita t\xE9cnica (corretiva ou RCs)",
        "Visitas t\xE9cnicas (Preventiva ou teste)",
        "Preventivas",
        "Teste",
        "Reclama\xE7\xE3o",
        "Visitas t\xE9cnicas"
      ];
      let parentRequiresRat = false;
      if (activityType?.parentId) {
        const parentType = await storage.getActivityType(activityType.parentId);
        if (parentType?.requiresRat) {
          parentRequiresRat = true;
        }
      }
      const shouldCreateRat = finalWorkCompleted === true && activityType && (activityType.requiresRat === true || parentRequiresRat || typesRequiringRat.some((t) => t.trim() === activityType.name.trim()));
      if (shouldCreateRat) {
        try {
          const existingRats = await db.select().from(rats).where(eq5(rats.activityId, activity.id));
          if (existingRats.length === 0 && activity.technicianId) {
            const reportNumber = await storage.getNextRatNumber();
            await storage.createRat({
              activityId: activity.id,
              technicianId: activity.technicianId,
              formData: JSON.stringify({}),
              reportNumber,
              status: "pendente",
              clientName: activity.clientName || "",
              openDate: /* @__PURE__ */ new Date()
            });
            console.log(`\u{1F4CB} RAT pendente criada automaticamente para atividade ${activity.id}`);
          }
        } catch (ratError) {
          console.error("\u26A0\uFE0F Error auto-creating RAT:", ratError);
        }
      }
      const idaTravelMinutes = activity.actualTravelMinutes || activity.estimatedTravelMinutes || 0;
      if (idaTravelMinutes > 0) {
        try {
          let travelCategory;
          if (activityType?.category === "efetivo" && finalWorkCompleted !== false) {
            travelCategory = "adicional";
          } else if (finalWorkCompleted === false) {
            travelCategory = "perda";
          } else if (finalTravelClassification) {
            travelCategory = finalTravelClassification;
          } else {
            travelCategory = activityType?.category === "adicional" ? "adicional" : activityType?.category === "perda" ? "perda" : "adicional";
          }
          let travelNotes = `Tempo de IDA at\xE9 ${activity.clientName || "cliente"}: ${idaTravelMinutes}min`;
          if (activity.actualTravelMinutes) {
            travelNotes += ` (informado pelo t\xE9cnico)`;
          } else {
            travelNotes += ` (estimativa GPS)`;
          }
          if (finalWorkCompleted === false && finalTravelJustification) {
            travelNotes += ` | Trabalho N\xC3O realizado - Justificativa: ${finalTravelJustification}`;
          } else if (finalWorkCompleted === true || finalWorkCompleted === void 0) {
            travelNotes += ` | Deslocamento`;
          }
          const idaWorkDateStr = new Date(activity.scheduledDate).toISOString().split("T")[0];
          await db.insert(timeEntries2).values({
            technicianId: activity.technicianId,
            activityTypeId: activity.activityTypeId,
            workDate: /* @__PURE__ */ new Date(idaWorkDateStr + "T12:00:00Z"),
            minutes: idaTravelMinutes,
            category: travelCategory,
            source: "ida_travel",
            location: "Trajeto",
            notes: travelNotes,
            createdBy: req.user.userId
          });
          console.log(`\u2705 Time entry IDA criado: ${idaTravelMinutes}min de ${travelCategory} (tipo atividade: ${activityType?.category})`);
        } catch (travelError) {
          console.error("\u26A0\uFE0F Erro ao criar time entry de IDA:", travelError);
        }
      }
      if (durationMinutes !== null && durationMinutes > 0 && activityType) {
        if (activityType.category === "efetivo" || activityType.category === "adicional" || activityType.category === "perda") {
          try {
            const execWorkDateStr = new Date(activity.scheduledDate).toISOString().split("T")[0];
            const workDate = /* @__PURE__ */ new Date(execWorkDateStr + "T12:00:00Z");
            let timeEntryCategory;
            if (finalWorkCompleted === false) {
              timeEntryCategory = "perda";
            } else if (activityType.category === "efetivo") {
              timeEntryCategory = "efetivo";
            } else if (activityType.category === "adicional") {
              timeEntryCategory = "adicional";
            } else {
              timeEntryCategory = "perda";
            }
            const notes = finalWorkCompleted === false ? `Tempo n\xE3o produtivo - ${activity.clientName || "sem nome"}${finalTravelJustification ? ` | Motivo: ${finalTravelJustification}` : ""}` : `Tempo de execu\xE7\xE3o da atividade ${activity.clientName || "sem nome"}`;
            await db.insert(timeEntries2).values({
              technicianId: activity.technicianId,
              activityTypeId: activity.activityTypeId,
              workDate,
              minutes: durationMinutes,
              category: timeEntryCategory,
              source: "timer",
              location: activity.location ?? null,
              notes,
              createdBy: req.user.userId,
              agendaActivityId: activity.id
            }).onConflictDoNothing({ target: timeEntries2.agendaActivityId });
            console.log(`\u2705 Time entry EXECU\xC7\xC3O criado: ${durationMinutes}min de ${timeEntryCategory} (workCompleted=${finalWorkCompleted})`);
          } catch (timeEntryError) {
            console.error("\u26A0\uFE0F Erro ao criar time entry de execu\xE7\xE3o:", timeEntryError);
          }
        }
      }
      if (finalWorkCompleted === false && activityType) {
        const parsedLostMinutes = typeof lostMinutes === "number" ? lostMinutes : typeof lostMinutes === "string" ? parseInt(lostMinutes, 10) : NaN;
        if (!isNaN(parsedLostMinutes) && parsedLostMinutes > 0) {
          try {
            const lostWorkDateStr = new Date(activity.scheduledDate).toISOString().split("T")[0];
            const workDate = /* @__PURE__ */ new Date(lostWorkDateStr + "T12:00:00Z");
            const notes = `Tempo n\xE3o produtivo - ${activity.clientName || "sem nome"}${finalTravelJustification ? ` | Motivo: ${finalTravelJustification}` : ""}`;
            await db.insert(timeEntries2).values({
              technicianId: activity.technicianId,
              activityTypeId: activity.activityTypeId,
              workDate,
              minutes: parsedLostMinutes,
              category: "perda",
              source: "timer",
              location: activity.location ?? null,
              notes,
              createdBy: req.user.userId,
              agendaActivityId: activity.id
            }).onConflictDoNothing({ target: timeEntries2.agendaActivityId });
            console.log(`\u2705 Time entry PERDA criado: ${parsedLostMinutes}min (trabalho n\xE3o realizado)`);
          } catch (lostTimeError) {
            console.error("\u26A0\uFE0F Erro ao criar time entry de perda:", lostTimeError);
          }
        }
      }
      if (finalWorkCompleted !== false) {
        try {
          const activityDate = new Date(activity.scheduledDate);
          const startOfDay = new Date(activityDate);
          startOfDay.setHours(0, 0, 0, 0);
          const endOfDay = new Date(activityDate);
          endOfDay.setHours(23, 59, 59, 999);
          const sameDayActivities = await db.select().from(activities).where(
            and3(
              eq5(activities.technicianId, activity.technicianId),
              gte3(activities.scheduledDate, startOfDay),
              lte3(activities.scheduledDate, endOfDay),
              eq5(activities.status, "concluido"),
              ne(activities.id, activity.id)
              // Exclude current activity
            )
          ).orderBy(activities.scheduledDate);
          const previousNotCompleted = sameDayActivities.filter(
            (a) => a.workCompleted === false && new Date(a.scheduledDate) < new Date(activity.scheduledDate)
          );
          if (previousNotCompleted.length > 0) {
            const prevActivity = previousNotCompleted[previousNotCompleted.length - 1];
            const reclassifyResult = await db.update(timeEntries2).set({
              category: "adicional",
              notes: sql4`${timeEntries2.notes} || ' | Reclassificado: deslocamento resultou em trabalho produtivo na próxima atividade'`
            }).where(
              and3(
                eq5(timeEntries2.technicianId, prevActivity.technicianId),
                eq5(timeEntries2.activityTypeId, prevActivity.activityTypeId),
                eq5(timeEntries2.source, "volta_travel"),
                eq5(timeEntries2.category, "perda"),
                gte3(timeEntries2.workDate, startOfDay),
                lte3(timeEntries2.workDate, endOfDay)
              )
            ).returning();
            if (reclassifyResult.length > 0) {
              console.log(`\u{1F504} Reclassificado ${reclassifyResult.length} time entry(ies) de VOLTA de perda \u2192 adicional (atividade anterior: ${prevActivity.clientName})`);
            }
          }
        } catch (reclassifyError) {
          console.error("\u26A0\uFE0F Erro ao reclassificar time entries:", reclassifyError);
        }
      }
      res.json(updatedActivity);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/navigation/start", authMiddleware, async (req, res) => {
    try {
      const { originLatLng, destLatLng, gpsEtaMinutes, date } = req.body;
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const isMultiDay = !!activity.endDate;
      const technician = await storage.getTechnicianByUserId(req.user.userId);
      if (!technician || req.user.role !== "admin" && activity.technicianId !== technician.id) {
        return res.status(403).json({ error: "N\xE3o autorizado a iniciar navega\xE7\xE3o desta atividade" });
      }
      const now = /* @__PURE__ */ new Date();
      if (isMultiDay) {
        const targetDate = date ? /* @__PURE__ */ new Date(date + "T00:00:00.000Z") : /* @__PURE__ */ new Date();
        targetDate.setUTCHours(0, 0, 0, 0);
        const nextDay = new Date(targetDate);
        nextDay.setDate(nextDay.getDate() + 1);
        const [existingDayStatus] = await db.select().from(activityDayStatus).where(
          and3(
            eq5(activityDayStatus.activityId, req.params.id),
            gte3(activityDayStatus.date, targetDate),
            lt(activityDayStatus.date, nextDay)
          )
        ).limit(1);
        if (existingDayStatus && (existingDayStatus.status === "concluido" || existingDayStatus.status === "emExecucao")) {
          return res.status(400).json({
            error: `N\xE3o \xE9 poss\xEDvel iniciar navega\xE7\xE3o. Status do dia: ${existingDayStatus.status}`
          });
        }
        if (existingDayStatus) {
          await db.update(activityDayStatus).set({ status: "aCaminho", updatedAt: now }).where(eq5(activityDayStatus.id, existingDayStatus.id));
        } else {
          await db.insert(activityDayStatus).values({
            activityId: req.params.id,
            date: targetDate,
            status: "aCaminho"
          });
        }
        await storage.updateActivity(req.params.id, {
          navigationStartTime: now,
          navigationEtaMinutes: gpsEtaMinutes || null
        });
      } else {
        if (activity.status !== "planejado") {
          return res.status(400).json({
            error: `N\xE3o \xE9 poss\xEDvel iniciar navega\xE7\xE3o. Status atual: ${activity.status}. Esperado: planejado`
          });
        }
        const existingNavigating = await db.select().from(activities).where(
          and3(
            eq5(activities.technicianId, activity.technicianId),
            eq5(activities.status, "aCaminho"),
            ne(activities.id, activity.id)
          )
        ).limit(1);
        if (existingNavigating.length > 0) {
          return res.status(400).json({
            error: "J\xE1 existe outra atividade em navega\xE7\xE3o. Finalize-a antes de iniciar outra."
          });
        }
        await storage.updateActivity(req.params.id, {
          status: "aCaminho",
          navigationStartTime: now,
          navigationEtaMinutes: gpsEtaMinutes || null
        });
      }
      console.log(`\u2705 Navega\xE7\xE3o iniciada para atividade ${req.params.id}, ETA: ${gpsEtaMinutes || "n\xE3o dispon\xEDvel"}min`);
      const refreshedActivity = await storage.getActivity(req.params.id);
      res.json({
        ...refreshedActivity,
        message: "Navega\xE7\xE3o iniciada com sucesso"
      });
    } catch (error) {
      console.error(`\u274C Erro ao iniciar navega\xE7\xE3o:`, error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/travel/ida", authMiddleware, async (req, res) => {
    try {
      const { minutesReported, gpsEtaMinutes, transportType, date } = req.body;
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const isMultiDay = !!activity.endDate;
      if (!isMultiDay) {
        if (activity.status !== "aCaminho" && activity.status !== "planejado") {
          return res.status(400).json({
            error: `N\xE3o \xE9 poss\xEDvel registrar tempo de IDA. Status atual: ${activity.status}. Esperado: aCaminho ou planejado`
          });
        }
      }
      if (typeof minutesReported !== "number" || minutesReported < 0) {
        return res.status(400).json({ error: "minutesReported deve ser um n\xFAmero n\xE3o-negativo" });
      }
      const validTransportTypes = ["carro", "moto", "a_pe", "transporte_publico", "aviao"];
      if (transportType && !validTransportTypes.includes(transportType)) {
        return res.status(400).json({
          error: `Tipo de transporte inv\xE1lido. Valores permitidos: ${validTransportTypes.join(", ")}`
        });
      }
      if (isMultiDay) {
        const targetDate = date ? /* @__PURE__ */ new Date(date + "T00:00:00.000Z") : /* @__PURE__ */ new Date();
        targetDate.setUTCHours(0, 0, 0, 0);
        const nextDay = new Date(targetDate);
        nextDay.setDate(nextDay.getDate() + 1);
        const targetDateStr = targetDate.toISOString().split("T")[0];
        const existingRecord = await db.select().from(activityTimeRecords).where(
          and3(
            eq5(activityTimeRecords.activityId, activity.id),
            eq5(activityTimeRecords.recordType, "ida"),
            sql4`DATE(${activityTimeRecords.finishedAt}) = ${targetDateStr}`
          )
        ).limit(1);
        if (existingRecord.length > 0) {
          return res.status(409).json({
            error: "Tempo de IDA j\xE1 registrado para este dia",
            existingRecord: existingRecord[0]
          });
        }
        const [timeRecord] = await db.insert(activityTimeRecords).values({
          activityId: activity.id,
          recordType: "ida",
          minutesReported,
          gpsEtaMinutes: gpsEtaMinutes || null,
          transportType: transportType || null,
          startedAt: activity.navigationStartTime,
          finishedAt: /* @__PURE__ */ new Date()
        }).returning();
        const now = /* @__PURE__ */ new Date();
        console.log(`\u{1F504} [Multi-dia] Atualizando day status para emExecucao, data: ${targetDateStr}`);
        const [existingDayStatus] = await db.select().from(activityDayStatus).where(
          and3(
            eq5(activityDayStatus.activityId, req.params.id),
            gte3(activityDayStatus.date, targetDate),
            lt(activityDayStatus.date, nextDay)
          )
        ).limit(1);
        if (existingDayStatus) {
          await db.update(activityDayStatus).set({ status: "emExecucao", checkInTime: now, updatedAt: now }).where(eq5(activityDayStatus.id, existingDayStatus.id));
        } else {
          await db.insert(activityDayStatus).values({
            activityId: req.params.id,
            date: targetDate,
            status: "emExecucao",
            checkInTime: now
          });
        }
        await db.update(activities).set({
          checkInTime: now,
          idaRecordedAt: now,
          actualTravelMinutes: minutesReported,
          updatedAt: now
        }).where(eq5(activities.id, req.params.id));
      } else {
        const existingRecord = await db.select().from(activityTimeRecords).where(
          and3(
            eq5(activityTimeRecords.activityId, activity.id),
            eq5(activityTimeRecords.recordType, "ida")
          )
        ).limit(1);
        if (existingRecord.length > 0) {
          return res.status(409).json({
            error: "Tempo de IDA j\xE1 registrado para esta atividade",
            existingRecord: existingRecord[0]
          });
        }
        const [timeRecord] = await db.insert(activityTimeRecords).values({
          activityId: activity.id,
          recordType: "ida",
          minutesReported,
          gpsEtaMinutes: gpsEtaMinutes || null,
          transportType: transportType || null,
          startedAt: activity.navigationStartTime,
          finishedAt: /* @__PURE__ */ new Date()
        }).returning();
        const now = /* @__PURE__ */ new Date();
        const [updatedActivity] = await db.update(activities).set({
          status: "emExecucao",
          checkInTime: now,
          idaRecordedAt: now,
          actualTravelMinutes: minutesReported,
          updatedAt: now
        }).where(eq5(activities.id, req.params.id)).returning();
        console.log(`\u2705 actualTravelMinutes salvo: ${updatedActivity.actualTravelMinutes}`);
      }
      console.log(`\u2705 Tempo de IDA registrado: ${minutesReported}min (ETA GPS: ${gpsEtaMinutes || "N/A"}min)`);
      res.json({
        activityStatus: "emExecucao",
        message: "Tempo de IDA registrado e atividade iniciada"
      });
    } catch (error) {
      console.error(`\u274C Erro ao registrar tempo de IDA:`, error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/travel/return-base", authMiddleware, async (req, res) => {
    try {
      const { baseId, minutesReported, gpsEtaMinutes, transportType, date } = req.body;
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const isMultiDay = !!activity.endDate;
      if (!isMultiDay && activity.status !== "concluido") {
        return res.status(400).json({
          error: `N\xE3o \xE9 poss\xEDvel registrar retorno \xE0 base. Status atual: ${activity.status}. Esperado: concluido`
        });
      }
      if (typeof minutesReported !== "number" || minutesReported < 0) {
        return res.status(400).json({ error: "minutesReported deve ser um n\xFAmero n\xE3o-negativo" });
      }
      const validTransportTypes = ["carro", "moto", "a_pe", "transporte_publico", "aviao"];
      if (transportType && !validTransportTypes.includes(transportType)) {
        return res.status(400).json({
          error: `Tipo de transporte inv\xE1lido. Valores permitidos: ${validTransportTypes.join(", ")}`
        });
      }
      const recordDateStr = date || new Date(activity.scheduledDate).toISOString().split("T")[0];
      const recordDate = /* @__PURE__ */ new Date(recordDateStr + "T12:00:00Z");
      const recordDateStart = /* @__PURE__ */ new Date(recordDateStr + "T00:00:00Z");
      const recordDateEnd = new Date(recordDateStart);
      recordDateEnd.setDate(recordDateEnd.getDate() + 1);
      let existingRecordQuery;
      if (isMultiDay && date) {
        existingRecordQuery = await db.select().from(activityTimeRecords).where(
          and3(
            eq5(activityTimeRecords.activityId, activity.id),
            eq5(activityTimeRecords.recordType, "retorno_base"),
            or2(
              and3(
                gte3(activityTimeRecords.finishedAt, recordDateStart),
                lt(activityTimeRecords.finishedAt, recordDateEnd)
              ),
              sql4`DATE(${activityTimeRecords.createdAt}) = ${recordDateStr}`
            )
          )
        ).limit(1);
      } else {
        existingRecordQuery = await db.select().from(activityTimeRecords).where(
          and3(
            eq5(activityTimeRecords.activityId, activity.id),
            eq5(activityTimeRecords.recordType, "retorno_base")
          )
        ).limit(1);
      }
      if (existingRecordQuery.length > 0) {
        return res.status(409).json({
          error: "Retorno \xE0 base j\xE1 registrado para esta atividade" + (isMultiDay ? ` no dia ${recordDateStr}` : ""),
          existingRecord: existingRecordQuery[0]
        });
      }
      const now = /* @__PURE__ */ new Date();
      const finishedAtForRecord = isMultiDay && date ? new Date(recordDateStart.getTime() + (now.getHours() * 36e5 + now.getMinutes() * 6e4 + now.getSeconds() * 1e3)) : now;
      const [timeRecord] = await db.insert(activityTimeRecords).values({
        activityId: activity.id,
        recordType: "retorno_base",
        minutesReported,
        gpsEtaMinutes: gpsEtaMinutes || null,
        transportType: transportType || null,
        baseId: baseId || null,
        startedAt: activity.checkOutTime,
        finishedAt: finishedAtForRecord
      }).returning();
      await storage.updateActivity(req.params.id, {
        returnBaseRecordedAt: /* @__PURE__ */ new Date(),
        actualReturnMinutes: minutesReported
      });
      try {
        const activityType = await storage.getActivityType(activity.activityTypeId);
        let dayWorkCompleted = activity.workCompleted;
        if (isMultiDay && date) {
          const [dayStatus] = await db.select().from(activityDayStatus).where(
            and3(
              eq5(activityDayStatus.activityId, activity.id),
              gte3(activityDayStatus.date, recordDate),
              lt(activityDayStatus.date, recordDateEnd)
            )
          ).limit(1);
          if (dayStatus) {
            dayWorkCompleted = dayStatus.workCompleted;
          }
        }
        let voltaCategory;
        if (activityType?.category === "efetivo" && dayWorkCompleted !== false) {
          voltaCategory = "adicional";
        } else if (dayWorkCompleted === false) {
          voltaCategory = "perda";
        } else {
          voltaCategory = activityType?.category === "adicional" ? "adicional" : activityType?.category === "perda" ? "perda" : "adicional";
        }
        const voltaNotes = isMultiDay ? `Dia ${recordDateStr} - VOLTA de ${activity.clientName || "cliente"}: ${minutesReported}min (informado pelo t\xE9cnico)` : `Tempo de VOLTA de ${activity.clientName || "cliente"}: ${minutesReported}min (informado pelo t\xE9cnico)`;
        await db.insert(timeEntries2).values({
          technicianId: activity.technicianId,
          activityTypeId: activity.activityTypeId,
          workDate: recordDate,
          minutes: minutesReported,
          category: voltaCategory,
          source: "volta_travel",
          location: "Trajeto",
          notes: voltaNotes,
          createdBy: req.user.userId,
          agendaActivityId: isMultiDay ? activity.id : void 0
        });
        console.log(`\u2705 Time entry VOLTA criado: ${minutesReported}min de ${voltaCategory} (dia: ${recordDateStr})`);
      } catch (timeEntryError) {
        console.error("\u26A0\uFE0F Erro ao criar time entry de VOLTA:", timeEntryError);
      }
      console.log(`\u2705 Retorno \xE0 base registrado: ${minutesReported}min (ETA GPS: ${gpsEtaMinutes || "N/A"}min)`);
      res.json({
        timeRecordId: timeRecord.id,
        message: "Retorno \xE0 base registrado com sucesso"
      });
    } catch (error) {
      console.error(`\u274C Erro ao registrar retorno \xE0 base:`, error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/next-step", authMiddleware, async (req, res) => {
    try {
      const { action, nextActivityId } = req.body;
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const isMultiDay = !!activity.endDate;
      if (!isMultiDay && activity.status !== "concluido") {
        return res.status(400).json({
          error: `A\xE7\xE3o n\xE3o permitida. Status atual: ${activity.status}. Esperado: concluido`
        });
      }
      const validActions = ["next_activity", "end_journey", "return_base"];
      if (!action || !validActions.includes(action)) {
        return res.status(400).json({
          error: `A\xE7\xE3o inv\xE1lida. Valores permitidos: ${validActions.join(", ")}`
        });
      }
      if (action === "next_activity" && nextActivityId) {
        const nextActivity = await storage.getActivity(nextActivityId);
        if (!nextActivity) {
          return res.status(404).json({ error: "Pr\xF3xima atividade n\xE3o encontrada" });
        }
        if (nextActivity.technicianId !== activity.technicianId) {
          return res.status(400).json({ error: "Pr\xF3xima atividade pertence a outro t\xE9cnico" });
        }
      }
      console.log(`\u2705 Pr\xF3ximo passo selecionado: ${action}${nextActivityId ? ` \u2192 ${nextActivityId}` : ""}`);
      res.json({
        message: "OK",
        action,
        nextActivityId: nextActivityId || null
      });
    } catch (error) {
      console.error(`\u274C Erro ao selecionar pr\xF3ximo passo:`, error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activity-time-records/bulk", authMiddleware, async (req, res) => {
    try {
      const { activityIds } = req.query;
      if (!activityIds || typeof activityIds !== "string") {
        return res.json([]);
      }
      const ids = activityIds.split(",").filter(Boolean);
      if (ids.length === 0) return res.json([]);
      const records = await db.select().from(activityTimeRecords).where(inArray(activityTimeRecords.activityId, ids)).orderBy(activityTimeRecords.createdAt);
      res.json(records);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities/:id/time-records", authMiddleware, async (req, res) => {
    try {
      const activity = await storage.getActivity(req.params.id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const records = await db.select().from(activityTimeRecords).where(eq5(activityTimeRecords.activityId, activity.id)).orderBy(activityTimeRecords.createdAt);
      res.json(records);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/reschedule", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      const { newDate, newEndDate, newStartTime, newEndTime, reason } = req.body;
      if (!newDate || !newStartTime || !newEndTime || !reason) {
        return res.status(400).json({ error: "newDate, newStartTime, newEndTime and reason are required" });
      }
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (activity.status !== "planejado") {
        return res.status(400).json({ error: "Only activities with 'planejado' status can be rescheduled" });
      }
      let parsedNewDate;
      if (typeof newDate === "string") {
        const datePartMatch = newDate.match(/(\d{4})-(\d{2})-(\d{2})/);
        if (datePartMatch) {
          const [, year, month, day] = datePartMatch;
          parsedNewDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day), 0, 0, 0, 0);
        } else {
          parsedNewDate = new Date(newDate);
        }
      } else {
        parsedNewDate = new Date(newDate);
      }
      console.log(`[Reschedule] Activity ${id}: Old date=${new Date(activity.scheduledDate).toLocaleDateString()} \u2192 New date=${parsedNewDate.toLocaleDateString()} (ISO: ${parsedNewDate.toISOString()})`);
      const rescheduleNumber = (activity.rescheduleCount || 0) + 1;
      await db.insert(activityReschedules2).values({
        activityId: id,
        previousDate: activity.scheduledDate,
        previousStartTime: activity.startTime,
        previousEndTime: activity.endTime,
        newDate: parsedNewDate,
        newStartTime,
        newEndTime,
        reason,
        rescheduledBy: req.user.userId,
        rescheduleNumber
      });
      const updateData = {
        scheduledDate: parsedNewDate,
        startTime: newStartTime,
        endTime: newEndTime,
        rescheduleCount: rescheduleNumber,
        updatedAt: /* @__PURE__ */ new Date()
      };
      if (activity.endDate) {
        if (newEndDate) {
          let parsedEndDate;
          if (typeof newEndDate === "string") {
            const datePartMatch = newEndDate.match(/(\d{4})-(\d{2})-(\d{2})/);
            if (datePartMatch) {
              const [, year, month, day] = datePartMatch;
              parsedEndDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day), 23, 59, 59, 999);
            } else {
              parsedEndDate = new Date(newEndDate);
            }
          } else {
            parsedEndDate = new Date(newEndDate);
          }
          if (parsedEndDate < parsedNewDate) {
            return res.status(400).json({ error: "A data fim n\xE3o pode ser anterior \xE0 data in\xEDcio." });
          }
          updateData.endDate = parsedEndDate;
        } else {
          const originalStart = new Date(activity.scheduledDate);
          const originalEnd = new Date(activity.endDate);
          const durationMs = originalEnd.getTime() - originalStart.getTime();
          updateData.endDate = new Date(parsedNewDate.getTime() + durationMs);
        }
      }
      const [updatedActivity] = await db.update(activities).set(updateData).where(eq5(activities.id, id)).returning();
      console.log(`[Reschedule] Activity ${id} updated successfully. New scheduledDate: ${updatedActivity.scheduledDate}`);
      invalidateActivitiesCache();
      res.json(updatedActivity);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/reschedule-day", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      const { originalDate, newDate, newStartTime, newEndTime, reason } = req.body;
      if (!originalDate || !newDate || !newStartTime || !newEndTime || !reason) {
        return res.status(400).json({ error: "originalDate, newDate, newStartTime, newEndTime and reason are required" });
      }
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This is not a multi-day activity. Use the regular reschedule endpoint." });
      }
      const origDateStr = new Date(originalDate).toISOString().split("T")[0];
      const startDateStr = new Date(activity.scheduledDate).toISOString().split("T")[0];
      const endDateStr = new Date(activity.endDate).toISOString().split("T")[0];
      if (origDateStr < startDateStr || origDateStr > endDateStr) {
        return res.status(400).json({ error: "The original date is not within the activity date range." });
      }
      const existingDayStatus = await db.select().from(activityDayStatus).where(and3(
        eq5(activityDayStatus.activityId, id),
        eq5(activityDayStatus.date, /* @__PURE__ */ new Date(origDateStr + "T00:00:00Z"))
      ));
      const completedStatuses = ["concluido"];
      if (existingDayStatus.length > 0 && completedStatuses.includes(existingDayStatus[0].status)) {
        return res.status(400).json({ error: "Dias j\xE1 conclu\xEDdos n\xE3o podem ser reagendados." });
      }
      const newActivity = await storage.createActivity({
        technicianId: activity.technicianId,
        clientId: activity.clientId,
        clientName: activity.clientName,
        siteId: activity.siteId,
        activityTypeId: activity.activityTypeId,
        title: activity.title ? `${activity.title} (reagendado)` : void 0,
        description: activity.description ? `${activity.description} - Reagendado de ${origDateStr}` : `Reagendado de ${origDateStr}`,
        address: activity.address,
        numero: activity.numero,
        bairro: activity.bairro,
        city: activity.city,
        state: activity.state,
        country: activity.country || "Brasil",
        latitude: activity.latitude,
        longitude: activity.longitude,
        scheduledDate: new Date(newDate),
        startTime: newStartTime,
        endTime: newEndTime,
        status: "planejado"
      });
      if (existingDayStatus.length > 0) {
        await db.update(activityDayStatus).set({
          status: "cancelado",
          notes: `Reagendado para ${new Date(newDate).toISOString().split("T")[0]} - Motivo: ${reason}`
        }).where(eq5(activityDayStatus.id, existingDayStatus[0].id));
      } else {
        await db.insert(activityDayStatus).values({
          activityId: id,
          date: /* @__PURE__ */ new Date(origDateStr + "T00:00:00Z"),
          status: "cancelado",
          notes: `Reagendado para ${new Date(newDate).toISOString().split("T")[0]} - Motivo: ${reason}`
        });
      }
      const rescheduleNumber = (activity.rescheduleCount || 0) + 1;
      await db.insert(activityReschedules2).values({
        activityId: id,
        previousDate: /* @__PURE__ */ new Date(origDateStr + "T00:00:00"),
        previousStartTime: activity.startTime,
        previousEndTime: activity.endTime,
        newDate: new Date(newDate),
        newStartTime,
        newEndTime,
        reason,
        rescheduledBy: req.user.userId,
        rescheduleNumber
      });
      await db.update(activities).set({ rescheduleCount: rescheduleNumber, updatedAt: /* @__PURE__ */ new Date() }).where(eq5(activities.id, id));
      res.json({
        originalActivity: activity,
        newActivity,
        rescheduledDay: origDateStr
      });
    } catch (error) {
      console.error("Reschedule day error:", error);
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities/:id/reschedules", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      const reschedules = await db.select().from(activityReschedules2).where(eq5(activityReschedules2.activityId, id)).orderBy(activityReschedules2.rescheduleNumber);
      res.json(reschedules);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/reschedules/calendar-ghosts", authMiddleware, async (req, res) => {
    try {
      const { startDate, endDate, technicianId } = req.query;
      let query = db.select({
        id: activityReschedules2.id,
        activityId: activityReschedules2.activityId,
        previousDate: activityReschedules2.previousDate,
        previousStartTime: activityReschedules2.previousStartTime,
        previousEndTime: activityReschedules2.previousEndTime,
        newDate: activityReschedules2.newDate,
        newStartTime: activityReschedules2.newStartTime,
        newEndTime: activityReschedules2.newEndTime,
        reason: activityReschedules2.reason,
        rescheduleNumber: activityReschedules2.rescheduleNumber,
        createdAt: activityReschedules2.createdAt,
        // Activity info
        activityTitle: activities.title,
        activityClientName: activities.clientName,
        activityTechnicianId: activities.technicianId,
        activityStatus: activities.status
      }).from(activityReschedules2).innerJoin(activities, eq5(activityReschedules2.activityId, activities.id));
      const conditions = [];
      if (technicianId && technicianId !== "all") {
        conditions.push(eq5(activities.technicianId, technicianId));
      }
      if (startDate && endDate) {
        conditions.push(gte3(activityReschedules2.previousDate, new Date(startDate)));
        conditions.push(lte3(activityReschedules2.previousDate, new Date(endDate)));
      }
      const reschedules = await query.where(and3(...conditions));
      res.json(reschedules);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities/:id/day-status", authMiddleware, async (req, res) => {
    try {
      const { id } = req.params;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This endpoint is only for multi-day activities" });
      }
      const dayStatuses = await db.select().from(activityDayStatus).where(eq5(activityDayStatus.activityId, id)).orderBy(activityDayStatus.date);
      res.json(dayStatuses);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/activities/:id/day-status/:date", authMiddleware, async (req, res) => {
    try {
      const { id, date } = req.params;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This endpoint is only for multi-day activities" });
      }
      const targetDate = /* @__PURE__ */ new Date(date + "T00:00:00Z");
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);
      const activityStartDate = new Date(activity.scheduledDate);
      activityStartDate.setUTCHours(0, 0, 0, 0);
      const activityEndDate = new Date(activity.endDate);
      activityEndDate.setUTCHours(23, 59, 59, 999);
      if (targetDate < activityStartDate || targetDate > activityEndDate) {
        return res.status(400).json({ error: "Date is outside activity date range" });
      }
      const [existingStatus] = await db.select().from(activityDayStatus).where(
        and3(
          eq5(activityDayStatus.activityId, id),
          gte3(activityDayStatus.date, targetDate),
          lt(activityDayStatus.date, nextDay)
        )
      ).limit(1);
      if (existingStatus) {
        return res.json(existingStatus);
      }
      res.json(null);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/activities/:id/day-status/:date", authMiddleware, async (req, res) => {
    try {
      const { id, date } = req.params;
      const {
        status,
        startTime,
        endTime,
        checkInTime,
        checkOutTime,
        checkInLatitude,
        checkInLongitude,
        checkOutLatitude,
        checkOutLongitude,
        actualDurationMinutes,
        workCompleted,
        notes
      } = req.body;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This endpoint is only for multi-day activities" });
      }
      const validStatuses = ["planejado", "aCaminho", "emExecucao", "concluido", "reprovado", "cancelado"];
      if (status && !validStatuses.includes(status)) {
        return res.status(400).json({ error: `Invalid status. Must be one of: ${validStatuses.join(", ")}` });
      }
      const targetDate = /* @__PURE__ */ new Date(date + "T00:00:00Z");
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);
      const activityStartDate = new Date(activity.scheduledDate);
      activityStartDate.setUTCHours(0, 0, 0, 0);
      const activityEndDate = new Date(activity.endDate);
      activityEndDate.setUTCHours(23, 59, 59, 999);
      if (targetDate < activityStartDate || targetDate > activityEndDate) {
        return res.status(400).json({ error: "Date is outside activity date range" });
      }
      if (startTime || endTime) {
        const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
        if (startTime && !timeRegex.test(startTime)) {
          return res.status(400).json({ error: "startTime inv\xE1lido. Use formato HH:MM" });
        }
        if (endTime && !timeRegex.test(endTime)) {
          return res.status(400).json({ error: "endTime inv\xE1lido. Use formato HH:MM" });
        }
        if (startTime && endTime && startTime >= endTime) {
          return res.status(400).json({ error: "Hor\xE1rio de in\xEDcio deve ser antes do hor\xE1rio de fim" });
        }
      }
      if (startTime && endTime && activity.technicianId) {
        const newStart = startTime;
        const newEnd = endTime;
        const dayActivities = await db.select().from(activities).where(
          and3(
            eq5(activities.technicianId, activity.technicianId),
            ne(activities.id, id)
          )
        );
        for (const otherActivity of dayActivities) {
          const otherStartDate = new Date(otherActivity.scheduledDate);
          otherStartDate.setUTCHours(0, 0, 0, 0);
          const otherEndDate = otherActivity.endDate ? new Date(otherActivity.endDate) : otherStartDate;
          otherEndDate.setUTCHours(0, 0, 0, 0);
          if (targetDate >= otherStartDate && targetDate <= otherEndDate) {
            let otherStart = otherActivity.startTime;
            let otherEnd = otherActivity.endTime;
            if (otherActivity.endDate) {
              const [otherDayStatus] = await db.select().from(activityDayStatus).where(
                and3(
                  eq5(activityDayStatus.activityId, otherActivity.id),
                  gte3(activityDayStatus.date, targetDate),
                  lt(activityDayStatus.date, nextDay)
                )
              ).limit(1);
              if (otherDayStatus?.startTime) otherStart = otherDayStatus.startTime;
              if (otherDayStatus?.endTime) otherEnd = otherDayStatus.endTime;
            }
            if (newStart < otherEnd && newEnd > otherStart) {
              return res.status(409).json({
                error: `Conflito de hor\xE1rio: j\xE1 existe uma atividade (${otherActivity.title || otherActivity.clientName || "Sem t\xEDtulo"}) das ${otherStart} \xE0s ${otherEnd} neste dia.`
              });
            }
          }
        }
      }
      const [existingStatus] = await db.select().from(activityDayStatus).where(
        and3(
          eq5(activityDayStatus.activityId, id),
          gte3(activityDayStatus.date, targetDate),
          lt(activityDayStatus.date, nextDay)
        )
      ).limit(1);
      if (existingStatus) {
        const [updated] = await db.update(activityDayStatus).set({
          status: status || existingStatus.status,
          startTime: startTime !== void 0 ? startTime : existingStatus.startTime,
          endTime: endTime !== void 0 ? endTime : existingStatus.endTime,
          checkInTime: checkInTime ? new Date(checkInTime) : existingStatus.checkInTime,
          checkOutTime: checkOutTime ? new Date(checkOutTime) : existingStatus.checkOutTime,
          checkInLatitude: checkInLatitude ?? existingStatus.checkInLatitude,
          checkInLongitude: checkInLongitude ?? existingStatus.checkInLongitude,
          checkOutLatitude: checkOutLatitude ?? existingStatus.checkOutLatitude,
          checkOutLongitude: checkOutLongitude ?? existingStatus.checkOutLongitude,
          actualDurationMinutes: actualDurationMinutes ?? existingStatus.actualDurationMinutes,
          workCompleted: workCompleted ?? existingStatus.workCompleted,
          notes: notes ?? existingStatus.notes,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq5(activityDayStatus.id, existingStatus.id)).returning();
        return res.json(updated);
      } else {
        const [created] = await db.insert(activityDayStatus).values({
          activityId: id,
          date: targetDate,
          status: status || "planejado",
          startTime: startTime || null,
          endTime: endTime || null,
          checkInTime: checkInTime ? new Date(checkInTime) : null,
          checkOutTime: checkOutTime ? new Date(checkOutTime) : null,
          checkInLatitude: checkInLatitude ?? null,
          checkInLongitude: checkInLongitude ?? null,
          checkOutLatitude: checkOutLatitude ?? null,
          checkOutLongitude: checkOutLongitude ?? null,
          actualDurationMinutes: actualDurationMinutes ?? null,
          workCompleted: workCompleted ?? false,
          notes: notes ?? null
        }).returning();
        return res.json(created);
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/day-status/:date/check-in", authMiddleware, async (req, res) => {
    try {
      const { id, date } = req.params;
      const { latitude, longitude } = req.body;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This endpoint is only for multi-day activities" });
      }
      const targetDate = /* @__PURE__ */ new Date(date + "T00:00:00Z");
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);
      const now = /* @__PURE__ */ new Date();
      const activityStartDate = new Date(activity.scheduledDate);
      activityStartDate.setUTCHours(0, 0, 0, 0);
      const activityEndDate = new Date(activity.endDate);
      activityEndDate.setUTCHours(23, 59, 59, 999);
      if (targetDate < activityStartDate || targetDate > activityEndDate) {
        return res.status(400).json({ error: "Date is outside activity date range" });
      }
      const [result] = await db.insert(activityDayStatus).values({
        activityId: id,
        date: targetDate,
        status: "emExecucao",
        checkInTime: now,
        checkInLatitude: latitude ?? null,
        checkInLongitude: longitude ?? null
      }).onConflictDoUpdate({
        target: [activityDayStatus.activityId, activityDayStatus.date],
        set: {
          status: "emExecucao",
          checkInTime: now,
          checkInLatitude: latitude ?? null,
          checkInLongitude: longitude ?? null,
          updatedAt: now
        }
      }).returning();
      await storage.updateActivity(id, {
        checkInTime: now
      });
      return res.json(result);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/activities/:id/day-status/:date/check-out", authMiddleware, async (req, res) => {
    try {
      const { id, date } = req.params;
      const { latitude, longitude, workCompleted, notes, justification, lostMinutes, executionMinutes } = req.body;
      const activity = await storage.getActivity(id);
      if (!activity) {
        return res.status(404).json({ error: "Activity not found" });
      }
      if (!activity.endDate) {
        return res.status(400).json({ error: "This endpoint is only for multi-day activities" });
      }
      if (workCompleted === false && (!justification || justification.trim().length === 0)) {
        return res.status(400).json({ error: "Justificativa \xE9 obrigat\xF3ria quando o trabalho n\xE3o foi realizado" });
      }
      const targetDate = /* @__PURE__ */ new Date(date + "T00:00:00Z");
      const targetDateForWorkDate = /* @__PURE__ */ new Date(date + "T12:00:00Z");
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);
      const now = /* @__PURE__ */ new Date();
      const activityStartDate = new Date(activity.scheduledDate);
      activityStartDate.setUTCHours(0, 0, 0, 0);
      const activityEndDate = new Date(activity.endDate);
      activityEndDate.setUTCHours(23, 59, 59, 999);
      if (targetDate < activityStartDate || targetDate > activityEndDate) {
        return res.status(400).json({ error: "Date is outside activity date range" });
      }
      const [existingStatus] = await db.select().from(activityDayStatus).where(
        and3(
          eq5(activityDayStatus.activityId, id),
          gte3(activityDayStatus.date, targetDate),
          lt(activityDayStatus.date, nextDay)
        )
      ).limit(1);
      if (!existingStatus) {
        return res.status(400).json({ error: "No check-in found for this date" });
      }
      let actualDuration = null;
      if (workCompleted === true) {
        const parsedExecution = typeof executionMinutes === "number" ? executionMinutes : parseInt(executionMinutes, 10);
        if (!isNaN(parsedExecution) && parsedExecution >= 0) {
          actualDuration = parsedExecution;
        } else if (existingStatus.checkInTime) {
          actualDuration = Math.round((now.getTime() - new Date(existingStatus.checkInTime).getTime()) / 6e4);
        }
      } else {
        const parsedLost = typeof lostMinutes === "number" ? lostMinutes : typeof lostMinutes === "string" ? parseInt(lostMinutes, 10) : NaN;
        if (!isNaN(parsedLost) && parsedLost >= 0) {
          actualDuration = parsedLost;
        } else if (existingStatus.checkInTime) {
          actualDuration = Math.round((now.getTime() - new Date(existingStatus.checkInTime).getTime()) / 6e4);
        }
      }
      let finalNotes = notes ?? existingStatus.notes;
      if (workCompleted === false && justification) {
        finalNotes = `N\xE3o realizado - ${justification.trim()}`;
      }
      const dayStatus = "concluido";
      const [updated] = await db.update(activityDayStatus).set({
        status: dayStatus,
        checkOutTime: now,
        checkOutLatitude: latitude ?? null,
        checkOutLongitude: longitude ?? null,
        actualDurationMinutes: actualDuration,
        workCompleted: workCompleted ?? false,
        notes: finalNotes,
        updatedAt: now
      }).where(eq5(activityDayStatus.id, existingStatus.id)).returning();
      const activityType = await storage.getActivityType(activity.activityTypeId);
      if (activityType) {
        try {
          const existingIdaEntry = await db.select().from(timeEntries2).where(
            and3(
              eq5(timeEntries2.technicianId, activity.technicianId),
              eq5(timeEntries2.agendaActivityId, id),
              eq5(timeEntries2.source, "ida_travel"),
              eq5(timeEntries2.workDate, targetDate)
            )
          ).limit(1);
          if (existingIdaEntry.length === 0) {
            const targetDateStr = date;
            const idaRecords = await db.select().from(activityTimeRecords).where(
              and3(
                eq5(activityTimeRecords.activityId, id),
                eq5(activityTimeRecords.recordType, "ida"),
                or2(
                  and3(
                    gte3(activityTimeRecords.finishedAt, targetDate),
                    lt(activityTimeRecords.finishedAt, nextDay)
                  ),
                  sql4`DATE(${activityTimeRecords.createdAt}) = ${targetDateStr}`
                )
              )
            ).orderBy(activityTimeRecords.createdAt);
            const idaRecord = idaRecords.length > 0 ? idaRecords[idaRecords.length - 1] : null;
            if (idaRecord && idaRecord.minutesReported > 0) {
              let travelCategory;
              if (activityType.category === "efetivo" && workCompleted !== false) {
                travelCategory = "adicional";
              } else if (workCompleted === false) {
                travelCategory = "perda";
              } else {
                travelCategory = activityType.category === "adicional" ? "adicional" : activityType.category === "perda" ? "perda" : "adicional";
              }
              await db.insert(timeEntries2).values({
                technicianId: activity.technicianId,
                activityTypeId: activity.activityTypeId,
                workDate: targetDateForWorkDate,
                minutes: idaRecord.minutesReported,
                category: travelCategory,
                source: "ida_travel",
                location: "Trajeto",
                notes: `Dia ${date} - IDA at\xE9 ${activity.clientName || "cliente"}: ${idaRecord.minutesReported}min (informado pelo t\xE9cnico)`,
                createdBy: req.user.userId,
                agendaActivityId: id
              });
              console.log(`\u2705 Time entry IDA dia ${date}: ${idaRecord.minutesReported}min de ${travelCategory}`);
            }
          } else {
            console.log(`\u2139\uFE0F Time entry IDA j\xE1 existe para dia ${date}, pulando`);
          }
        } catch (e) {
          console.error("\u26A0\uFE0F Erro ao criar time entry de IDA do dia:", e);
        }
      }
      if (workCompleted === true && actualDuration && actualDuration > 0 && activityType) {
        try {
          await db.insert(timeEntries2).values({
            technicianId: activity.technicianId,
            activityTypeId: activity.activityTypeId,
            workDate: targetDateForWorkDate,
            minutes: actualDuration,
            category: activityType.category === "efetivo" ? "efetivo" : activityType.category === "adicional" ? "adicional" : "perda",
            source: "timer",
            location: activity.location ?? null,
            notes: `Dia ${date} - Execu\xE7\xE3o em ${activity.clientName || "cliente"}`,
            createdBy: req.user.userId
          });
          console.log(`\u2705 Time entry EXECU\xC7\xC3O dia ${date}: ${actualDuration}min`);
        } catch (e) {
          console.error("\u26A0\uFE0F Erro ao criar time entry de execu\xE7\xE3o do dia:", e);
        }
      } else if (workCompleted === false) {
        const parsedLost = typeof lostMinutes === "number" ? lostMinutes : parseInt(lostMinutes, 10);
        if (!isNaN(parsedLost) && parsedLost > 0) {
          try {
            await db.insert(timeEntries2).values({
              technicianId: activity.technicianId,
              activityTypeId: activity.activityTypeId,
              workDate: targetDateForWorkDate,
              minutes: parsedLost,
              category: "perda",
              source: "timer",
              location: activity.location ?? null,
              notes: `Dia ${date} - Tempo n\xE3o produtivo em ${activity.clientName || "cliente"}${justification ? ` | Motivo: ${justification.trim()}` : ""}`,
              createdBy: req.user.userId
            });
            console.log(`\u2705 Time entry PERDA dia ${date}: ${parsedLost}min`);
          } catch (e) {
            console.error("\u26A0\uFE0F Erro ao criar time entry de perda do dia:", e);
          }
        }
      }
      await storage.updateActivity(id, {
        navigationStartTime: null,
        navigationEtaMinutes: null
      });
      res.json(updated);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats", authMiddleware, async (req, res) => {
    try {
      let filterTechnicianId;
      let cacheKey;
      if (req.user.role !== "admin") {
        let techId = _userTechCache.get(req.user.userId);
        if (!techId) {
          const technician = await storage.getTechnicianByUserId(req.user.userId);
          if (!technician) {
            return res.status(403).json({ error: "Technician not found for this user" });
          }
          techId = technician.id;
          _userTechCache.set(req.user.userId, techId);
        }
        filterTechnicianId = techId;
        cacheKey = `tech:${techId}`;
      } else {
        cacheKey = "admin";
      }
      const lightSelect = getRatsLightSelect();
      const conditions = [];
      if (filterTechnicianId) conditions.push(eq5(rats.technicianId, filterTechnicianId));
      const runQuery = async () => {
        const q = conditions.length > 0 ? db.select(lightSelect).from(rats).where(and3(...conditions)).orderBy(desc2(rats.createdAt)) : db.select(lightSelect).from(rats).orderBy(desc2(rats.createdAt));
        return q;
      };
      const cached = _ratsCache.get(cacheKey);
      if (cached) {
        res.json(cached.data);
        const age = Date.now() - cached.ts;
        if (age > RATS_CACHE_TTL) {
          _bgRefreshRatsCache(cacheKey, runQuery).catch(() => {
          });
        }
        return;
      }
      let lightRats = null;
      try {
        lightRats = await runQuery();
      } catch (dbErr) {
        console.error(`[RATs] DB query failed:`, dbErr.message);
        return res.status(503).json({
          error: "Servidor aquecendo, tente novamente em alguns segundos",
          retryAfter: 5
        });
      }
      _ratsCache.set(cacheKey, { data: lightRats, ts: Date.now() });
      console.log(`[RATs cache] populated key="${cacheKey}" (${lightRats.length} items)`);
      res.json(lightRats);
    } catch (error) {
      console.error("[RATs] Failed to fetch:", error.message);
      res.status(500).json({ error: error.message || "Failed to fetch RATs" });
    }
  });
  app2.get("/api/rats/export-all-pdfs", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const allRats = await db.select().from(rats).orderBy(desc2(rats.createdAt));
      if (allRats.length === 0) {
        return res.status(404).json({ error: "Nenhuma RAT encontrada" });
      }
      const ratsWithContent = allRats.filter((r) => r.formData && r.formData !== "{}" && r.formData !== "");
      if (ratsWithContent.length === 0) {
        return res.status(404).json({ error: "Nenhuma RAT com conte\xFAdo preenchido encontrada" });
      }
      console.log(`[PDF Export] Iniciando exporta\xE7\xE3o de ${ratsWithContent.length} RATs como PDFs...`);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", `attachment; filename="RATs_Export_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.zip"`);
      const archive = archiver("zip", { zlib: { level: 5 } });
      archive.on("error", (err) => {
        console.error("[PDF Export] Archive error:", err);
        if (!res.headersSent) {
          res.status(500).json({ error: "Archive error: " + err.message });
        } else {
          res.end();
        }
      });
      let aborted = false;
      res.on("close", () => {
        if (!archive.closed) {
          aborted = true;
          archive.abort();
          console.log("[PDF Export] Client disconnected, aborting export");
        }
      });
      archive.pipe(res);
      let successCount = 0;
      let errorCount = 0;
      for (const rat of ratsWithContent) {
        if (aborted) break;
        try {
          const technician = await storage.getTechnician(rat.technicianId);
          const formData = rat.formData ? JSON.parse(rat.formData) : {};
          const html = rat.isSimplified ? generateSimplifiedRatHtml(rat, technician, formData) : generateRatHtml(rat, technician, formData);
          const pdfBuffer = await generatePdfFromHtml(html);
          const reportNumber = rat.reportNumberManual || rat.reportNumber;
          const clientName = (rat.clientNameEditable || rat.clientName || "").replace(/[\/\\:*?"<>|]/g, "_").substring(0, 50);
          const fileName = `${reportNumber}_${clientName}.pdf`;
          archive.append(Buffer.from(pdfBuffer), { name: fileName });
          successCount++;
          console.log(`[PDF Export] \u2705 ${successCount}/${ratsWithContent.length}: ${fileName}`);
        } catch (ratError) {
          errorCount++;
          console.error(`[PDF Export] \u274C Erro na RAT ${rat.reportNumber}: ${ratError.message}`);
        }
      }
      console.log(`[PDF Export] Finalizado: ${successCount} PDFs gerados, ${errorCount} erros`);
      if (!aborted) {
        await archive.finalize();
      }
    } catch (error) {
      console.error("PDF export error:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to export PDFs: " + error.message });
      } else {
        res.end();
      }
    }
  });
  app2.get("/api/rats/pending-count", authMiddleware, async (req, res) => {
    try {
      if (req.user.role === "admin") {
        const result = await db.select({ count: sql4`count(*)::int` }).from(rats).where(eq5(rats.status, "pendente"));
        return res.json({ count: result[0]?.count || 0 });
      }
      const technician = await storage.getTechnicianByUserId(req.user.userId);
      if (!technician) {
        return res.json({ count: 0 });
      }
      const count = await storage.getPendingRatsCount(technician.id);
      res.json({ count });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats/by-activity/:activityId", authMiddleware, async (req, res) => {
    try {
      const rat = await storage.getRatByActivityId(req.params.activityId);
      if (!rat) {
        return res.status(404).json({ error: "RAT not found for this activity" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || rat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats/:id", authMiddleware, async (req, res) => {
    try {
      const rat = await storage.getRat(req.params.id);
      if (!rat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || rat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/rats", authMiddleware, async (req, res) => {
    try {
      const data = createRatSchema.parse(req.body);
      const reportNumber = await storage.getNextRatNumber();
      const activity = await storage.getActivity(data.activityId);
      if (!activity) {
        return res.status(400).json({ error: "Activity not found" });
      }
      const technicianId = data.technicianId || activity.technicianId;
      if (!technicianId) {
        return res.status(400).json({ error: "Activity has no technician assigned" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || technicianId !== technician.id) {
          return res.status(403).json({ error: "You can only create RATs for your own activities" });
        }
      }
      const rat = await storage.createRat({
        activityId: data.activityId,
        technicianId,
        formData: data.formData,
        status: data.status || "pendente",
        reportNumber,
        clientName: activity.clientName || "Cliente n\xE3o identificado",
        clientId: activity.clientId || void 0,
        openDate: activity.checkOutTime || /* @__PURE__ */ new Date(),
        // New fields
        reportNumberManual: data.reportNumberManual,
        clientNameEditable: data.clientNameEditable,
        projectType: data.projectType,
        openingDate: data.openingDate,
        closingDate: data.closingDate,
        surfaceMaintenanceGrade: data.surfaceMaintenanceGrade,
        applicationNote: data.applicationNote,
        technicianSignature: data.technicianSignature,
        technicianSignatureName: data.technicianSignatureName,
        photoSections: data.photoSections,
        isSimplified: data.isSimplified || false
      });
      addRatToCache({
        id: rat.id,
        reportNumber: rat.reportNumber,
        reportNumberManual: rat.reportNumberManual || null,
        activityId: rat.activityId,
        technicianId: rat.technicianId,
        clientName: rat.clientName,
        status: rat.status,
        openDate: rat.openDate,
        sentAt: rat.sentAt || null,
        importedPdfUrl: rat.importedPdfUrl || null,
        importedPdfFilename: rat.importedPdfFilename || null,
        isSimplified: rat.isSimplified || false,
        createdAt: rat.createdAt,
        hasFormData: !!rat.formData,
        hasSignature: !!rat.technicianSignature,
        hasPhotos: !!(rat.photoSections || rat.photos)
      });
      res.status(201).json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.put("/api/rats/:id", authMiddleware, async (req, res) => {
    try {
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || existingRat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      const data = updateRatSchema.parse(req.body);
      if (existingRat.sentAt && req.user.role !== "admin") {
        const isOnlySentAtChange = Object.keys(data).length === 1 && "sentAt" in data;
        if (!isOnlySentAtChange) {
          return res.status(400).json({ error: "Cannot modify a sent RAT" });
        }
      }
      console.log(`[RAT Update] ID: ${req.params.id}, Status being set: ${data.status}, Current status: ${existingRat.status}`);
      const rat = await storage.updateRat(req.params.id, data);
      console.log(`[RAT Update] Updated RAT status: ${rat.status}`);
      patchRatInCache(rat.id, {
        status: rat.status,
        sentAt: rat.sentAt,
        reportNumberManual: rat.reportNumberManual,
        clientName: rat.clientName,
        isSimplified: rat.isSimplified,
        importedPdfUrl: rat.importedPdfUrl,
        importedPdfFilename: rat.importedPdfFilename,
        hasFormData: !!rat.formData,
        hasSignature: !!rat.technicianSignature,
        hasPhotos: !!(rat.photoSections || rat.photos)
      });
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.patch("/api/rats/:id/complete", authMiddleware, async (req, res) => {
    try {
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || existingRat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      const rat = await storage.updateRat(req.params.id, {
        status: "completa",
        closeDate: /* @__PURE__ */ new Date()
      });
      patchRatInCache(rat.id, { status: "completa" });
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/rats/fix-pending", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
    try {
      const allRats = await db.select().from(rats).where(eq5(rats.status, "pendente"));
      let fixed = 0;
      for (const rat of allRats) {
        const hasContent = rat.formData && rat.formData !== "{}" && rat.formData !== "";
        if (hasContent) {
          await db.update(rats).set({ status: "completa", closeDate: /* @__PURE__ */ new Date() }).where(eq5(rats.id, rat.id));
          fixed++;
        }
      }
      if (fixed > 0) invalidateRatsCache();
      res.json({ message: `${fixed} RATs pendentes corrigidas para completa`, fixed, total: allRats.length });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app2.post("/api/rats/:id/send", authMiddleware, async (req, res) => {
    try {
      const { channel } = req.body;
      if (!channel || !["whatsapp", "email", "ambos"].includes(channel)) {
        return res.status(400).json({ error: "Invalid channel. Use 'whatsapp', 'email', or 'ambos'" });
      }
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician2 = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician2 || existingRat.technicianId !== technician2.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      const technician = await storage.getTechnician(existingRat.technicianId);
      let formData = {};
      try {
        formData = existingRat.formData ? JSON.parse(existingRat.formData) : {};
      } catch (e) {
        formData = {};
      }
      const formatDate = (date) => {
        if (!date) return "N/A";
        return new Date(date).toLocaleDateString("pt-BR");
      };
      const displayReportNumber = existingRat.reportNumberManual || existingRat.reportNumber;
      const message = `*RELAT\xD3RIO DE ASSIST\xCANCIA T\xC9CNICA - RENNER*

*N\xFAmero:* ${displayReportNumber}
*Data:* ${formatDate(existingRat.openDate)}
*Cliente:* ${existingRat.clientName || "N/A"}

_Segue em anexo o relat\xF3rio completo em PDF._`;
      const whatsappLink = `https://wa.me/?text=${encodeURIComponent(message)}`;
      const emailSubject = `RAT ${displayReportNumber} - ${existingRat.clientName || "Cliente"}`;
      const emailBody = message.replace(/\*/g, "").replace(/_/g, "");
      const emailLink = `mailto:${formData.email || ""}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      const rat = await storage.updateRat(req.params.id, {
        sentAt: /* @__PURE__ */ new Date(),
        sendChannel: channel
      });
      patchRatInCache(rat.id, { sentAt: rat.sentAt, status: rat.status });
      res.json({
        ...rat,
        deepLinks: {
          whatsapp: whatsappLink,
          email: emailLink
        }
      });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/rats/:id", authMiddleware, async (req, res) => {
    try {
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (existingRat.sentAt && req.user.role !== "admin") {
        return res.status(403).json({ error: "Only admins can delete sent RATs" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || existingRat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      await storage.updateRat(req.params.id, {
        status: "pendente",
        formData: null,
        photoSections: null,
        sentAt: null,
        sendChannel: null,
        fileUrl: null,
        importedPdfUrl: null,
        importedPdfFilename: null,
        technicianSignature: null,
        technicianSignatureName: null
      });
      removeRatFromCache(req.params.id);
      res.status(200).json({ message: "RAT resetada para pendente" });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.post("/api/rats/:id/pdf", authMiddleware, upload.single("pdf"), async (req, res) => {
    try {
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || existingRat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      if (existingRat.sentAt) {
        return res.status(400).json({ error: "Cannot upload PDF to a sent RAT" });
      }
      if (!req.file) {
        return res.status(400).json({ error: "No PDF file uploaded" });
      }
      if (req.file.mimetype !== "application/pdf") {
        return res.status(400).json({ error: "Only PDF files are allowed" });
      }
      if (req.file.size > 5 * 1024 * 1024) {
        return res.status(400).json({ error: "PDF file size must be under 5MB" });
      }
      const pdfBase64 = `data:application/pdf;base64,${req.file.buffer.toString("base64")}`;
      const filename = req.file.originalname || `RAT-${existingRat.reportNumber}.pdf`;
      const updateData = {
        importedPdfUrl: pdfBase64,
        importedPdfFilename: filename
      };
      if (existingRat.status === "pendente") {
        updateData.status = "rascunho";
      }
      const rat = await storage.updateRat(req.params.id, updateData);
      patchRatInCache(rat.id, {
        importedPdfUrl: rat.importedPdfUrl,
        importedPdfFilename: rat.importedPdfFilename,
        status: rat.status
      });
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats/:id/download-imported-pdf", async (req, res) => {
    try {
      let token = req.query.token;
      if (!token) {
        const authHeader = req.headers.authorization;
        if (authHeader?.startsWith("Bearer ")) {
          token = authHeader.substring(7);
        }
      }
      if (!token) {
        return res.status(401).json({ error: "Token required" });
      }
      let decoded;
      try {
        decoded = verifyToken(token);
      } catch (err) {
        return res.status(401).json({ error: "Invalid token" });
      }
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(401).json({ error: "User not found" });
      }
      req.user = { userId: user.id, username: user.username || "", role: user.role };
      const rat = await storage.getRat(req.params.id);
      if (!rat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || rat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      if (!rat.importedPdfUrl) {
        return res.status(404).json({ error: "No imported PDF for this RAT" });
      }
      const base64Data = rat.importedPdfUrl.replace(/^data:application\/pdf;base64,/, "");
      const pdfBuffer = Buffer.from(base64Data, "base64");
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${rat.importedPdfFilename || "RAT.pdf"}"`);
      res.send(pdfBuffer);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.delete("/api/rats/:id/pdf", authMiddleware, async (req, res) => {
    try {
      const existingRat = await storage.getRat(req.params.id);
      if (!existingRat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician || existingRat.technicianId !== technician.id) {
          return res.status(403).json({ error: "Access denied" });
        }
        if (existingRat.sentAt || existingRat.status === "completa") {
          return res.status(400).json({ error: "Cannot delete PDF from a completed or sent RAT" });
        }
      }
      const rat = await storage.updateRat(req.params.id, {
        importedPdfUrl: null,
        importedPdfFilename: null
      });
      patchRatInCache(rat.id, { importedPdfUrl: null, importedPdfFilename: null });
      res.json(rat);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats/:id/preview", async (req, res) => {
    try {
      let token = req.query.token;
      if (!token) {
        const authHeader = req.headers.authorization;
        if (authHeader?.startsWith("Bearer ")) {
          token = authHeader.substring(7);
        }
      }
      if (!token) {
        return res.status(401).json({ error: "Token required" });
      }
      let decoded;
      try {
        decoded = verifyToken(token);
      } catch (err) {
        return res.status(401).json({ error: "Invalid token" });
      }
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(401).json({ error: "User not found" });
      }
      req.user = { userId: user.id, username: user.username || "", role: user.role };
      const rat = await storage.getRat(req.params.id);
      if (!rat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician2 = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician2 || rat.technicianId !== technician2.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      const technician = await storage.getTechnician(rat.technicianId);
      const formData = rat.formData ? JSON.parse(rat.formData) : {};
      const html = rat.isSimplified ? generateSimplifiedRatHtml(rat, technician, formData) : generateRatHtml(rat, technician, formData);
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.setHeader("Content-Type", "text/html");
      res.send(html);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app2.get("/api/rats/:id/pdf", async (req, res) => {
    try {
      let token = req.query.token;
      if (!token) {
        const authHeader = req.headers.authorization;
        if (authHeader?.startsWith("Bearer ")) {
          token = authHeader.substring(7);
        }
      }
      if (!token) {
        return res.status(401).json({ error: "Token required" });
      }
      let decoded;
      try {
        decoded = verifyToken(token);
      } catch (err) {
        return res.status(401).json({ error: "Invalid token" });
      }
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(401).json({ error: "User not found" });
      }
      req.user = { userId: user.id, username: user.username || "", role: user.role };
      const rat = await storage.getRat(req.params.id);
      if (!rat) {
        return res.status(404).json({ error: "RAT not found" });
      }
      if (req.user.role !== "admin") {
        const technician2 = await storage.getTechnicianByUserId(req.user.userId);
        if (!technician2 || rat.technicianId !== technician2.id) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      const technician = await storage.getTechnician(rat.technicianId);
      const formData = rat.formData ? JSON.parse(rat.formData) : {};
      const html = rat.isSimplified ? generateSimplifiedRatHtml(rat, technician, formData) : generateRatHtml(rat, technician, formData);
      console.log(`[PDF] Generating PDF using browser pool...`);
      const pdfBuffer = await generatePdfFromHtml(html);
      console.log(`[PDF] PDF generated successfully, size: ${pdfBuffer.length} bytes`);
      const reportNumber = rat.reportNumberManual || rat.reportNumber;
      const fileName = `RAT-${reportNumber}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `inline; filename="${fileName}"`);
      res.setHeader("Content-Length", pdfBuffer.length);
      res.setHeader("Cache-Control", "no-cache");
      res.end(Buffer.from(pdfBuffer));
    } catch (error) {
      console.error("PDF generation error:", error);
      res.status(500).json({ error: "Failed to generate PDF: " + error.message });
    }
  });
  const warmAdminRatsCache = async () => {
    try {
      const data = await db.select(getRatsLightSelect()).from(rats).orderBy(desc2(rats.createdAt));
      _ratsCache.set("admin", { data, ts: Date.now() });
      return true;
    } catch (err) {
      console.warn("[RATs cache] admin warm failed:", err.message);
      return false;
    }
  };
  (async () => {
    console.log("[Startup] \u{1F525} AGGRESSIVE WARM-UP: Acordando o Neon agora!");
    console.log("[Startup] Tentando acordar Neon com query simples...");
    for (let attempt = 0; attempt < 60; attempt++) {
      try {
        await db.execute(sql4`SELECT 1`);
        console.log(`[Startup] \u2705 Neon acordado em tentativa ${attempt + 1}`);
        break;
      } catch (err) {
        console.log(`[Startup] Tentativa ${attempt + 1}/60 falhando, aguardando 1s...`);
        await new Promise((r) => setTimeout(r, 1e3));
      }
    }
    console.log("[Startup] Aquecendo RATs, Technicians e Activities em paralelo...");
    const startWarmUp = Date.now();
    await Promise.all([
      warmAdminRatsCache().catch((err) => console.error("[Startup] RATs warm failed:", err.message)),
      _bgRefreshTechniciansCache().catch((err) => console.error("[Startup] Technicians warm failed:", err.message)),
      // ✅ CRÍTICO: Aquecer activities com INTERVALO DE 90 DIAS
      // RATs.tsx carrega com intervalo padrão de 3 meses (90 dias)
      // Se aquecermos apenas 1 mês, o primeiro carregamento vai bater no banco
      _bgRefreshActivitiesCache("default:all:all", async () => {
        const now = /* @__PURE__ */ new Date();
        const ninetyDaysAgo = new Date(now);
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
        ninetyDaysAgo.setHours(0, 0, 0, 0);
        now.setHours(23, 59, 59, 999);
        console.log(`[Startup] Aquecendo activities de ${ninetyDaysAgo.toISOString().split("T")[0]} a ${now.toISOString().split("T")[0]}`);
        return await storage.getActivitiesByDateRange(ninetyDaysAgo, now);
      }).catch((err) => console.error("[Startup] Activities warm failed:", err.message))
    ]);
    const warmUpTime = Date.now() - startWarmUp;
    console.log(`[Startup] \u2705 AGRESSIVO WARM-UP CONCLU\xCDDO em ${warmUpTime}ms!`);
  })();
  setInterval(() => {
    warmAdminRatsCache().catch(() => {
    });
    for (const key of _ratsCache.keys()) {
      if (key.startsWith("tech:")) {
        const techId = key.slice("tech:".length);
        _bgRefreshRatsCache(
          key,
          async () => db.select(getRatsLightSelect()).from(rats).where(eq5(rats.technicianId, techId)).orderBy(desc2(rats.createdAt))
        ).catch(() => {
        });
      }
    }
    _bgRefreshTechniciansCache().catch(() => {
    });
    const now = /* @__PURE__ */ new Date();
    const ninetyDaysAgo = new Date(now);
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    ninetyDaysAgo.setHours(0, 0, 0, 0);
    now.setHours(23, 59, 59, 999);
    _bgRefreshActivitiesCache(
      "default:all:all",
      async () => storage.getActivitiesByDateRange(ninetyDaysAgo, now)
    ).catch(() => {
    });
  }, 60 * 1e3);
  const httpServer = createServer(app2);
  return httpServer;
}
function generateSimplifiedRatHtml(rat, technician, formData) {
  const formatDate = (date) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("pt-BR");
  };
  const isChecked = (arr, value) => {
    if (!arr) return false;
    return arr.some((v) => v.toLowerCase() === value.toLowerCase());
  };
  const checkbox = (checked) => checked ? "\u2611" : "\u2610";
  const logoBase64 = RENNER_LOGO_BASE64;
  let photoSections = {};
  try {
    if (rat.photoSections) {
      photoSections = typeof rat.photoSections === "string" ? JSON.parse(rat.photoSections) : rat.photoSections;
    }
  } catch (e) {
    console.error("Error parsing photoSections:", e);
  }
  let photoGalleryHtml = "";
  for (const [sectionKey, photos] of Object.entries(photoSections)) {
    if (Array.isArray(photos) && photos.length > 0) {
      let sectionPhotosHtml = "";
      let sectionHasPhotos = false;
      for (const photo of photos) {
        const photoData = photo?.data || photo?.base64;
        if (photo && photoData) {
          sectionHasPhotos = true;
          const imgSrc = photoData.startsWith("data:") ? photoData : `data:image/jpeg;base64,${photoData}`;
          sectionPhotosHtml += `<div style="page-break-inside: avoid; display: inline-block; width: 48%; vertical-align: top; margin: 0 1% 12px 1%; text-align: center;">
            <img src="${imgSrc}" style="display: block; margin: 0 auto; max-width: 100%; max-height: 260px; width: auto; height: auto; border: 1px solid #ccc; border-radius: 4px; object-fit: contain;" />
            ${photo.description ? `<p style="font-size: 9pt; color: #333; margin: 4px 0 0 0; font-weight: 500; word-wrap: break-word; overflow-wrap: break-word; word-break: break-word; max-width: 100%;">${photo.description}</p>` : ""}
          </div>`;
        }
      }
      if (sectionHasPhotos) {
        photoGalleryHtml += `<div style="font-size: 0;">
            ${sectionPhotosHtml}
        </div>`;
      }
    }
  }
  const techName = rat.technicianSignatureName || technician?.name || "T\xE9cnico Respons\xE1vel";
  let signatureHtml = `<div style="text-align: center; margin-top: 40px; page-break-inside: avoid;">
    <div style="display: inline-block; text-align: center;">
      <div style="border-top: 1px solid #000; width: 250px; margin: 0 auto; padding-top: 5px; font-size: 9pt;">${techName}</div>
    </div>
  </div>`;
  if (rat.technicianSignature) {
    const sigSrc = rat.technicianSignature.startsWith("data:") ? rat.technicianSignature : `data:image/png;base64,${rat.technicianSignature}`;
    signatureHtml = `<div style="text-align: center; margin-top: 40px; page-break-inside: avoid;">
      <div style="display: inline-block; text-align: center;">
        <img src="${sigSrc}" style="max-width: 280px; max-height: 100px; display: block; margin: 0 auto; background-color: #ffffff;" />
        <div style="border-top: 1px solid #000; width: 280px; margin: 5px auto 0; padding-top: 5px; font-size: 9pt;">
          ${techName}
        </div>
      </div>
    </div>`;
  }
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RAT Simplificada - ${rat.reportNumberManual || rat.reportNumber}</title>
  <style>
    @page { size: A4; margin: 10mm; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; font-size: 10pt; line-height: 1.5; color: #000; background: #fff; }
    .page { max-width: 210mm; margin: 0 auto; padding: 10mm; overflow: hidden; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
    .header-title { 
      background: linear-gradient(135deg, #6b6b6b 0%, #888888 100%);
      color: white; 
      padding: 10px 25px; 
      font-size: 13pt; 
      font-weight: bold;
      border-radius: 3px;
      box-shadow: 2px 2px 4px rgba(0,0,0,0.2);
    }
    .header-subtitle {
      font-size: 9pt;
      color: #fff;
      font-weight: normal;
      margin-top: 2px;
    }
    .logo { height: 50px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 8px; table-layout: fixed; }
    td, th { border: 1px solid #bbb; padding: 6px 8px; vertical-align: top; font-size: 10pt; overflow: hidden; word-wrap: break-word; overflow-wrap: break-word; word-break: normal; }
    p { word-wrap: break-word; overflow-wrap: break-word; word-break: normal; }
    img { max-width: 100%; height: auto; }
    .section-title { font-weight: bold; text-align: center; background: #f0f0f0; padding: 6px; font-size: 11pt; word-break: normal; }
    .subsection-title { font-weight: bold; text-align: center; background: #d9d9d9; padding: 5px; font-size: 10pt; word-break: normal; }
    .cb { margin-right: 20px; white-space: nowrap; }
    .text-section { min-height: 80px; padding: 8px; white-space: pre-wrap; font-size: 10pt; line-height: 1.6; }
    .signature-line { 
      border-top: 1px solid #000; 
      width: 200px; 
      margin: 40px auto 5px; 
      text-align: center;
      padding-top: 5px;
      font-size: 9pt;
    }
    .company-footer {
      text-align: center;
      margin-top: 40px;
      padding: 20px;
    }
    .company-footer .title { font-weight: bold; font-size: 11pt; margin-bottom: 15px; }
    .company-footer .logo-small { height: 40px; margin: 10px 0; }
    .company-footer .info { font-size: 9pt; line-height: 1.6; }
    .company-footer a { color: #0066cc; text-decoration: underline; }
    .doc-footer { 
      font-size: 7pt; 
      color: #666; 
      margin-top: 15px; 
      padding-top: 5px;
      border-top: 1px solid #ccc;
    }
    @media print { 
      body { print-color-adjust: exact; -webkit-print-color-adjust: exact; } 
      .page { padding: 5mm; margin: 0; }
    }
  </style>
</head>
<body>
  <div class="page">
    <div class="header">
      <div>
        <div class="header-title">RELAT\xD3RIO DE ASSIST\xCANCIA T\xC9CNICA
          <div class="header-subtitle">Simplificada</div>
        </div>
      </div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo" onerror="this.style.display='none'">
    </div>
    
    <table>
      <tr>
        <td style="width:50%">Relat\xF3rio n\xBA: ${rat.reportNumberManual || rat.reportNumber}</td>
        <td style="width:50%">Data abertura: ${formatDate(rat.openingDate || rat.openDate)}</td>
      </tr>
    </table>
    
    <table>
      <tr><td colspan="2" class="section-title">DADOS CLIENTE</td></tr>
      <tr>
        <td style="width:50%"><strong>Cliente:</strong> ${formData.clientNameEditable || rat.clientName || ""}</td>
        <td style="width:50%"><strong>Contato:</strong> ${formData.contact || ""}</td>
      </tr>
      <tr>
        <td><strong>Aplicadora:</strong> ${formData.applicator || ""}</td>
        <td><strong>Setor:</strong> ${formData.sector || ""}</td>
      </tr>
      <tr>
        <td><strong>Obra:</strong> ${formData.obraName || ""}</td>
        <td><strong>Tipo:</strong> <span class="cb">${checkbox((rat.projectType || formData.projectType) === "manutencao")} Manuten\xE7\xE3o</span> <span class="cb">${checkbox((rat.projectType || formData.projectType) === "nova")} Nova</span></td>
      </tr>
      <tr>
        <td colspan="2"><strong>Segmento:</strong>
          <span class="cb">${checkbox(isChecked(formData.segment, "powder"))} Powder</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "performance"))} Performance</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "protective"))} Protective</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "marine"))} Marine</span>
        </td>
      </tr>
    </table>
    
    <table>
      <tr><td class="section-title">ATIVIDADES REALIZADAS</td></tr>
      <tr><td class="text-section">${formData.activityPerformed || formData.activitiesPerformed || ""}</td></tr>
    </table>
    
    <table>
      <tr><td class="section-title">COMENT\xC1RIOS GERAIS</td></tr>
      <tr><td class="text-section">${formData.generalComments || formData.comments || ""}</td></tr>
    </table>

    ${photoGalleryHtml ? `<div style="page-break-before: always;"></div>
    <table>
      <tr><td class="section-title">RELAT\xD3RIO FOTOGR\xC1FICO</td></tr>
      <tr><td style="border: 1px solid #bbb; padding: 4px 8px;">
        ${photoGalleryHtml}
      </td></tr>
    </table>` : ""}
    
    <div style="page-break-inside: avoid;">
    ${signatureHtml}
    
    <div class="company-footer">
      <div class="title">Assist\xEAncia T\xE9cnica</div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo-small" onerror="this.style.display='none'">
      <div class="info">
        <strong>Renner Herrmann S.A.</strong><br>
        Divis\xE3o Renner Coatings<br>
        Av. Juscelino Kubitschek de Oliveira, 12.453 - CIC<br>
        81.170-300 \u2013 Curitiba \u2013 PR \u2013 Brasil<br>
        <a href="https://www.rennercoatings.com">www.rennercoatings.com</a><br>
        <a href="https://www.renner.com.br">www.renner.com.br</a>
      </div>
    </div>
    
    <div class="doc-footer">1.400 F4-Relat\xF3rio de Assist\xEAncia T\xE9cnica Simplificado</div>
    </div>
  </div>
</body>
</html>`;
}
function generateRatHtml(rat, technician, formData) {
  const formatDate = (date) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("pt-BR");
  };
  const isChecked = (arr, value) => {
    if (!arr) return false;
    return arr.some((v) => v.toLowerCase() === value.toLowerCase());
  };
  const checkbox = (checked) => checked ? "\u2611" : "\u2610";
  const naValue = (val) => val || '<span style="color:#c00">N/A</span>';
  const logoBase64 = RENNER_LOGO_BASE64;
  console.log("Logo base64 length:", logoBase64?.length || 0, "starts with:", logoBase64?.substring(0, 50));
  const components = formData.components || [];
  let componentRowsHtml = "";
  const categoryLabels = {
    "A": "Componente A",
    "B": "Componente B",
    "C": "Componente C",
    "Componente A": "Componente A",
    "Componente B": "Componente B",
    "Componente C": "Componente C",
    "Diluente": "Diluente",
    "Powder": "Powder"
  };
  for (const comp of components) {
    if (!comp.code && !comp.batch) continue;
    const categoryLabel = categoryLabels[comp.category] || comp.category || "Componente";
    componentRowsHtml += '<tr><td colspan="3"><strong>' + categoryLabel + ":</strong> " + (comp.code || "") + "</td></tr><tr><td>Lote: " + (comp.batch || "") + "</td><td>Fabrica\xE7\xE3o: " + (comp.manufactureDate || "") + "</td><td>Validade: " + (comp.expiryDate || "") + "</td></tr>";
    const thicknessLabel = comp.category === "Diluente" || comp.category === "diluente" ? "Dilui\xE7\xE3o Recomendada" : "Espessura Recomendada";
    if (comp.technicalBulletin || comp.recommendedThickness) {
      componentRowsHtml += "<tr><td>C\xF3d. Boletim T\xE9cnico: " + (comp.technicalBulletin || naValue(null)) + '</td><td colspan="2">' + thicknessLabel + ": " + (comp.recommendedThickness || naValue(null)) + "</td></tr>";
    }
    if (comp.complements) {
      componentRowsHtml += '<tr><td colspan="3">Complementos: ' + comp.complements + "</td></tr>";
    }
  }
  if (componentRowsHtml === "" && components.length > 0) {
    for (let i = 0; i < 3; i++) {
      const c = components[i] || {};
      const letter = String.fromCharCode(65 + i);
      const codeVal = c.code || (i === 2 ? '<span style="color:#c00">N/A</span>' : "");
      componentRowsHtml += '<tr><td colspan="3"><strong>C\xF3digo comp. ' + letter + ":</strong> " + codeVal + "</td></tr><tr><td>Lote: " + (c.batch || "") + "</td><td>Fabrica\xE7\xE3o: " + (c.manufactureDate || "") + "</td><td>Validade: " + (c.expiryDate || "") + "</td></tr>";
    }
  }
  const diluentHtml = formData.diluent ? '<tr><td colspan="3"><strong>Diluente:</strong> ' + (formData.diluent || "") + "</td></tr><tr><td>Lote: " + (formData.diluentBatch || "") + "</td><td>Fabrica\xE7\xE3o: " + (formData.diluentManufacture || "") + "</td><td>Validade: " + (formData.diluentExpiry || "") + "</td></tr>" : "";
  let photoSections = {};
  try {
    if (rat.photoSections) {
      photoSections = typeof rat.photoSections === "string" ? JSON.parse(rat.photoSections) : rat.photoSections;
    }
  } catch (e) {
    console.error("Error parsing photoSections:", e);
  }
  const sectionLabels = {
    section1: "Superf\xEDcie/Substrato",
    section2: "Prepara\xE7\xE3o",
    section3: "Aplica\xE7\xE3o",
    section4: "Resultado Final",
    section5: "Defeitos/Problemas",
    section6: "Outros"
  };
  let photoGalleryHtml = "";
  for (const [sectionKey, photos] of Object.entries(photoSections)) {
    if (Array.isArray(photos) && photos.length > 0) {
      const sectionTitle = sectionLabels[sectionKey] || sectionKey;
      let sectionHasPhotos = false;
      let sectionPhotosHtml = "";
      for (const photo of photos) {
        const photoData = photo?.data || photo?.base64;
        if (photo && photoData) {
          sectionHasPhotos = true;
          const imgSrc = photoData.startsWith("data:") ? photoData : `data:image/jpeg;base64,${photoData}`;
          sectionPhotosHtml += `<div style="text-align: center; margin-bottom: 10px; overflow: hidden;">
            <img src="${imgSrc}" style="display: block; margin: 0 auto; max-width: 100%; max-height: 400px; width: auto; height: auto; border: 1px solid #ccc; border-radius: 4px; object-fit: contain;" />
            ${photo.description ? `<p style="font-size: 10pt; color: #333; margin: 2px 0 0 0; font-weight: 500; word-wrap: break-word; overflow-wrap: break-word; word-break: normal; max-width: 100%;">${photo.description}</p>` : ""}
          </div>`;
        }
      }
      if (sectionHasPhotos) {
        photoGalleryHtml += `<div style="margin-bottom: 6px;">
          <h4 style="font-size: 12pt; margin-bottom: 4px; color: #000; font-weight: bold;">${sectionTitle}</h4>
            ${sectionPhotosHtml}
        </div>`;
      }
    }
  }
  const techName2 = rat.technicianSignatureName || technician?.name || "T\xE9cnico Respons\xE1vel";
  let signatureHtml = `<div class="signature-line">${techName2}</div>`;
  if (rat.technicianSignature) {
    const sigSrc = rat.technicianSignature.startsWith("data:") ? rat.technicianSignature : `data:image/png;base64,${rat.technicianSignature}`;
    signatureHtml = `<div style="text-align: center; margin-top: 40px;">
      <div style="display: inline-block; text-align: center;">
        <img src="${sigSrc}" style="max-width: 280px; max-height: 100px; display: block; margin: 0 auto; background-color: #ffffff;" />
        <div style="border-top: 1px solid #000; width: 280px; margin: 5px auto 0; padding-top: 5px; font-size: 9pt;">
          ${techName2}
        </div>
      </div>
    </div>`;
  }
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RAT - ${rat.reportNumberManual || rat.reportNumber}</title>
  <style>
    @page { size: A4; margin: 10mm; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; font-size: 9pt; line-height: 1.4; color: #000; background: #fff; }
    .page { max-width: 210mm; margin: 0 auto; padding: 8mm; page-break-after: always; }
    .page:last-child { page-break-after: auto; }
    
    /* Header - exact F2 template */
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
    .header-title { 
      background: linear-gradient(135deg, #6b6b6b 0%, #888888 100%);
      color: white; 
      padding: 10px 25px; 
      font-size: 13pt; 
      font-weight: bold;
      border-radius: 3px;
      box-shadow: 2px 2px 4px rgba(0,0,0,0.2);
    }
    .logo { height: 50px; }
    
    /* Main table styling */
    table { width: 100%; border-collapse: collapse; margin-bottom: 3px; table-layout: fixed; }
    td, th { border: 1px solid #000; padding: 4px 6px; vertical-align: top; font-size: 9pt; overflow: hidden; word-wrap: break-word; overflow-wrap: break-word; word-break: normal; }
    p { word-wrap: break-word; overflow-wrap: break-word; word-break: normal; }
    img { max-width: 100%; height: auto; }
    
    /* Section headers */
    .section-title { font-weight: bold; text-align: center; background: #f0f0f0; padding: 5px; font-size: 10pt; word-break: normal; }
    .subsection-title { font-weight: bold; text-align: center; background: #d9d9d9; padding: 4px; font-size: 9pt; word-break: normal; }
    
    /* Checkbox styling */
    .cb { margin-right: 20px; white-space: nowrap; }
    
    /* Text sections */
    .text-section { min-height: 55px; padding: 5px; white-space: pre-wrap; }
    
    /* Legend row */
    .legend-row td { text-align: center; background: #f5f5f5; font-size: 8pt; padding: 3px; }
    
    /* Signature */
    .signature-line { 
      border-top: 1px solid #000; 
      width: 200px; 
      margin: 40px auto 5px; 
      text-align: center;
      padding-top: 5px;
      font-size: 9pt;
    }
    
    /* Company footer - Page 3 style */
    .company-footer {
      text-align: center;
      margin-top: 50px;
      padding: 20px;
    }
    .company-footer .title { font-weight: bold; font-size: 11pt; margin-bottom: 15px; }
    .company-footer .logo-small { height: 40px; margin: 10px 0; }
    .company-footer .info { font-size: 9pt; line-height: 1.6; }
    .company-footer a { color: #0066cc; text-decoration: underline; }
    
    /* Document footer */
    .doc-footer { 
      font-size: 7pt; 
      color: #666; 
      margin-top: 15px; 
      padding-top: 5px;
      border-top: 1px solid #ccc;
    }
    
    @media print { 
      body { print-color-adjust: exact; -webkit-print-color-adjust: exact; } 
      .page { padding: 5mm; margin: 0; }
    }
  </style>
</head>
<body>
  <!-- PAGE 1 -->
  <div class="page">
    <div class="header">
      <div class="header-title">RELAT\xD3RIO DE ASSIST\xCANCIA T\xC9CNICA</div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo" onerror="this.style.display='none'">
    </div>
    
    <table>
      <tr>
        <td style="width:50%">Relat\xF3rio n\xBA: ${rat.reportNumberManual || rat.reportNumber}</td>
        <td style="width:50%">Data abertura: ${formatDate(rat.openingDate || rat.openDate)}</td>
      </tr>
      <tr>
        <td colspan="2" style="text-align:center; padding: 6px;">
          <span class="cb">${checkbox(isChecked(formData.serviceType, "exigencia"))} Exig\xEAncia</span>
          <span class="cb">${checkbox(isChecked(formData.serviceType, "corretiva"))} Corretiva</span>
          <span class="cb">${checkbox(isChecked(formData.serviceType, "preventiva"))} Preventiva</span>
          <span class="cb">${checkbox(isChecked(formData.serviceType, "teste"))} Teste</span>
          <span class="cb">${checkbox(isChecked(formData.serviceType, "rc"))} RC</span>
          <span class="cb">${checkbox(isChecked(formData.serviceType, "outros"))} Outros</span>
        </td>
      </tr>
    </table>
    
    <table>
      <tr><td colspan="4" class="section-title">DADOS CLIENTE</td></tr>
      <tr>
        <td style="width:15%">Cliente:</td>
        <td style="width:35%">${rat.clientName || ""}</td>
        <td style="width:15%">Aplicadora:</td>
        <td style="width:35%">${formData.applicator || ""}</td>
      </tr>
      <tr>
        <td>Obra:</td>
        <td colspan="3">${formData.obraName || ""}</td>
      </tr>
      <tr>
        <td>Contato:</td>
        <td>${formData.contact || ""}</td>
        <td>E-mail:</td>
        <td>${formData.email || ""}</td>
      </tr>
      <tr>
        <td>Setor:</td>
        <td>${formData.sector || ""}</td>
        <td>Data de fechamento:</td>
        <td>${formatDate(rat.closingDate || rat.closeDate)}</td>
      </tr>
      <tr>
        <td>Segmento:</td>
        <td colspan="3">
          <span class="cb">${checkbox(isChecked(formData.segment, "powder"))} Powder</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "performance"))} Performance</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "protective"))} Protective</span>
          <span class="cb">${checkbox(isChecked(formData.segment, "marine"))} Marine</span>
        </td>
      </tr>
    </table>
    
    <table>
      <tr><td colspan="3" class="section-title">DADOS T\xC9CNICOS</td></tr>
      <tr><td colspan="3" class="subsection-title">Superf\xEDcie</td></tr>
      <tr><td colspan="3">Substrato: ${formData.substrate || ""}</td></tr>
      <tr><td colspan="3">Agressividade a que o revestimento / pintura ser\xE1 submetido: ${formData.aggressiveness || ""}</td></tr>
      <tr><td colspan="3">Grau inicial da superf\xEDcie: ${formData.initialGrade || ""}</td></tr>
      <tr><td colspan="3">Manuten\xE7\xE3o (ASTM D610) 0 a 10: ${rat.surfaceMaintenanceGrade != null ? `Grau ${rat.surfaceMaintenanceGrade}` : formData.surfaceMaintenanceGrade != null ? `Grau ${formData.surfaceMaintenanceGrade}` : "N\xE3o Aplic\xE1vel"}</td></tr>
      <tr><td colspan="3">Tipo de preparo de superf\xEDcie: ${formData.surfacePrep || ""}</td></tr>
      <tr><td colspan="3">Tipo de abrasivo: ${formData.abrasiveType || ""}</td></tr>
      <tr><td colspan="3">Rugosidade: ${formData.roughness || ""}</td></tr>
      
      <tr><td colspan="3" class="subsection-title">Produto</td></tr>
      <tr><td colspan="3">Produto / Descri\xE7\xE3o: ${formData.product?.description || ""}</td></tr>
      <tr><td colspan="3">Cor: ${formData.product?.color || ""}</td></tr>
      ${componentRowsHtml}
      ${diluentHtml}
    </table>
    
    <div class="doc-footer">1.400 F2 - Relat\xF3rio de Assist\xEAncia T\xE9cnica rev. 06 de 12/2025</div>
  </div>
  
  <!-- PAGE 2 -->
  <div class="page">
    <div class="header">
      <div class="header-title">RELAT\xD3RIO DE ASSIST\xCANCIA T\xC9CNICA</div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo" onerror="this.style.display='none'">
    </div>
    
    <table>
      <tr><td colspan="3" class="subsection-title">Caracter\xEDsticas de aplica\xE7\xE3o</td></tr>
      <tr><td colspan="3">Viscosidade de trabalho (s) /Dilui\xE7\xE3o (%): ${formData.application?.viscosity || ""}</td></tr>
      <tr><td colspan="3">Espessura seca total (E.F.S \xB5m): ${formData.application?.totalThickness || ""}</td></tr>
      <tr>
        <td>Primer: ${formData.application?.primer || ""}</td>
        <td>Intermedi\xE1rio: ${formData.application?.intermediate || naValue(null)}</td>
        <td>Acabamento: ${formData.application?.finish || ""}</td>
      </tr>
      <tr><td colspan="3">Temperatura (\xBAC): ${formData.application?.temperature || ""}</td></tr>
      <tr><td colspan="3">URA (%): ${formData.application?.humidity || ""}</td></tr>
      <tr><td colspan="3">Superf\xEDcie Aplicada/Pe\xE7a: ${formData.application?.equipment || ""}</td></tr>
      <tr><td colspan="3">M\xE9todo de Aplica\xE7\xE3o: ${formData.application?.method || ""}</td></tr>
      <tr><td colspan="3">Condi\xE7\xF5es de aplica\xE7\xE3o: ${formData.application?.conditions || ""}</td></tr>
      <tr><td colspan="3">Observa\xE7\xF5es Adicionais: ${rat.applicationNote || formData.applicationNote || ""}</td></tr>
      <tr class="legend-row">
        <td colspan="3" style="text-align:center;"><strong>Legenda</strong></td>
      </tr>
      <tr class="legend-row">
        <td>N/A: N\xE3o Aplic\xE1vel</td>
        <td>FAB: Fabrica\xE7\xE3o</td>
        <td>VAL.: Validade</td>
      </tr>
    </table>
    
    <table>
      <tr><td class="subsection-title">Produto e informa\xE7\xF5es t\xE9cnicas:</td></tr>
    </table>
    
    <table>
      <tr><td><strong>1-OBJETIVO:</strong></td></tr>
      <tr><td class="text-section">${formData.objective || ""}</td></tr>
    </table>
    
    <table>
      <tr><td><strong>2- PARTICIPANTES:</strong></td></tr>
      <tr><td class="text-section">${formData.participants || ""}</td></tr>
    </table>
    
    <table>
      <tr><td><strong>3-ATIVIDADES REALIZADAS:</strong></td></tr>
      <tr><td class="text-section">${formData.activitiesPerformed || ""}</td></tr>
    </table>
    
    <table>
      <tr><td><strong>4- COMENT\xC1RIOS:</strong></td></tr>
      <tr><td class="text-section">${formData.comments || ""}</td></tr>
    </table>
    
    <table>
      <tr><td><strong>5 \u2013 CONCLUS\xC3O:</strong></td></tr>
      <tr><td class="text-section">${formData.conclusion || ""}</td></tr>
    </table>
    
    ${photoGalleryHtml ? `<div style="page-break-before: always;"></div>` : ""}
    <table>
      <tr><td><strong>6 - RELAT\xD3RIO FOTOGR\xC1FICO:</strong></td></tr>
      <tr><td class="text-section">
        ${photoGalleryHtml || formData.photoReport || "<em>Nenhuma foto anexada</em>"}
      </td></tr>
    </table>
    
    <table>
      <tr><td><strong>7 \u2013 DOCUMENTOS DE REFER\xCANCIA:</strong></td></tr>
      <tr><td class="text-section">${formData.referenceDocuments || "N/A"}</td></tr>
    </table>
    
    <div class="doc-footer">1.400 F2 - Relat\xF3rio de Assist\xEAncia T\xE9cnica rev. 06 de 12/2025</div>
  </div>
  
  <!-- PAGE 3 - Assinatura e Informa\xE7\xF5es da Empresa -->
  <div class="page">
    <div class="header">
      <div class="header-title">RELAT\xD3RIO DE ASSIST\xCANCIA T\xC9CNICA</div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo" onerror="this.style.display='none'">
    </div>
    
    ${signatureHtml}
    
    <div class="company-footer">
      <div class="title">Assist\xEAncia T\xE9cnica</div>
      <img src="${logoBase64}" alt="Renner Coatings" class="logo-small" onerror="this.style.display='none'">
      <div class="info">
        <strong>Renner Herrmann S.A.</strong><br>
        Divis\xE3o Renner Coatings<br>
        Av. Juscelino Kubitschek de Oliveira, 12.453 - CIC<br>
        81.170-300 \u2013 Curitiba \u2013 PR \u2013 Brasil<br>
        <a href="https://www.rennercoatings.com">www.rennercoatings.com</a><br>
        <a href="https://www.renner.com.br">www.renner.com.br</a>
      </div>
    </div>
    
    <div class="doc-footer">1.400 F2 - Relat\xF3rio de Assist\xEAncia T\xE9cnica rev. 06 de 12/2025</div>
  </div>
</body>
</html>`;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      ),
      await import("@replit/vite-plugin-dev-banner").then(
        (m) => m.devBanner()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/migrate.ts
await init_db();
import { sql as sql5 } from "drizzle-orm";
var MIGRATION_LOG_TABLE = `
  CREATE TABLE IF NOT EXISTS _migration_log (
    id SERIAL PRIMARY KEY,
    version VARCHAR(50) NOT NULL,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT,
    success BOOLEAN DEFAULT true
  )
`;
async function fixAgendaBlockDates() {
  try {
    console.log("\u{1F527} Corrigindo datas de bloqueios de agenda...");
    const result = await db.execute(sql5`
      UPDATE agenda_blocks
      SET 
        start_date = start_date - INTERVAL '1 day',
        end_date = CASE 
          WHEN block_type = 'compromisso' THEN end_date - INTERVAL '1 day'
          ELSE end_date - INTERVAL '1 day'
        END
      WHERE 
        created_at < NOW() - INTERVAL '1 hour'
        AND EXTRACT(HOUR FROM start_date) = 0
        AND EXTRACT(MINUTE FROM start_date) = 0
        AND EXTRACT(HOUR FROM end_date) = 0
        AND EXTRACT(MINUTE FROM end_date) = 0
      RETURNING id, block_type, start_date, end_date
    `);
    const updatedCount = result.rows.length;
    if (updatedCount > 0) {
      console.log(`\u2705 Corrigidas ${updatedCount} datas de bloqueios de agenda`);
      result.rows.forEach((row) => {
        console.log(`   - ${row.block_type}: ${new Date(row.start_date).toLocaleDateString("pt-BR")} a ${new Date(row.end_date).toLocaleDateString("pt-BR")}`);
      });
    } else {
      console.log(`\u2705 Nenhum bloqueio de agenda precisava corre\xE7\xE3o`);
    }
  } catch (error) {
    console.error("\u274C Erro ao corrigir datas de bloqueios:", error);
  }
}
async function addIsActiveToUsers() {
  try {
    console.log("\u{1F527} Verificando coluna is_active na tabela users...");
    const checkColumn = await db.execute(sql5.raw(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' AND column_name = 'is_active'
    `));
    if (checkColumn.rows.length === 0) {
      console.log("  \u2795 Adicionando coluna is_active...");
      await db.execute(sql5.raw(`
        ALTER TABLE users 
        ADD COLUMN is_active BOOLEAN DEFAULT true NOT NULL
      `));
      console.log("  \u2705 Coluna is_active adicionada com sucesso");
    } else {
      console.log("  \u2705 Coluna is_active j\xE1 existe");
    }
  } catch (error) {
    console.error("\u274C Erro ao adicionar coluna is_active:", error.message);
  }
}
async function createPerformanceIndexes() {
  try {
    console.log("\u{1F527} Criando \xEDndices de performance...");
    const indexes = [
      // Activities indexes for date range queries
      { name: "idx_activities_scheduled_date", query: "CREATE INDEX IF NOT EXISTS idx_activities_scheduled_date ON activities(scheduled_date)" },
      { name: "idx_activities_end_date", query: "CREATE INDEX IF NOT EXISTS idx_activities_end_date ON activities(end_date)" },
      { name: "idx_activities_technician_id", query: "CREATE INDEX IF NOT EXISTS idx_activities_technician_id ON activities(technician_id)" },
      { name: "idx_activities_status", query: "CREATE INDEX IF NOT EXISTS idx_activities_status ON activities(status)" },
      // RATs indexes
      { name: "idx_rats_technician_id", query: "CREATE INDEX IF NOT EXISTS idx_rats_technician_id ON rats(technician_id)" },
      { name: "idx_rats_created_at", query: "CREATE INDEX IF NOT EXISTS idx_rats_created_at ON rats(created_at)" },
      { name: "idx_rats_activity_id", query: "CREATE INDEX IF NOT EXISTS idx_rats_activity_id ON rats(activity_id)" },
      // Technicians indexes
      { name: "idx_technicians_user_id", query: "CREATE INDEX IF NOT EXISTS idx_technicians_user_id ON technicians(user_id)" },
      // Clients indexes
      { name: "idx_clients_company_name", query: "CREATE INDEX IF NOT EXISTS idx_clients_company_name ON clients(company_name)" }
    ];
    for (const idx of indexes) {
      try {
        await db.execute(sql5.raw(idx.query));
        console.log(`  \u2705 ${idx.name}`);
      } catch (err) {
        if (!err.message.includes("already exists")) {
          console.warn(`  \u26A0\uFE0F ${idx.name}: ${err.message}`);
        }
      }
    }
    console.log("\u2705 \xCDndices de performance criados");
  } catch (error) {
    console.error("\u274C Erro ao criar \xEDndices:", error);
  }
}
async function runMigrations() {
  const startTime = Date.now();
  console.log("\u{1F504} Iniciando verifica\xE7\xE3o de migra\xE7\xE3o do banco de dados...");
  try {
    await db.execute(sql5.raw(MIGRATION_LOG_TABLE));
    const APP_VERSION = process.env.APP_VERSION || "2.0.0";
    const existingMigration = await db.execute(
      sql5`SELECT * FROM _migration_log WHERE version = ${APP_VERSION} ORDER BY applied_at DESC LIMIT 1`
    );
    if (existingMigration.rows.length > 0) {
      console.log(`\u2705 Vers\xE3o ${APP_VERSION} j\xE1 migrada anteriormente`);
      return;
    }
    console.log(`\u{1F4E6} Sincronizando schema para vers\xE3o ${APP_VERSION}...`);
    const tablesCheck = await db.execute(sql5`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);
    const tables = tablesCheck.rows.map((row) => row.table_name);
    console.log(`\u{1F4CB} Tabelas encontradas: ${tables.join(", ")}`);
    const mainTables = ["users", "clients", "activities", "technicians", "activity_types"];
    for (const tableName of mainTables) {
      if (tables.includes(tableName)) {
        const columnsCheck = await db.execute(sql5.raw(`
          SELECT column_name, data_type, is_nullable 
          FROM information_schema.columns 
          WHERE table_name = '${tableName}' 
          ORDER BY ordinal_position
        `));
        console.log(`  \u{1F4C4} ${tableName}: ${columnsCheck.rows.length} colunas`);
      }
    }
    await fixAgendaBlockDates();
    await addIsActiveToUsers();
    await createPerformanceIndexes();
    await db.execute(
      sql5`INSERT INTO _migration_log (version, description, success) 
          VALUES (${APP_VERSION}, ${"Sincroniza\xE7\xE3o autom\xE1tica do schema + \xEDndices de performance"}, true)`
    );
    const elapsed = Date.now() - startTime;
    console.log(`\u2705 Migra\xE7\xE3o conclu\xEDda com sucesso em ${elapsed}ms`);
  } catch (error) {
    console.error("\u274C Erro durante migra\xE7\xE3o:", error);
    try {
      const APP_VERSION = process.env.APP_VERSION || "2.0.0";
      await db.execute(
        sql5`INSERT INTO _migration_log (version, description, success) 
            VALUES (${APP_VERSION}, ${`Erro: ${error instanceof Error ? error.message : "Unknown error"}`}, false)`
      );
    } catch (logError) {
      console.error("\u274C N\xE3o foi poss\xEDvel registrar erro de migra\xE7\xE3o:", logError);
    }
    console.log("\u26A0\uFE0F Aplica\xE7\xE3o continuar\xE1 mesmo com erro de migra\xE7\xE3o");
  }
}

// server/index.ts
var app = express2();
app.use(express2.json({ limit: "15mb" }));
app.use(express2.urlencoded({ extended: false, limit: "15mb" }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  console.log("\u{1F680} Starting ASTEC server...");
  console.log(`\u{1F4CD} Environment: ${process.env.NODE_ENV || "development"}`);
  console.log(`\u{1F50C} Port: ${process.env.PORT || "5000"}`);
  console.log(`\u{1F5C4}\uFE0F  Database URL configured: ${process.env.DATABASE_URL ? "Yes" : "No"}`);
  try {
    await runMigrations();
    console.log("\u2705 Database migrations completed");
  } catch (error) {
    console.error("\u26A0\uFE0F  Database migration check failed:", error.message);
    console.log("\u26A0\uFE0F  Continuing without migrations - database may need manual setup");
  }
  try {
    await seedActivityTypes();
    console.log("\u2705 Database seeding completed");
  } catch (error) {
    console.error("\u26A0\uFE0F  Database seeding failed - app will start without seeded data:", error.message);
    console.log("\u26A0\uFE0F  Continuing startup - check database connection if issues persist");
  }
  try {
    await seedDefaultAdmin();
  } catch (error) {
    console.error("\u26A0\uFE0F  Default admin seeding failed:", error.message);
  }
  const server = await registerRoutes(app);
  setupWebSocket(server);
  const { startReminderScheduler: startReminderScheduler2 } = await init_notifications().then(() => notifications_exports);
  startReminderScheduler2();
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  const listenOptions = {
    port,
    host: "0.0.0.0"
  };
  if (process.platform !== "win32") {
    listenOptions.reusePort = true;
  }
  server.listen(listenOptions, () => {
    console.log(`\u2705 ASTEC server ready and listening on port ${port}`);
    log(`serving on port ${port}`);
  });
  const gracefulShutdown = async (signal) => {
    console.log(`
\u{1F6D1} Received ${signal}, shutting down gracefully...`);
    const { stopReminderScheduler: stopReminderScheduler2 } = await init_notifications().then(() => notifications_exports);
    stopReminderScheduler2();
    await closeBrowser();
    server.close(() => {
      console.log("\u2705 Server closed");
      process.exit(0);
    });
    setTimeout(() => {
      console.log("\u26A0\uFE0F Forcing exit after timeout");
      process.exit(1);
    }, 1e4);
  };
  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
})();
